/* Turnstile is mounted only in an open review dialog. No secret is sent to the browser. */
(function($){
    'use strict';
    function parts(root){var form=root.find('[data-sr="review-form"]');return {form:form,node:form.find('[data-sr-turnstile]'),status:form.find('.sr-verification-status'),button:form.find('button[type="submit"]'),retry:form.find('[data-sr-turnstile-retry]')};}
    function fail(p,message){p.button.prop('disabled',true);p.status.text(message);p.retry.prop('hidden',false);}
    window.srMountTurnstile=function(root){
        var p=parts($(root));if(!p.node.length||p.node.data('widget-id')!==undefined)return;
        p.button.prop('disabled',true);p.status.text('Checking your connection securely…');p.retry.prop('hidden',true);
        if(!window.turnstile||!p.node.attr('data-sitekey')){fail(p,'Verification could not load. Check your connection and try again.');return;}
        try{window.turnstile.ready(function(){
            if(!p.node[0].isConnected)return;
            var id=window.turnstile.render(p.node[0],{sitekey:p.node.attr('data-sitekey'),action:'starboard-review',theme:'auto',size:p.node[0].getBoundingClientRect().width<300?'compact':'flexible',
                callback:function(){p.button.prop('disabled',false);p.status.text('Security verification complete.');p.retry.prop('hidden',true);},
                'expired-callback':function(){fail(p,'Verification expired. Please refresh the security check.');},
                'error-callback':function(){fail(p,'Verification could not complete. Please retry.');},
                'timeout-callback':function(){fail(p,'Verification timed out. Please retry.');}
            });p.node.data('widget-id',id);
        });}catch(error){fail(p,'Verification could not load. Please retry.');}
    };
    window.srResetTurnstile=function(root){var p=parts($(root)),id=p.node.data('widget-id');if(!p.node.length)return;p.button.prop('disabled',true);p.status.text('Refreshing security verification…');if(window.turnstile&&id!==undefined){try{window.turnstile.reset(id);}catch(error){fail(p,'Please retry security verification.');}}else window.srMountTurnstile($(root));};
    $(document).on('click','[data-sr-turnstile-retry]',function(){window.srResetTurnstile($(this).closest('.sr-widget-container'));});
})(jQuery);
