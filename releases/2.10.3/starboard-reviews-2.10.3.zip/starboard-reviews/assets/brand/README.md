# Starboard identity

Starboard uses a faceted compass star with an extended east-facing point and a diamond aperture. The directional silhouette gives the brand its own identity. Ocean blue and cyan provide the family connection to DigitalDeckhand.

The icon is custom vector artwork. The interface uses separately bundled Lucide icons; the Starboard logo is not a stock interface icon.

Use the shared Starboard mark and wordmark across the suite. Put the product descriptor (Reviews, UI, and future plugin names) in a separate badge or text label. The descriptor is not part of the wordmark artwork.

## Assets

- `starboard-mark.svg`: transparent vector app/menu icon.
- `starboard-logotype.svg`: outlined Starboard lettering, without the icon.
- `starboard-lockup.svg`: icon and wordmark, with fixed spacing.
- `-mono.svg`: single ink color versions for one-color applications.
- `-reverse.svg`: cyan/white icon and white wordmark for dark backgrounds.
- `starboard-icon-512.png`: transparent 512×512 icon.
- `starboard-logo.png`: transparent high-resolution color lockup.

All lettering in the SVGs is outlined, so rendering does not depend on a font being installed. No font files are distributed. Avenir Next Demi Bold informed the outlined wordmark; interface typography uses local system fallbacks.

## Palette and spacing

Ocean: `#2864ED` · Sky: `#27BAF2` · Ink: `#14263D` · Surface: `#F3F6FB`.

Keep clear space of at least one fifth of the icon's width around a standalone mark. Use the supplied lockup proportions. Use the complete mark at 24px or larger where practical; the WordPress menu uses a compact rendering at 20px. Do not stretch the artwork or add gradients, shadows or outlines to the mark. Use the reverse version on dark surfaces.

The central diamond is a transparent cutout. On dark surfaces, use the reverse artwork with white and cyan facets.
