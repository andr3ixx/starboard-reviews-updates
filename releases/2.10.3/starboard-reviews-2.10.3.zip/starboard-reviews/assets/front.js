(function($){
    'use strict';
    function imageUrl(value) {
        try { var url=new URL(String(value),window.location.href);return /^(https?:)$/.test(url.protocol)?url.href:''; }
        catch(error){return '';}
    }
    function openDialog(node){if(window.srDialog)window.srDialog.open(node);else node.css('display','flex');}
    function closeDialog(node){if(window.srDialog)window.srDialog.close(node);else node.hide();}
    function init(root){
        if(root.data('sr-initialized'))return;
        root.data('sr-initialized',true);
        var pid=Number(root.data('pid'))||0, request=null, generation=0, photoGeneration=0, cache=new Map();
        var find=function(id){return root.find('[data-sr="'+id+'"]');};
        var list=find('reviews-list'),load=find('load-more-btn');
        function showReviews(data,page){
            if(page===1)list.html(data.html);else list.append(data.html);
            if(page===1&&!data.html)list.html(Number(root.attr('data-min-rating'))>1?'<div class="sr-review-placeholder"><strong>No reviews match this rating filter yet.</strong></div>':'<div class="sr-review-placeholder"><strong>No reviews yet.</strong></div>');
            root.find('.sr-load-more-wrap').toggle(Boolean(data.has_more));load.data('page',page+1);
        }
        function loadReviews(page){
            if(root.attr('data-preview')==='true')return;
            if(request)request.abort();
            var current=++generation,key=(find('front-sort').val()||root.attr('data-order')||'newest')+':'+page,cached=cache.get(key);
            if(cached&&Date.now()-cached.at<20000){showReviews(cached.data,page);return;}
            load.prop('disabled',true).text('Loading…');list.attr('aria-busy','true');
            if(page===1&&!list.find('.sr-card').length)list.html('<div class="sr-review-skeleton" aria-hidden="true"></div><div class="sr-review-skeleton" aria-hidden="true"></div>');
            request=$.ajax({url:sr_ajax.url,type:'POST',data:{action:'sr_filter_reviews',nonce:sr_ajax.nonce,pid:pid,sort:find('front-sort').val()||root.attr('data-order')||'newest',page:page,count:root.attr('data-count')||6,min_rating:root.attr('data-min-rating')||1,excerpt:root.attr('data-excerpt')||20}})
                .done(function(res){
                    if(current!==generation)return;
                    if(!res.success){find('notice').prop('hidden',false).text('Unable to load reviews. Please try again.');return;}
                    if(cache.size>=30)cache.delete(cache.keys().next().value);
                    cache.set(key,{data:res.data,at:Date.now()});showReviews(res.data,page);
                }).fail(function(xhr,status){
                    if(status==='abort'||current!==generation)return;
                    if(!list.find('.sr-card').length)list.html('<div class="sr-review-placeholder"><strong>Reviews could not load</strong><button type="button" class="sr-btn-secondary sr-retry-reviews">Try again</button></div>');
                    else find('notice').prop('hidden',false).text('Could not load more reviews. Please try again.');
                }).always(function(){if(current===generation){load.prop('disabled',false).text('Load more reviews');list.attr('aria-busy','false');}});
        }
        find('front-sort').on('change',function(){loadReviews(1);});
        load.on('click',function(){loadReviews(Number(load.data('page'))||2);});
        root.on('click','.sr-retry-reviews',function(){loadReviews(1);});
        if(root.attr('data-initial')==='true'){root.find('.sr-load-more-wrap').toggle(root.attr('data-initial-has-more')==='true');load.data('page',2);}else loadReviews(1);
        root.on('click','.sr-trigger-modal',function(){
            var data=$(this).data(),box=find('read-content').empty();
            var header=$('<div class="sr-read-author">').appendTo(box);
            $('<strong>').text(data.author||'').appendTo(header);$('<span>').text(data.date||'').appendTo(header);
            var rating=Math.max(0,Math.min(5,Number(data.rating)||0));
            $('<div class="sr-stars-static">').css('--v',rating).attr({role:'img','aria-label':rating+' out of 5 stars'}).appendTo(box);
            if(data.title)$('<h3 class="sr-read-title">').text(data.title).appendTo(box);
            $('<div class="sr-read-text">').text(data.content||'').appendTo(box);
            var gallery=$('<div class="sr-mini-gallery">').appendTo(box);
            (Array.isArray(data.photos)?data.photos:[]).forEach(function(src,index){
                var url=imageUrl(src);if(!url)return;
                $('<button type="button" class="sr-photo-button">').attr('aria-label','View review photo '+(index+1))
                    .append($('<img>').attr({src:url,alt:'Customer review photo'})).on('click',function(){find('lightbox-image').attr('src',url);openDialog(find('lightbox'));}).appendTo(gallery);
            });
            if(data.reply){var reply=$('<div class="sr-read-reply">').appendTo(box);$('<strong>').text('Store response: ').appendTo(reply);$('<span>').text(data.reply).appendTo(reply);}
            openDialog(find('read-modal'));
        });
        root.find('.sr-btn-write').on('click',function(){openDialog(find('write-modal'));if(window.srMountTurnstile)window.srMountTurnstile(root);});
        // Fallback for embedded integrations that have not enqueued the shared helper.
        root.on('click','.sr-close-btn,.sr-modal-overlay,.sr-lightbox-close,.sr-lightbox-overlay',function(event){
            if(window.srDialog)return;
            if(event.target===this||$(this).is('.sr-close-btn,.sr-lightbox-close'))closeDialog($(this).closest('.sr-modal-overlay,.sr-lightbox-overlay'));
        });
        var labels={1:'Poor',2:'Fair',3:'Good',4:'Very good',5:'Excellent'};
        root.find('.sr-write-stars').each(function(){
            var group=$(this);
            group.find('input').on('change',function(){group.find('.sr-rating-label').text(labels[$(this).val()]||'Select');if(this.name==='cs_rating')find('clear-service').prop('hidden',false);})
                .on('keydown',function(event){
                    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
                    event.preventDefault();
                    var value=Number(this.value),next=event.key==='Home'?1:event.key==='End'?5:Math.max(1,Math.min(5,value+(['ArrowRight','ArrowUp'].includes(event.key)?1:-1)));
                    group.find('input[value="'+next+'"]').prop('checked',true).trigger('change').trigger('focus');
                });
            group.find('label').on('mouseenter',function(){group.find('.sr-rating-label').text(labels[$(this).prev('input').val()]);});
            group.on('mouseleave',function(){group.find('.sr-rating-label').text(labels[group.find('input:checked').val()]||'Select');});
        });
        find('clear-service').on('click',function(){root.find('input[name="cs_rating"]').prop('checked',false);$(this).prop('hidden',true).closest('.sr-write-stars').find('.sr-rating-label').text('Select');});
        find('photo-input').on('change',function(){
            var currentPhoto=++photoGeneration;
            var preview=find('photo-previews').empty();
            if(this.files.length>5||Array.from(this.files).some(function(file){return file.size>5*1024*1024||!/^image\/(jpeg|png|webp)$/.test(file.type);})){find('form-message').text('Choose up to 5 JPEG, PNG or WebP photos, each up to 5 MB.');this.value='';return;}
            Array.from(this.files).forEach(function(file,index){
                var reader=new FileReader();
                reader.onload=function(event){if(currentPhoto!==photoGeneration)return;$('<div class="sr-thumb-wrap">').append($('<img>').attr({src:event.target.result,alt:file.name}),$('<button type="button" class="sr-remove-photo">').attr({'data-index':index,'aria-label':'Remove '+file.name}).append($('<span class="sr-icon sr-icon-x" aria-hidden="true">'))).appendTo(preview);};
                reader.readAsDataURL(file);
            });
        });
        root.on('click','.sr-remove-photo',function(){
            var input=find('photo-input')[0],transfer=new DataTransfer(),index=Number($(this).data('index'));
            Array.from(input.files).forEach(function(file,i){if(i!==index)transfer.items.add(file);});
            input.files=transfer.files;$(input).trigger('change');
        });
        function updateSummary(summary){
            if(!summary)return;
            find('avg').text(summary.avg);find('review-count').text(summary.count);
            find('overall-stars').css('--v',summary.avg).attr('aria-label',summary.avg+' out of 5 stars');
            var badge=summary.avg>=4.5?'Excellent':summary.avg>=4?'Very good':'';
            find('rating-badge').text(badge).prop('hidden',!badge);
            find('cs-score').prop('hidden',!summary.cs_count);find('cs-avg').text(summary.cs_avg);
            [1,2,3,4,5].forEach(function(star){root.find('[data-star-count="'+star+'"]').text(summary.dist[star]);root.find('[data-star-bar="'+star+'"]').css('width',summary.count?(summary.dist[star]/summary.count*100)+'%':'0%');});
        }
        find('review-form').on('submit',function(event){
            event.preventDefault();if(!this.reportValidity())return;
            if(root.attr('data-preview')==='true'){find('form-message').text('This is a preview. No review has been submitted.');return;}
            var form=$(this),message=find('form-message'),button=form.find('button[type="submit"]'),data=new FormData(this);
            if(form.find('[data-sr-turnstile]').length&&!form.find('[name="cf-turnstile-response"]').val()){message.text('Please complete the security verification first.');if(window.srMountTurnstile)window.srMountTurnstile(root);return;}
            data.append('action','sr_submit_review');data.append('security',sr_ajax.nonce);
            message.empty();button.prop('disabled',true).text('Submitting…');
            $.ajax({url:sr_ajax.url,type:'POST',data:data,contentType:false,processData:false}).done(function(res){
                if(!res.success){message.text(res.data&&res.data.message?res.data.message:'Unable to submit review.');return;}
                form[0].reset();photoGeneration++;find('photo-previews').empty();find('clear-service').prop('hidden',true);root.find('.sr-rating-label').text('Select');
                closeDialog(find('write-modal'));find('notice').prop('hidden',false).text(res.data.message);
                if(res.data.approved){cache.clear();loadReviews(1);updateSummary(res.data.summary);}
            }).fail(function(xhr){message.text(xhr.responseJSON&&xhr.responseJSON.data?xhr.responseJSON.data.message:'Unable to submit review. Please try again.');})
                .always(function(){button.prop('disabled',false).text('Submit review');if(window.srResetTurnstile)window.srResetTurnstile(root);});
        });
    }
    window.srInitWidget=function(){$('.sr-widget-container').each(function(){init($(this));});};
    $(document).ready(window.srInitWidget);
})(jQuery);
