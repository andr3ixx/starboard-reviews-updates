# Interface icons

Selected Lucide SVG icons from `lucide-static` 1.68.0, bundled locally. The complete ISC/MIT notices are in `LICENSE`.

`../icons.css` contains data-URI masks generated from these SVGs, so interface icons do not require JavaScript rendering, an icon font, or a third-party CDN. Static fractional ratings use a repeated, filled version of the Lucide star path; interactive ratings use its outline and filled forms.

The Starboard brand mark in `../brand/` is separate custom artwork.
