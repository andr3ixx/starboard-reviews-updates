(function($){
    'use strict';
    $(function(){
        var form=$('#sr-showcase-builder');if(!form.length)return;
        var request=null,generation=0,debounce;
        var defaults={layout:'grid',count:'6',min_rating:'4',columns:'3',product_id:'0',review_ids:'',order:'newest',theme:'light',title:'What our customers say',subtitle:'Real experiences, in their own words.',show_summary:'true',show_product:'true',show_date:'true',show_photos:'false',autoplay:'false',interval:'6',excerpt:'38',link:'',position:'right',font:'default'};
        var productDefaults={product_id:'0',columns:'3',count:'6',min_rating:'1',order:'newest',title:'Customer reviews',subtitle:'Real experiences. Helpful details.',excerpt:'20',show_summary:'true',show_form:'true',show_sort:'true',show_title:'true',show_content:'true',show_date:'true',show_photos:'true',font:'default'};
        var productMode=false,saved={showcase:null,product:null};
        function values(){var data={};form.find('[name]').each(function(){data[this.name]=this.type==='checkbox'?(this.checked?'true':'false'):this.value;});return data;}
        function quote(value){return String(value).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/\[/g,'&#91;').replace(/\]/g,'&#93;');}
        function refresh(){
            form.find('.sc-showcase-only').prop('hidden',productMode).find('input,select').prop('disabled',productMode);form.find('.sc-product-only').prop('hidden',!productMode).find('input,select').prop('disabled',!productMode);
            if(!form[0].checkValidity()){$('#sc-preview-status').text('Check the highlighted fields before updating the preview.');return;}
            var data=values(),activeDefaults=productMode?productDefaults:defaults,code=productMode?'[starboard_reviews':'[starboard_showcase';Object.keys(activeDefaults).forEach(function(key){if(data[key]!==undefined&&data[key]!==activeDefaults[key])code+=' '+key+'="'+quote(data[key])+'"';});code+=']';$('#sc-shortcode').val(code);
            var slider=!productMode&&['carousel','sidebar'].includes(data.layout);form.find('[name="autoplay"],[name="interval"]').prop('disabled',!slider);form.find('[name="position"]').prop('disabled',productMode||data.layout!=='floating');form.find('[name="columns"]').prop('disabled',!productMode&&!['grid','carousel','wall'].includes(data.layout));
            if(request)request.abort();var current=++generation;$('#sc-preview-status').text('Updating preview…');$('#sc-preview').attr('aria-busy','true');
            request=$.ajax({url:sr_vars.ajax_url,type:'POST',data:{action:'sr_preview_showcase',nonce:sr_vars.nonce,...data}}).done(function(res){
                if(current!==generation)return;if(!res.success){$('#sc-preview-status').text(res.data.message||'Could not load preview.');return;}
                $('#sc-preview .sr-modal-overlay,#sc-preview .sr-lightbox-overlay').each(function(){window.srDialog.close($(this));});window.srDestroyShowcases($('#sc-preview'));$('#sc-preview').html(res.data.html);window.srInitShowcases($('#sc-preview'));if(window.srInitWidget)window.srInitWidget();$('#sc-preview-status').text(productMode?'Product preview uses published reviews. Form actions are available on the live page.':'Only published reviews are displayed.');
            }).fail(function(xhr,status){if(status!=='abort'&&current===generation)$('#sc-preview-status').text(xhr.responseJSON&&xhr.responseJSON.data?xhr.responseJSON.data.message:'Could not load preview. Please try again.');}).always(function(){if(current===generation)$('#sc-preview').attr('aria-busy','false');});
        }
        $('#sc-placement').on('change',function(){
            var next=this.value==='product';
            if(next!==productMode){
                saved[productMode?'product':'showcase']=values();productMode=next;
                var restore=saved[next?'product':'showcase']||(next?productDefaults:defaults);
                Object.keys(restore).forEach(function(key){if(key==='placement')return;var field=form.find('[name="'+key+'"]');if(field.is(':checkbox'))field.prop('checked',restore[key]==='true');else field.val(restore[key]);});
            }
            if(this.value==='sidebar')$('#sc-layout').val('sidebar');
            $('#sc-order option[value="manual"]').prop('hidden',next).prop('disabled',next);
            if(next&&$('#sc-order').val()==='manual')$('#sc-order').val('newest');
            $('#sc-count-label').text(next?'Reviews per page':'Number of reviews');
            $('#sc-placement-help').text(next?'Shows the current product automatically when Product ID is 0. Choose columns, review content and form options below.':'Showcase published reviews across your store.');
            clearTimeout(debounce);refresh();
        });
        form.on('submit',function(event){event.preventDefault();});form.on('input change',function(){clearTimeout(debounce);debounce=setTimeout(refresh,260);});
        $('#sc-viewport').on('change',function(){$('#sc-preview').toggleClass('is-mobile',this.value==='mobile');$(window).trigger('resize');});
        $('#sc-copy').on('click',async function(){
            try{if(navigator.clipboard&&window.isSecureContext)await navigator.clipboard.writeText($('#sc-shortcode').val());else{$('#sc-shortcode')[0].select();if(!document.execCommand('copy'))throw Error('copy');}$('#sc-copy-status').text('Copied. Paste it into your page.');}
            catch(error){$('#sc-shortcode')[0].select();$('#sc-copy-status').text('Select the shortcode and copy it with your keyboard.');}
        });
        refresh();
    });
})(jQuery);
