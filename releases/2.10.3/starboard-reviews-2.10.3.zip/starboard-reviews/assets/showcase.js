(function($){
    'use strict';
    var reduced=window.matchMedia('(prefers-reduced-motion: reduce)');
    function init(root){
        if(root.data('showcase-ready'))return;
        root.data('showcase-ready',true);
        var layout=root.attr('data-layout'),track=root.find('.sr-showcase-track'),cards=track.children('.sr-showcase-card');
        var timer=null,paused=false,hover=false,focused=false,current=0,panel=root.find('.sr-showcase-dialog'),portal=null;
        if(panel.length){
            portal=$('<div class="sr-showcase sr-showcase-portal">').addClass(root.hasClass('sr-showcase-theme--dark')?'sr-showcase-theme--dark':root.hasClass('sr-showcase-theme--soft')?'sr-showcase-theme--soft':'sr-showcase-theme--light').css('font-family',getComputedStyle(root[0]).fontFamily).append(panel).appendTo(document.body);
            root.find('[data-showcase-open]').on('click',function(){window.srDialog.open(panel);});
            panel.on('click','[data-showcase-close]',function(){window.srDialog.close(panel);});
            panel.on('click',function(event){if(event.target===this)window.srDialog.close(panel);});
        }
        function visibleCount(){
            if(!track.length||!cards.length)return 1;
            return Math.max(1,Math.min(cards.length,Math.floor((track[0].clientWidth+16+.5)/(cards[0].getBoundingClientRect().width+16))));
        }
        function update(){
            if(!track.length||!cards.length)return;
            var width=cards[0].getBoundingClientRect().width+16;
            if(width)current=Math.max(0,Math.min(cards.length-visibleCount(),Math.round(Math.abs(track[0].scrollLeft)/width)));
            root.find('[data-showcase-status]').text('Reviews '+(current+1)+'–'+Math.min(cards.length,current+visibleCount())+' of '+cards.length);
        }
        function move(direction){
            var max=Math.max(0,cards.length-visibleCount()),target=current+direction;
            if(target>max)target=0;if(target<0)target=max;
            current=target;
            var box=track[0].getBoundingClientRect(),card=cards[target].getBoundingClientRect();
            var delta=getComputedStyle(track[0]).direction==='rtl'?card.right-box.right:card.left-box.left;
            track[0].scrollTo({left:track[0].scrollLeft+delta,behavior:reduced.matches?'auto':'smooth'});
        }
        if(['carousel','sidebar'].includes(layout)&&cards.length){
            root.find('[data-showcase-next]').on('click',function(){move(1);});root.find('[data-showcase-prev]').on('click',function(){move(-1);});
            track.on('keydown',function(event){if(event.target!==track[0])return;if(event.key==='ArrowRight'||event.key==='ArrowLeft'){event.preventDefault();move(event.key==='ArrowRight'?1:-1);}});
            var pending;
            track.on('scroll',function(){clearTimeout(pending);pending=setTimeout(update,70);});
            root.on('mouseenter',function(){hover=true;}).on('mouseleave',function(){hover=false;});
            root.on('focusin',function(){focused=true;}).on('focusout',function(event){focused=Boolean(event.relatedTarget&&root[0].contains(event.relatedTarget));});
            root.find('[data-showcase-pause]').on('click',function(){
                paused=!paused;root.find('[data-showcase-status]').attr('aria-live',paused?'polite':'off');$(this).attr('aria-label',paused?'Play review rotation':'Pause review rotation').find('.sr-icon').toggleClass('sr-icon-pause',!paused).toggleClass('sr-icon-play',paused);
            });
            if(root.attr('data-autoplay')==='true'){root.find('[data-showcase-status]').attr('aria-live','off');if(reduced.matches)root.find('[data-showcase-pause]').prop('disabled',true).attr('aria-label','Automatic rotation is disabled by reduced motion');}
            if(root.attr('data-autoplay')==='true'&&cards.length>1){
                timer=setInterval(function(){
                    if(!root[0].isConnected){clearInterval(timer);return;}
                    if(!paused&&!hover&&!focused&&!document.hidden&&!reduced.matches&&root[0].getBoundingClientRect().bottom>0&&root[0].getBoundingClientRect().top<window.innerHeight)move(1);
                },Number(root.attr('data-interval'))||6000);
            }
            update();
        }
        root.data('showcase-update',update).data('showcase-destroy',function(){clearInterval(timer);clearTimeout(pending);if(panel.length)window.srDialog.close(panel);if(portal)portal.remove();});
    }
    window.srInitShowcases=function(container){var scope=container?$(container):$(document);scope.find('[data-sr-showcase]').addBack('[data-sr-showcase]').each(function(){init($(this));});};
    window.srDestroyShowcases=function(container){$(container).find('[data-sr-showcase]').each(function(){var destroy=$(this).data('showcase-destroy');if(destroy)destroy();});};
    $(window).on('resize.srShowcase',function(){$('[data-sr-showcase]').each(function(){var update=$(this).data('showcase-update');if(update)update();});});
    $(document).ready(function(){window.srInitShowcases();});
})(jQuery);
