<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SR_Admin_Menu {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_menus' ] );
    }

    public function register_menus() {
        // Main Menu: Reviews
        add_menu_page(
            'Starboard Reviews',
            'Starboard Reviews',
            'moderate_comments',
            'starboard-reviews',
            [ 'SR_Reviews_Page', 'render' ],
            SR_URL . 'assets/brand/starboard-mark.svg',
            56
        );

        // Submenu: Reviews (Default)
        add_submenu_page(
            'starboard-reviews',
            'Reviews',
            'Reviews',
            'moderate_comments',
            'starboard-reviews',
            [ 'SR_Reviews_Page', 'render' ]
        );

        add_submenu_page( 'starboard-reviews', 'Review showcases', 'Widgets', 'moderate_comments', 'sr-widgets', [ 'SR_Widgets_Page', 'render' ] );

        // Submenu: Emails
        add_submenu_page(
            'starboard-reviews',
            'Email Automation',
            'Emails',
            'manage_options',
            'sr-emails',
            [ 'SR_Emails_Page', 'render' ]
        );

        // Submenu: Settings
        add_submenu_page(
            'starboard-reviews',
            'Settings',
            'Settings',
            'manage_options',
            'sr-settings',
            [ 'SR_Settings_Page', 'render' ]
        );
    }
}
