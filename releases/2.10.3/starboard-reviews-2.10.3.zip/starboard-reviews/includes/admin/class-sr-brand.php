<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Shared Starboard suite identity; the product name stays separate from the mark. */
class SR_Brand {
    public static function header( $active = 'reviews' ) {
        $links = [
            'reviews' => [ 'Reviews', 'admin.php?page=starboard-reviews' ],
            'widgets' => [ 'Widgets', 'admin.php?page=sr-widgets' ],
            'emails' => [ 'Emails', 'admin.php?page=sr-emails' ],
            'settings' => [ 'Settings', 'admin.php?page=sr-settings' ],
        ];
        ?>
        <header class="sr-masthead">
            <a class="sr-brand" href="<?php echo esc_url( admin_url( 'admin.php?page=starboard-reviews' ) ); ?>" aria-label="Starboard Reviews home">
                <img src="<?php echo esc_url( SR_URL . 'assets/brand/starboard-lockup.svg' ); ?>" alt="Starboard" width="196" height="56">
                <span class="sr-product-badge">Reviews</span>
            </a>
            <nav class="sr-main-nav" aria-label="Starboard Reviews">
                <?php foreach ( $links as $key => $link ) :
                    if ( ! in_array( $key, [ 'reviews','widgets' ], true ) && ! current_user_can( 'manage_options' ) ) continue; ?>
                    <a href="<?php echo esc_url( admin_url( $link[1] ) ); ?>" <?php if ( $active === $key ) echo 'aria-current="page"'; ?>><?php echo esc_html( $link[0] ); ?></a>
                <?php endforeach; ?>
            </nav>
            <button type="button" class="sr-command-trigger" aria-label="Open quick navigation" aria-haspopup="dialog"><span>Jump to…</span><kbd>⌘ K</kbd></button>
        </header>
        <?php
    }

    public static function footer() {
        ?>
        <div class="sr-modal sr-command-modal" id="sr-command-modal" role="dialog" aria-modal="true" aria-labelledby="sr-command-title" tabindex="-1">
            <div class="sr-modal-panel">
                <div class="sr-modal-head"><h2 id="sr-command-title">Quick navigation</h2><button type="button" class="sr-close-modal" aria-label="Close navigation"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button></div>
                <div class="sr-modal-body">
                    <label class="sr-screen-reader" for="sr-command-search">Find a page or action</label>
                    <input type="search" id="sr-command-search" placeholder="Find a page or action…" autocomplete="off">
                    <div id="sr-command-results"></div>
                    <p class="sr-field-help"><span class="sr-icon sr-icon-arrow-up" aria-hidden="true"></span> <span class="sr-icon sr-icon-arrow-down" aria-hidden="true"></span> Navigate · Enter to open · Esc to close</p>
                </div>
            </div>
        </div>
        <?php
    }
}
