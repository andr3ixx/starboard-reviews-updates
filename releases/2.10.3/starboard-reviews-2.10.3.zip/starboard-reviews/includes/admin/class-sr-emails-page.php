<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SR_Emails_Page {

    public static function render() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.', '', [ 'response' => 403 ] );
        $sub = isset( $_GET['sub'] ) ? sanitize_text_field( $_GET['sub'] ) : 'log';
        ?>
        <div class="sr-wrap">
            <?php SR_Brand::header( 'emails' ); ?>
            <div class="sr-top-bar">
                <div class="sr-title-group">
                    <p class="sr-eyebrow">STARBOARD REVIEWS</p><h1>Email requests</h1><p class="sr-page-description">Thoughtful follow-ups. Happier customers. More useful feedback.</p>
                </div>
                <div class="sr-actions">
                    <button class="sr-btn blue" id="sr-force-run-btn">
                        <i class="sr-icon sr-icon-refresh-cw" aria-hidden="true"></i> Process Queue Now
                    </button>
                </div>
            </div>

            <nav class="sr-tabs-nav">
                <a href="?page=sr-emails&sub=log" class="<?php echo $sub === 'log' ? 'active' : ''; ?>">Logs</a>
                <a href="?page=sr-emails&sub=manual" class="<?php echo $sub === 'manual' ? 'active' : ''; ?>">Manual Send</a>
                <a href="?page=sr-emails&sub=settings" class="<?php echo $sub === 'settings' ? 'active' : ''; ?>">Templates & Settings</a>
            </nav>

            <?php
            if ( $sub === 'log' ) {
                self::render_logs_ui();
            } elseif ( $sub === 'manual' ) {
                self::render_manual_ui();
            } else {
                self::render_settings_ui();
            }
            ?>
        </div>
        <?php
    }

    /**
     * Renders a row of pagination links (server-rendered, real <a href> navigation —
     * NOT the AJAX pagination used on the Reviews page). Preserves the current query
     * string and just swaps "pg". Uses a distinct class so it doesn't collide with the
     * '.sr-page-link' click handler in admin.js, which is wired for the AJAX Reviews table.
     */
    private static function render_pagination( $current, $total_pages ) {
        if ( $total_pages <= 1 ) return;
        echo '<div class="sr-pagination">';
        if ( $current > 1 ) {
            echo '<a href="' . esc_url( add_query_arg( 'pg', $current - 1 ) ) . '" class="sr-page-link-static" aria-label="Previous page"><span class="sr-icon sr-icon-chevron-left" aria-hidden="true"></span></a>';
        }
        for ( $i = 1; $i <= $total_pages; $i++ ) {
            if ( $i === 1 || $i === $total_pages || ( $i >= $current - 1 && $i <= $current + 1 ) ) {
                $cls = 'sr-page-link-static' . ( $i === $current ? ' current' : '' );
                echo '<a href="' . esc_url( add_query_arg( 'pg', $i ) ) . '" class="' . esc_attr( $cls ) . '">' . $i . '</a>';
            } elseif ( $i === $current - 2 || $i === $current + 2 ) {
                echo '<span style="padding:5px; color:#ccc;">...</span>';
            }
        }
        if ( $current < $total_pages ) {
            echo '<a href="' . esc_url( add_query_arg( 'pg', $current + 1 ) ) . '" class="sr-page-link-static" aria-label="Next page"><span class="sr-icon sr-icon-chevron-right" aria-hidden="true"></span></a>';
        }
        echo '</div>';
    }

    /**
     * LOGS TAB
     */
    private static function render_logs_ui() {
        global $wpdb;
        $table = $wpdb->prefix . 'sr_requests';
        $per_page = 20;

        $search = isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '';
        $paged  = isset( $_GET['pg'] ) ? max( 1, intval( $_GET['pg'] ) ) : 1;

        $where = "WHERE 1=1";
        $where_params = [];
        if ( $search ) {
            $where .= " AND (customer_email LIKE %s OR order_id = %s)";
            $where_params[] = '%' . $wpdb->esc_like( $search ) . '%';
            $where_params[] = $search;
        }

        $total = $where_params
            ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table $where", $where_params ) )
            : (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table $where" );

        $total_pages = max( 1, (int) ceil( $total / $per_page ) );
        $paged = min( $paged, $total_pages );
        $offset = ( $paged - 1 ) * $per_page;

        $logs = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table $where ORDER BY id DESC LIMIT %d OFFSET %d",
            array_merge( $where_params, [ $per_page, $offset ] )
        ) );
        ?>

        <div class="sr-toolbar" style="justify-content:space-between;">
            <div class="sr-bulk-actions" style="display:flex; gap:10px; align-items:center;">
                <select id="sr-bulk-action-selector">
                    <option value="-1">Bulk Actions</option>
                    <option value="resend">Resend</option>
                    <option value="cancel">Cancel</option>
                </select>
                <button type="button" class="sr-btn white small" id="sr-apply-bulk">Apply</button>
            </div>

            <div class="sr-search-wrap">
                <form method="get">
                    <input type="hidden" name="page" value="sr-emails">
                    <input type="hidden" name="sub" value="log">
                    <i class="sr-icon sr-icon-search" aria-hidden="true"></i>
                    <input type="text" name="s" placeholder="Search by email or Order ID..." value="<?php echo esc_attr( $search ); ?>">
                </form>
            </div>
        </div>

        <div class="sr-table-card">
            <table class="sr-table">
                <thead>
                    <tr>
                        <th width="30"><input type="checkbox" id="sr-select-all"></th>
                        <th width="100">Status</th>
                        <th>Order</th>
                        <th>Customer</th>
                        <th>Type</th>
                        <th>Scheduled For</th>
                        <th>Sent At</th>
                        <th width="120" style="text-align:right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $logs ) ): ?>
                        <tr><td colspan="7" style="text-align:center; padding:40px; color:#94a3b8;">No emails found.</td></tr>
                    <?php else: foreach ( $logs as $log ):
                        $cls = $log->status == 'sent' ? 'approved' : ( $log->status == 'failed' || $log->status == 'cancelled' ? 'spam' : 'hold' );
                    ?>
                        <tr id="email-row-<?php echo $log->id; ?>">
                            <td><input type="checkbox" class="sr-log-cb" value="<?php echo $log->id; ?>"></td>
                            <td><span class="sr-status-badge <?php echo $cls; ?>"><?php echo ucfirst( $log->status ); ?></span></td>
                            <td><a href="<?php echo admin_url( 'post.php?post=' . $log->order_id . '&action=edit' ); ?>">#<?php echo $log->order_id; ?></a></td>
                            <td>
                                <strong><?php echo esc_html( $log->customer_name ); ?></strong><br>
                                <span style="font-size: 14px; color:#64748b;"><?php echo esc_html( $log->customer_email ); ?></span>
                            </td>
                            <td>
                                <?php
                                if ( $log->level == 1 ) echo 'First Request';
                                elseif ( $log->level == 2 ) echo 'Follow-up';
                                else echo 'Customer Service';
                                ?>
                                <?php if ( isset( $log->source ) && $log->source === 'manual' ) : ?>
                                    <span class="sr-badge-pill" style="background:#ede9fe; color:#5b21b6;">Manual</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html( $log->scheduled_date ); ?></td>
                            <td><?php echo esc_html( $log->sent_date ); ?></td>
                            <td style="text-align:right;">
                                <div class="sr-action-group" style="display:flex; justify-content:flex-end; gap:5px;">
                                    <button type="button" class="sr-icon-btn sr-view-email" data-id="<?php echo $log->id; ?>" title="View Email Content">
                                        <i class="sr-icon sr-icon-eye" aria-hidden="true"></i>
                                    </button>

                                    <?php if ( $log->status == 'pending' ) : ?>
                                        <button type="button" class="sr-icon-btn sr-cancel-trigger" data-id="<?php echo $log->id; ?>" title="Cancel Email" style="color:#ef4444;">
                                            <i class="sr-icon sr-icon-ban" aria-hidden="true"></i>
                                        </button>
                                    <?php endif; ?>

                                    <button <?php disabled( $log->status, 'sending' ); ?> type="button" class="sr-icon-btn sr-resend-trigger" data-id="<?php echo $log->id; ?>" title="Resend Email" style="color:#2563eb;">
                                        <i class="sr-icon sr-icon-rotate-cw" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>

        <?php self::render_pagination( $paged, $total_pages ); ?>

        <div id="sr-view-modal" class="sr-modal">
            <div class="sr-modal-panel large"> <div class="sr-modal-head">
                    <h3>Email Preview</h3>
                    <button type="button" class="sr-close-modal" aria-label="Close dialog"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button>
                </div>
                <div class="sr-modal-body" style="background:#f1f5f9; padding:20px; max-height:600px; overflow-y:auto;">
                    <div id="sr-view-content" style="background:#fff; box-shadow:0 2px 10px rgba(0,0,0,0.05); margin:0 auto; max-width:600px;">
                        <div style="padding:40px; text-align:center; color:#94a3b8;">
                            <i class="sr-icon sr-icon-loader-circle sr-icon-spin sr-icon-lg" aria-hidden="true"></i><br>Generating preview...
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="sr-cancel-modal" class="sr-modal">
            <div class="sr-modal-panel small">
                <div class="sr-modal-head"><h3>Cancel Email?</h3><button type="button" class="sr-close-modal" aria-label="Close dialog"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button></div>
                <div class="sr-modal-body"><p>Are you sure you want to cancel this scheduled email?</p></div>
                <div class="sr-modal-foot">
                    <button class="sr-btn white sr-close-modal">Keep</button>
                    <button class="sr-btn red" id="sr-confirm-cancel">Yes, Cancel It</button>
                </div>
            </div>
        </div>

        <div id="sr-resend-modal" class="sr-modal">
            <div class="sr-modal-panel small">
                <div class="sr-modal-head"><h3>Resend Email?</h3><button type="button" class="sr-close-modal" aria-label="Close dialog"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button></div>
                <div class="sr-modal-body"><p>This will schedule the email to be sent <strong>immediately</strong>.</p></div>
                <div class="sr-modal-foot">
                    <button class="sr-btn white sr-close-modal">Cancel</button>
                    <button class="sr-btn blue" id="sr-confirm-resend">Yes, Resend</button>
                </div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($){
            var targetId = 0;

            // --- SELECT ALL CHECKBOX ---
            $('#sr-select-all').on('change', function(){
                $('.sr-log-cb').prop('checked', $(this).is(':checked'));
            });

            // --- BULK ACTIONS ---
            $('#sr-apply-bulk').click(function(){
                var action = $('#sr-bulk-action-selector').val();
                if(action === '-1') return;

                var ids = [];
                $('.sr-log-cb:checked').each(function(){ ids.push($(this).val()); });

                if(ids.length === 0) { alert('Please select items.'); return; }
                if(!confirm('Apply ' + action + ' to ' + ids.length + ' items?')) return;

                var btn = $(this); btn.text('...').prop('disabled',true);

                $.post(ajaxurl, {
                    action: 'sr_bulk_email_action',
                    type: action,
                    ids: ids,
                    nonce: '<?php echo wp_create_nonce("sr_admin_nonce"); ?>'
                }, function(res){
                    if(res.success) location.reload();
                    else { alert('Error processing bulk action'); btn.text('Apply').prop('disabled',false); }
                }).fail(function(xhr){ alert(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to update requests.'); btn.text('Apply').prop('disabled',false); });
            });

            // --- VIEW LOGIC ---
            $('.sr-view-email').click(function(){
                var id = $(this).data('id');
                window.srDialog.open($('#sr-view-modal'));

                // Fetch Preview via AJAX
                $.post(ajaxurl, {
                    action: 'sr_view_email_preview',
                    id: id,
                    nonce: '<?php echo wp_create_nonce("sr_admin_nonce"); ?>'
                }, function(res){
                    if(res.success) {
                        $('#sr-view-content').html(res.data.html);
                    } else {
                        $('#sr-view-content').html('<div style="padding:20px; color:red; text-align:center;">Could not generate preview. Order may no longer exist.</div>');
                    }
                });
            });

            // --- CANCEL / RESEND LOGIC ---
            $('.sr-cancel-trigger').click(function(){ targetId = $(this).data('id'); window.srDialog.open($('#sr-cancel-modal')); });
            $('.sr-resend-trigger').click(function(){ targetId = $(this).data('id'); window.srDialog.open($('#sr-resend-modal')); });

            $('#sr-confirm-cancel').click(function(){ processAction('cancel', targetId); });
            $('#sr-confirm-resend').click(function(){ processAction('resend', targetId); });

            function processAction(type, id) {
                $.post(ajaxurl, { action: 'sr_email_action', type: type, id: id, nonce: '<?php echo wp_create_nonce("sr_admin_nonce"); ?>' }, function(res){
                    if(res.success) location.reload(); else alert(res.data && res.data.message ? res.data.message : 'Unable to update request.');
                }).fail(function(xhr){ alert(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to update request.'); });
            }

            $('.sr-close-modal, .sr-modal').click(function(e){ if(e.target === this || $(this).hasClass('sr-close-modal')) $('.sr-modal:visible').each(function(){window.srDialog.close($(this));}); });
        });
        </script>

        <style>
            .sr-icon-btn { background:none; border:none; cursor:pointer; font-size:14px; padding:5px; color:#64748b; transition:color 0.2s; }
            .sr-icon-btn:hover { color:#1e293b; }
            .sr-modal-panel.large { max-width: 800px; width:90%; height:auto; }
        </style>
        <?php
    }

    /**
     * Determines Retail vs Wholesale for the "Customer Type" column, based on the
     * registered customer's WordPress role. WooCommerce Wholesale Pro (Wholesale Suite / WWPP)
     * assigns roles like 'wholesale_customer' and, with tiered pricing, variants such as
     * 'wholesale_customer_tier_2' — always prefixed "wholesale" — so we match on that prefix
     * rather than one hardcoded role slug. Guest checkouts and non-wholesale accounts default
     * to Retail.
     */
    private static function get_customer_type( $order ) {
        $user_id = $order->get_customer_id();
        if ( $user_id ) {
            $user = get_userdata( $user_id );
            if ( $user ) {
                foreach ( $user->roles as $role ) {
                    if ( stripos( $role, 'wholesale' ) !== false ) {
                        return 'wholesale';
                    }
                }
            }
        }
        return 'retail';
    }

    /**
     * Looks up whether this email address has already left any review (matched by author
     * email, not restricted to the specific product on this order) — so Manual Send can show
     * it and let an admin skip re-asking someone who's already reviewed.
     * Returns null when there's no review, or ['count' => n, 'avg' => x.x] when there is.
     */
    private static function get_existing_review_info( $email ) {
        if ( empty( $email ) || ! is_email( $email ) ) return null;

        $comments = get_comments( [
            'type'         => 'review',
            'author_email' => $email,
            'status'       => 'approve,hold',
            'parent'       => 0,
        ] );
        if ( empty( $comments ) ) return null;

        $sum = 0; $count = 0;
        foreach ( $comments as $c ) {
            $r = (int) get_comment_meta( $c->comment_ID, 'rating', true );
            if ( $r > 0 ) { $sum += $r; $count++; }
        }
        return [ 'count' => count( $comments ), 'avg' => $count ? round( $sum / $count, 1 ) : 0 ];
    }

    /**
     * MANUAL SEND TAB
     * Two modes:
     * - "new": orders never marked Completed in WooCommerce, so the automatic review
     *   request never fired for them. Sends the level-1 request immediately.
     * - "cs": orders that already got the full automatic/manual sequence (first request,
     *   and the follow-up too if it's enabled) but haven't been asked a dedicated
     *   "how was our customer service" question yet. Sends a level-3 request.
     * Neither mode touches the order's status, so neither can trigger a WooCommerce status email.
     */
    private static function render_manual_ui() {
        global $wpdb;
        $table = $wpdb->prefix . 'sr_requests';
        $per_page = 20;

        $mode   = ( isset( $_GET['mode'] ) && $_GET['mode'] === 'cs' ) ? 'cs' : 'new';
        $search = isset( $_GET['ms'] ) ? sanitize_text_field( $_GET['ms'] ) : '';
        $paged  = isset( $_GET['pg'] ) ? max( 1, intval( $_GET['pg'] ) ) : 1;
        $hide_reviewed = isset( $_GET['hide_reviewed'] ) && $_GET['hide_reviewed'] === '1';

        $orders = [];
        $total_pages = 1;
        $requested_map = []; // 'new' mode: order_id => existing level-1 row.
        $first_sent_map = []; // 'cs' mode: order_id => level-1 sent_date.

        if ( $mode === 'new' ) {
            // Any order status except the ones that mean "done" or "dead" is fair game here.
            $all_statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : [];
            $excluded     = [ 'wc-completed', 'wc-cancelled', 'wc-refunded', 'wc-failed', 'wc-checkout-draft', 'wc-trash' ];
            $open_statuses = [];
            foreach ( array_keys( $all_statuses ) as $slug ) {
                if ( in_array( $slug, $excluded, true ) ) continue;
                $open_statuses[] = str_replace( 'wc-', '', $slug );
            }

            if ( $search !== '' && is_numeric( $search ) ) {
                $o = wc_get_order( intval( $search ) );
                if ( $o && in_array( $o->get_status(), $open_statuses, true ) ) $orders = [ $o ];
            } elseif ( function_exists( 'wc_get_orders' ) ) {
                $args = [
                    'limit'    => $per_page,
                    'page'     => $paged,
                    'status'   => $open_statuses,
                    'orderby'  => 'date',
                    'order'    => 'DESC',
                    'return'   => 'objects',
                    'paginate' => true,
                ];
                if ( $search !== '' ) $args['billing_email'] = $search;
                $result = wc_get_orders( $args );
                $orders = $result->orders;
                $total_pages = max( 1, (int) $result->max_num_pages );
            }

            // Applied to the current page only (not re-queried against WooCommerce), so a page can
            // come back shorter than $per_page when some of its orders get filtered out here.
            if ( $hide_reviewed && ! empty( $orders ) ) {
                $orders = array_values( array_filter( $orders, function( $o ) {
                    return ! self::get_existing_review_info( $o->get_billing_email() );
                } ) );
            }

            // Look up which of these orders already have a first-request row (sent OR still pending).
            $order_ids = array_map( function( $o ) { return $o->get_id(); }, $orders );
            if ( ! empty( $order_ids ) ) {
                $placeholder = implode( ',', array_fill( 0, count( $order_ids ), '%d' ) );
                $rows = $wpdb->get_results( $wpdb->prepare( "SELECT order_id, status FROM $table WHERE level = 1 AND order_id IN ($placeholder)", $order_ids ) );
                foreach ( $rows as $r ) $requested_map[ $r->order_id ] = $r;
            }
        } else {
            // 'cs' mode: level-1 sent, and no level-2 still queued (checked per order — NOT against
            // the live sr_enable_followup setting, since that can be toggled long after older
            // orders' first requests already went out, and would otherwise wrongly gate on a
            // follow-up that was never scheduled for them in the first place). An order counts as
            // "done" once level 1 is sent and there's no level-2 currently pending — whether that's
            // because none was ever scheduled, or because one was scheduled and already resolved
            // (sent, failed, or cancelled). No level-3 yet, so we don't ask twice.
            $base_where = "r1.level = 1 AND r1.status = 'sent'
                AND NOT EXISTS (SELECT 1 FROM $table r2 WHERE r2.order_id = r1.order_id AND r2.level = 2 AND r2.status = 'pending')
                AND NOT EXISTS (SELECT 1 FROM $table r3 WHERE r3.order_id = r1.order_id AND r3.level = 3)";

            $order_ids_all = $wpdb->get_col( "SELECT DISTINCT r1.order_id FROM $table r1 WHERE $base_where ORDER BY r1.id DESC" );
            $orders_all = array_filter( array_map( 'wc_get_order', $order_ids_all ) );

            if ( $search !== '' ) {
                $orders_all = array_values( array_filter( $orders_all, function( $o ) use ( $search ) {
                    if ( is_numeric( $search ) ) return (string) $o->get_id() === (string) intval( $search );
                    return stripos( $o->get_billing_email(), $search ) !== false;
                } ) );
            }

            if ( $hide_reviewed ) {
                $orders_all = array_values( array_filter( $orders_all, function( $o ) {
                    return ! self::get_existing_review_info( $o->get_billing_email() );
                } ) );
            }

            $total = count( $orders_all );
            $total_pages = max( 1, (int) ceil( $total / $per_page ) );
            $paged = min( $paged, $total_pages );
            $orders = array_slice( $orders_all, ( $paged - 1 ) * $per_page, $per_page );

            $order_ids = array_map( function( $o ) { return $o->get_id(); }, $orders );
            if ( ! empty( $order_ids ) ) {
                $placeholder = implode( ',', array_fill( 0, count( $order_ids ), '%d' ) );
                $rows = $wpdb->get_results( $wpdb->prepare( "SELECT order_id, sent_date FROM $table WHERE level = 1 AND order_id IN ($placeholder)", $order_ids ) );
                foreach ( $rows as $r ) $first_sent_map[ $r->order_id ] = $r->sent_date;
            }
        }
        ?>

        <div style="display:flex; gap:10px; margin-bottom:20px;">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=sr-emails&sub=manual&mode=new' ) ); ?>" class="sr-btn <?php echo $mode === 'new' ? 'blue' : 'white'; ?> sm">Needs First Request</a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=sr-emails&sub=manual&mode=cs' ) ); ?>" class="sr-btn <?php echo $mode === 'cs' ? 'blue' : 'white'; ?> sm">Ready for Customer Service Ask</a>
        </div>

        <div class="sr-card" style="margin-bottom:20px; background:#eff6ff; border-color:#bfdbfe;">
            <p style="margin:0; font-size: 14px; color:#1e40af; line-height:1.6;">
                <i class="sr-icon sr-icon-info" aria-hidden="true"></i>
                <?php if ( $mode === 'new' ) : ?>
                    These orders haven't been marked <strong>Completed</strong> in WooCommerce, so the automatic review request never fired for them.
                    Select any below and send the request right now &mdash; this <strong>does not change the order's status</strong>, so it won't trigger any WooCommerce order emails.
                    If an order is later marked Completed the normal way, it will <strong>not</strong> get a duplicate request.
                <?php else : ?>
                    These customers already received the review request (and its follow-up, if one was scheduled for them), but haven't been asked specifically about their <strong>customer service</strong> experience yet.
                    Select any below to send that ask now. Customize its subject/body under Templates &amp; Settings &rarr; Customer Service Request.
                <?php endif; ?>
            </p>
        </div>

        <div class="sr-toolbar" style="justify-content:space-between;">
            <div class="sr-bulk-actions" style="display:flex; gap:10px; align-items:center;">
                <button type="button" class="sr-btn blue" id="sr-manual-send-btn" data-level="<?php echo $mode === 'cs' ? 3 : 1; ?>">
                    <i class="sr-icon sr-icon-send" aria-hidden="true"></i> <?php echo $mode === 'cs' ? 'Send Customer Service Request Now' : 'Send Review Request Now'; ?>
                </button>
            </div>

            <div style="display:flex; align-items:center; gap:16px;">
                <label style="display:flex; align-items:center; gap:6px; font-size: 14px; font-weight:600; color:#64748b; white-space:nowrap; margin:0; text-transform:none; letter-spacing:normal;">
                    <input type="checkbox" id="sr-hide-reviewed" <?php checked( $hide_reviewed ); ?> style="margin:0;">
                    Hide already reviewed
                </label>

                <div class="sr-search-wrap">
                    <form method="get" id="sr-manual-search-form">
                        <input type="hidden" name="page" value="sr-emails">
                        <input type="hidden" name="sub" value="manual">
                        <input type="hidden" name="mode" value="<?php echo esc_attr( $mode ); ?>">
                        <input type="hidden" name="hide_reviewed" id="sr-hide-reviewed-input" value="<?php echo $hide_reviewed ? '1' : ''; ?>">
                        <i class="sr-icon sr-icon-search" aria-hidden="true"></i>
                        <input type="text" name="ms" placeholder="Search by email or Order ID..." value="<?php echo esc_attr( $search ); ?>">
                    </form>
                </div>
            </div>
        </div>

        <div class="sr-table-card">
            <table class="sr-table">
                <thead>
                    <tr>
                        <th width="30"><input type="checkbox" id="sr-manual-select-all"></th>
                        <th>Order</th>
                        <th>Customer</th>
                        <th>Customer Type</th>
                        <th>Has Reviewed</th>
                        <th>Order Status</th>
                        <th><?php echo $mode === 'cs' ? 'First Request Sent' : 'Order Date'; ?></th>
                        <th width="160"><?php echo $mode === 'cs' ? 'CS Request' : 'Review Request'; ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $orders ) ): ?>
                        <tr><td colspan="8" style="text-align:center; padding:40px; color:#94a3b8;"><?php echo $mode === 'cs' ? 'No orders are ready for a Customer Service ask right now.' : 'No open orders found.'; ?></td></tr>
                    <?php else: foreach ( $orders as $order ):
                        $oid = $order->get_id();
                        $ctype = self::get_customer_type( $order );
                        $review_info = self::get_existing_review_info( $order->get_billing_email() );

                        if ( $mode === 'new' ) {
                            $already = isset( $requested_map[ $oid ] ) ? $requested_map[ $oid ] : null;
                            $created = $order->get_date_created();
                            $date_display = $created ? esc_html( $created->date( 'M j, Y' ) ) : '';
                        } else {
                            $already = false; // 'cs' mode is pre-filtered to only unsent-level-3 orders.
                            $sent_date = isset( $first_sent_map[ $oid ] ) ? $first_sent_map[ $oid ] : '';
                            $date_display = $sent_date ? esc_html( date_i18n( 'M j, Y', strtotime( $sent_date ) ) ) : '&mdash;';
                        }
                    ?>
                        <tr>
                            <td><?php if ( ! $already ): ?><input type="checkbox" class="sr-manual-cb" value="<?php echo esc_attr( $oid ); ?>"><?php endif; ?></td>
                            <td><a href="<?php echo admin_url( 'post.php?post=' . $oid . '&action=edit' ); ?>">#<?php echo esc_html( $oid ); ?></a></td>
                            <td>
                                <strong><?php echo esc_html( trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ); ?></strong><br>
                                <span style="font-size: 14px; color:#64748b;"><?php echo esc_html( $order->get_billing_email() ); ?></span>
                            </td>
                            <td><span class="sr-status-badge <?php echo esc_attr( $ctype ); ?>"><?php echo esc_html( ucfirst( $ctype ) ); ?></span></td>
                            <td>
                                <?php if ( $review_info ): ?>
                                    <div class="sr-stars-static sr-small" style="--v:<?php echo esc_attr( $review_info['avg'] ); ?>"></div>
                                    <span style="font-size: 14px; color:#64748b;"><?php echo esc_html( $review_info['count'] ); ?> review<?php echo $review_info['count'] > 1 ? 's' : ''; ?></span>
                                <?php else: ?>
                                    <span style="color:#cbd5e1; font-size: 14px;">&mdash;</span>
                                <?php endif; ?>
                            </td>
                            <td><span class="sr-status-badge hold"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span></td>
                            <td><?php echo $date_display; ?></td>
                            <td>
                                <?php if ( $already ): ?>
                                    <span class="sr-status-badge approved"><?php echo esc_html( ucfirst( $already->status ) ); ?></span>
                                <?php elseif ( $mode === 'cs' ): ?>
                                    <span style="color:#2563eb; font-size: 14px; font-weight:600;">Ready to send</span>
                                <?php else: ?>
                                    <span style="color:#94a3b8; font-size: 14px;">Not sent yet</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>

        <?php self::render_pagination( $paged, $total_pages ); ?>

        <div id="sr-manual-confirm-modal" class="sr-modal">
            <div class="sr-modal-panel small">
                <div class="sr-modal-head"><h3 id="sr-manual-confirm-title">Send Review Requests?</h3><button type="button" class="sr-close-modal" aria-label="Close dialog"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button></div>
                <div class="sr-modal-body">
                    <p id="sr-manual-confirm-text">This will immediately email the selected customers. It will not change their order status in WooCommerce.</p>
                </div>
                <div class="sr-modal-foot">
                    <button class="sr-btn white sr-close-modal">Cancel</button>
                    <button class="sr-btn blue" id="sr-manual-confirm-send">Yes, Send Now</button>
                </div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($){
            var sendLevel = parseInt($('#sr-manual-send-btn').data('level'), 10) || 1;
            var isCs = sendLevel === 3;

            $('#sr-manual-select-all').on('change', function(){
                $('.sr-manual-cb').prop('checked', $(this).is(':checked'));
            });

            $('#sr-hide-reviewed').on('change', function(){
                $('#sr-hide-reviewed-input').val($(this).is(':checked') ? '1' : '');
                $('#sr-manual-search-form')[0].submit();
            });

            $('#sr-manual-send-btn').click(function(){
                var ids = [];
                $('.sr-manual-cb:checked').each(function(){ ids.push($(this).val()); });
                if (ids.length === 0) { alert('Please select at least one order.'); return; }
                var noun = isCs ? 'customer service request' : 'review request';
                $('#sr-manual-confirm-title').text(isCs ? 'Send Customer Service Requests?' : 'Send Review Requests?');
                $('#sr-manual-confirm-text').text('This will immediately email the ' + noun + ' to ' + ids.length + ' customer(s). It will not change their order status in WooCommerce.');
                window.srDialog.open($('#sr-manual-confirm-modal'));
            });

            $('#sr-manual-confirm-send').click(function(){
                var ids = [];
                $('.sr-manual-cb:checked').each(function(){ ids.push($(this).val()); });
                var btn = $(this); btn.text('Sending...').prop('disabled', true);

                $.post(ajaxurl, {
                    action: 'sr_manual_send_bulk',
                    order_ids: ids,
                    level: sendLevel,
                    nonce: '<?php echo wp_create_nonce( "sr_admin_nonce" ); ?>'
                }, function(res){
                    btn.text('Yes, Send Now').prop('disabled', false);
                    $('.sr-modal:visible').each(function(){window.srDialog.close($(this));});
                    if (res.success) {
                        alert(res.data.message);
                        location.reload();
                    } else {
                        alert(res.data && res.data.message ? res.data.message : 'Error sending requests.');
                    }
                }).fail(function(xhr){ btn.text('Yes, Send Now').prop('disabled', false); alert(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to send requests. Check the log before retrying.'); });
            });

            $('.sr-close-modal, .sr-modal').click(function(e){ if(e.target === this || $(this).hasClass('sr-close-modal')) $('.sr-modal:visible').each(function(){window.srDialog.close($(this));}); });
        });
        </script>
        <?php
    }

    /**
     * SETTINGS TAB (With Preview & Tester)
     */
    private static function render_settings_ui() {
        $body1_default = "Hi {name},\n\nThanks for your purchase! We'd love to hear your thoughts.\n\nPlease review your items:\n{products}";
        $body1_val = get_option( 'sr_body_1', $body1_default );

        // Colors for Preview
        $header_bg = get_option('sr_color_admin', '#2563eb');
        $btn_bg    = get_option('sr_color_widget', '#2563eb');

        // Logo Options
        $logo_enabled = get_option( 'sr_email_logo_enabled', 0 );
        $logo_url     = get_option( 'sr_email_logo_url', '' );
        $logo_height  = get_option( 'sr_email_logo_height', '40' );
        ?>
        <form id="sr-email-settings-form">
            <input type="hidden" name="sr_settings_group" value="email">
            <div class="sr-settings-grid">

                <div class="sr-col-left" style="display:flex; flex-direction:column; gap:20px;">

                    <div class="sr-card">
                        <h3>Targeting Rules</h3>
                        <p style="font-size: 14px; color:#64748b; margin-bottom:15px;">Control which products trigger emails.</p>

                        <label style="font-size: 14px; font-weight: 600; display: block; margin-bottom: 8px;">Only Include Specific Products</label>
                        <p style="font-size: 14px; color:#64748b; margin-bottom:10px;">If added, <strong>ONLY</strong> these products will trigger emails. Leave empty to target all products.</p>

                        <input type="hidden" name="sr_included_products" id="sr-included-ids" value="<?php echo esc_attr( get_option( 'sr_included_products' ) ); ?>">

                        <div style="position: relative; margin-bottom: 10px;">
                            <input type="text" id="sr-inc-prod-search" placeholder="Type product name to add..." autocomplete="off"
                                   style="width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px;">

                            <div id="sr-inc-search-results" style="display: none; position: absolute; top: 100%; left: 0; right: 0;
                                 background: #fff; border: 1px solid #cbd5e1; border-radius: 0 0 6px 6px;
                                 box-shadow: 0 4px 6px rgba(0,0,0,0.1); z-index: 10; max-height: 200px; overflow-y: auto;">
                            </div>
                        </div>

                        <div id="sr-inc-selected-list" style="display: flex; flex-wrap: wrap; gap: 8px; margin-bottom:10px;">
                            <?php
                            $saved_ids = get_option( 'sr_included_products' );
                            if ( ! empty( $saved_ids ) ) {
                                $ids = explode( ',', $saved_ids );
                                foreach ( $ids as $id ) {
                                    $id = intval( trim( $id ) );
                                    if ( $id ) {
                                        $title = get_the_title( $id );
                                        if ( ! $title ) $title = 'Unknown Product';
                                        $short_title = strlen($title) > 25 ? substr($title, 0, 25) . '...' : $title;
                                        echo '<div class="sr-prod-tag inc-tag" data-id="'.$id.'"><span class="sr-tag-id">ID: '.$id.'</span><span class="sr-tag-name">'.esc_html( $short_title ).'</span><button type="button" class="sr-tag-remove" aria-label="Remove product"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button></div>';
                                    }
                                }
                            }
                            ?>
                        </div>
                    </div>

                    <div class="sr-card">
                        <h3>First Request</h3>
                        <div style="margin-bottom:15px;">
                            <label>Send Delay (Days)</label>
                            <input type="number" name="sr_delay_1" value="<?php echo esc_attr( get_option( 'sr_delay_1', 5 ) ); ?>" min="0" style="width:80px;">
                            <span style="font-size: 14px; color:#64748b;">Set to <strong>0</strong> for immediate.</span>
                        </div>
                        <div style="margin-bottom:15px;">
                            <label>Subject</label>
                            <input type="text" name="sr_subject_1" value="<?php echo esc_attr( get_option( 'sr_subject_1', 'How was your experience?' ) ); ?>">
                        </div>
                        <label>Email Body</label>
                        <textarea name="sr_body_1" id="body1" rows="8"><?php echo esc_textarea( $body1_val ); ?></textarea>
                        <div style="background:#f1f5f9; padding:10px; border-radius:6px; margin-top:8px; font-size: 14px; color:#475569; line-height:1.6;">
                            <strong>Available Tags:</strong><br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{first_name}</code> - Customer First Name<br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{last_name}</code> - Customer Last Name<br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{order_id}</code> - Order Number<br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{shop_name}</code> - Website Name<br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{order_table}</code> - Product List with Images & Buttons
                        </div>
                    </div>

                    <div class="sr-card">
                        <div class="sr-toggle-row">
                            <h3>Follow-up Email</h3>
                            <div style="display:flex; align-items:center; gap:5px;">
                                <input type="checkbox" name="sr_enable_followup" value="1" <?php checked( 1, get_option( 'sr_enable_followup' ) ); ?>>
                                <label style="margin:0; font-size: 14px;">Enable</label>
                            </div>
                        </div>
                        <div style="margin-bottom:15px;">
                            <label>Send Delay (Days)</label>
                            <input type="number" name="sr_delay_2" value="<?php echo esc_attr( get_option( 'sr_delay_2', 3 ) ); ?>" min="0" style="width:80px;">
                        </div>
                        <div style="margin-bottom:15px;">
                            <label>Subject</label>
                            <input type="text" name="sr_subject_2" value="<?php echo esc_attr( get_option( 'sr_subject_2', 'Just a reminder' ) ); ?>">
                        </div>
                        <label>Email Body</label>
                        <textarea name="sr_body_2" id="body2" rows="6"><?php echo esc_textarea( get_option( 'sr_body_2', SR_Cron::defaults( 2 )['body'] ) ); ?></textarea>
                    </div>

                    <div class="sr-card">
                        <h3>Customer Service Request</h3>
                        <p style="font-size: 14px; color:#64748b; margin-bottom:15px;">Manual only &mdash; sent from Emails &gt; Manual Send &gt; "Ready for Customer Service Ask" to customers who already got the request above. Not part of the automatic sequence.</p>
                        <div style="margin-bottom:15px;">
                            <label>Subject</label>
                            <input type="text" name="sr_subject_3" value="<?php echo esc_attr( get_option( 'sr_subject_3', 'How did we do?' ) ); ?>">
                        </div>
                        <label>Email Body</label>
                        <textarea name="sr_body_3" id="body3" rows="8"><?php echo esc_textarea( get_option( 'sr_body_3', "Hi {name},\n\nWe'd love to know how our team took care of you during your recent order. Got a minute to share your experience?\n\n{order_table}" ) ); ?></textarea>
                        <div style="background:#f1f5f9; padding:10px; border-radius:6px; margin-top:8px; font-size: 14px; color:#475569; line-height:1.6;">
                            <strong>Available Tags:</strong><br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{first_name}</code> - Customer First Name<br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{last_name}</code> - Customer Last Name<br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{order_id}</code> - Order Number<br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{shop_name}</code> - Website Name<br>
                            <code style="background:#e2e8f0; padding:2px 5px; border-radius:4px;">{order_table}</code> - Product List with Images &amp; Buttons &mdash; remove this tag if you'd rather send plain text with no button.
                        </div>
                    </div>
                </div>

                <div class="sr-col-right" style="display:flex; flex-direction:column; gap:20px;">

                    <div class="sr-card">
                        <h3>Email Design</h3>
                        <label style="margin-bottom:10px; display:block; font-weight:600; font-size: 14px;">Template Style</label>
                        <select name="sr_email_template_type" id="sr_email_template_type" style="width:100%; margin-bottom:15px;">
                            <option value="modern" <?php selected( get_option('sr_email_template_type'), 'modern' ); ?>>Starboard Modern (Recommended)</option>
                            <option value="woocommerce" <?php selected( get_option('sr_email_template_type'), 'woocommerce' ); ?>>WooCommerce Default</option>
                        </select>

                        <div style="border-top:1px solid #e2e8f0; padding-top:15px;">
                            <div class="sr-toggle-row" style="margin-bottom:10px;">
                                <label style="font-weight:600; font-size: 14px;">Use Site Logo</label>
                                <input type="checkbox" name="sr_email_logo_enabled" id="sr_email_logo_enabled" value="1" <?php checked( 1, $logo_enabled ); ?>>
                            </div>

                            <div id="sr-logo-settings" style="display: <?php echo $logo_enabled ? 'block' : 'none'; ?>;">
                                <div style="margin-bottom:10px;">
                                    <label style="font-size: 14px; color:#64748b;">Logo URL</label>
                                    <input type="text" name="sr_email_logo_url" id="sr_email_logo_url" value="<?php echo esc_attr( $logo_url ); ?>" placeholder="https://..." style="width:100%;">
                                </div>
                                <div>
                                    <label style="font-size: 14px; color:#64748b;">Logo Height (px)</label>
                                    <input type="number" name="sr_email_logo_height" id="sr_email_logo_height" value="<?php echo esc_attr( $logo_height ); ?>" style="width:80px;">
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="sr-card" style="border-color:#cbd5e1; background:#f8fafc; overflow:hidden;">
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                            <h3 style="margin:0;"><i class="sr-icon sr-icon-eye" aria-hidden="true"></i> Live Preview</h3>

                            <div class="sr-preview-toggle">
                                <label>
                                    <input type="radio" name="preview_mode" value="1" checked>
                                    <span>Request #1</span>
                                </label>
                                <label>
                                    <input type="radio" name="preview_mode" value="2">
                                    <span>Follow-up</span>
                                </label>
                                <label>
                                    <input type="radio" name="preview_mode" value="3">
                                    <span>Customer Service</span>
                                </label>
                            </div>
                        </div>

                        <div id="sr-preview-container" style="background:#fff; border:1px solid #e2e8f0; border-radius:6px; overflow:hidden; min-height:300px;">
                            </div>
                        <p style="font-size: 14px; color:#94a3b8; margin-top:10px; text-align:center;">*Actual rendering may vary slightly by email client.</p>
                    </div>

                    <div class="sr-card">
                        <h3><i class="sr-icon sr-icon-send" aria-hidden="true"></i> Send Test</h3>
                        <p style="font-size: 14px; color:#64748b; margin-bottom:15px;">Check mail delivery with a plain text test message.</p>
                        <input type="email" id="test_email_addr" value="<?php echo esc_attr( wp_get_current_user()->user_email ); ?>" placeholder="Enter email address..." style="margin-bottom:10px;">
                        <button type="button" id="sr_send_test" class="sr-btn blue full" style="justify-content:center;">Send Test Email</button>
                    </div>
                </div>

            </div>

            <div class="sr-sticky-foot">
                <button type="button" class="sr-btn blue" id="sr-save-email-settings">Save Settings</button>
            </div>
        </form>

        <style>
            .sr-prod-tag { background: #eff6ff; border: 1px solid #bfdbfe; color: #1e40af; border-radius: 4px; padding: 4px 8px; font-size: 14px; display: flex; align-items: center; gap: 6px; cursor: default; }
            .sr-prod-tag.inc-tag { background: #f0fdf4; border-color: #bbf7d0; color: #166534; }
            .sr-tag-remove { cursor: pointer; font-weight: bold; font-size: 14px; opacity: 0.6; margin-left: 4px; line-height: 1; }
            .sr-tag-remove:hover { opacity: 1; color: #ef4444; }
            .sr-search-item { padding: 8px 12px; cursor: pointer; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
            .sr-search-item:hover { background: #f8fafc; color: #2563eb; }

            /* Toggle Style */
            .sr-preview-toggle { background:#e2e8f0; padding:3px; border-radius:6px; display:flex; }
            .sr-preview-toggle label { margin:0; cursor:pointer; }
            .sr-preview-toggle input { display:none; }
            .sr-preview-toggle span { display:block; padding:4px 12px; font-size: 14px; font-weight:600; border-radius:4px; color:#64748b; transition:0.2s; }
            .sr-preview-toggle input:checked + span { background:#fff; color:#2563eb; box-shadow:0 1px 2px rgba(0,0,0,0.1); }
        </style>

        <script>
        jQuery(document).ready(function($){

            // --- CONSTANTS FOR PREVIEW ---
            const SHOP_NAME = '<?php echo esc_js( get_bloginfo( 'name' ) ); ?>';
            const BRAND_COLOR = '<?php echo esc_js( $header_bg ); ?>';
            const BTN_COLOR = '<?php echo esc_js( $btn_bg ); ?>';

            // Fake Product Table HTML - USING INLINE STYLES FOR PREVIEW CONSISTENCY
            const FAKE_TABLE = `
                <div style="background:#fff; border:1px solid #e5e7eb; border-radius:8px; overflow:hidden; margin-top:15px;">
                    <table width="100%" cellspacing="0" cellpadding="0" border="0" style="border-bottom:1px solid #f3f4f6;">
                        <tr>
                            <td width="80" style="padding:15px 0 15px 15px;">
                                <div style="width:60px; height:60px; background:#e2e8f0; border-radius:6px;"></div>
                            </td>
                            <td style="padding:15px 10px; vertical-align:middle;">
                                <div style="font-family:sans-serif; font-weight:600; color:#111827; font-size:15px;">Premium T-Shirt</div>
                                <div style="font-family:sans-serif; font-size: 14px; color:#6b7280; margin-top:4px;">$25.00</div>
                            </td>
                            <td width="100" align="right" style="padding:15px 15px 15px 0; vertical-align:middle;">
                                <a href="#" style="background:${BTN_COLOR}; color:#fff; text-decoration:none; padding:8px 18px; border-radius:6px; font-size: 14px; font-weight:600; display:inline-block; font-family:sans-serif;">Review</a>
                            </td>
                        </tr>
                    </table>
                    <table width="100%" cellspacing="0" cellpadding="0" border="0">
                        <tr>
                            <td width="80" style="padding:15px 0 15px 15px;">
                                <div style="width:60px; height:60px; background:#e2e8f0; border-radius:6px;"></div>
                            </td>
                            <td style="padding:15px 10px; vertical-align:middle;">
                                <div style="font-family:sans-serif; font-weight:600; color:#111827; font-size:15px;">Coffee Mug</div>
                                <div style="font-family:sans-serif; font-size: 14px; color:#6b7280; margin-top:4px;">$12.00</div>
                            </td>
                            <td width="100" align="right" style="padding:15px 15px 15px 0; vertical-align:middle;">
                                <a href="#" style="background:${BTN_COLOR}; color:#fff; text-decoration:none; padding:8px 18px; border-radius:6px; font-size: 14px; font-weight:600; display:inline-block; font-family:sans-serif;">Review</a>
                            </td>
                        </tr>
                    </table>
                </div>`;

            // Function: Update Preview
            function updatePreview() {
                // 1. Get Inputs
                var mode = $('input[name="preview_mode"]:checked').val();
                var rawText = (mode === '1') ? $('#body1').val() : (mode === '2' ? $('#body2').val() : $('#body3').val());
                var template = $('#sr_email_template_type').val();

                // Logo Vars
                var useLogo = $('#sr_email_logo_enabled').is(':checked');
                var logoUrl = $('#sr_email_logo_url').val();
                var logoH   = $('#sr_email_logo_height').val();

                // 2. Perform NL2BR FIRST to avoid breaking the table HTML later
                var content = rawText.replace(/\n/g, '<br>');

                // 3. Perform Variable Replacements
                content = content
                    .replace(/{first_name}|{name}/g, '<strong>John</strong>')
                    .replace(/{last_name}/g, '<strong>Doe</strong>')
                    .replace(/{order_id}/g, '#12345')
                    .replace(/{shop_name}/g, SHOP_NAME);

                // 4. Inject Table LAST (so regex doesn't mess it up)
                content = content.replace(/{order_table}|{products}/g, FAKE_TABLE);

                // 5. Header Logic
                var headerContent = `<h2 style="margin:0; color:#ffffff; font-size:20px; font-weight:600;">${SHOP_NAME}</h2>`;
                if(useLogo && logoUrl) {
                    headerContent = `<img src="${logoUrl}" style="height:${logoH}px; width:auto; display:block; margin:0 auto; border:0;">`;
                }

                // 6. Wrap based on Template Style
                var finalHtml = '';

                if (template === 'modern') {
                    // --- MODERN CARD PREVIEW ---
                    finalHtml = `
                    <div style="background-color:#f3f4f6; padding:20px; font-family:sans-serif;">
                        <div style="max-width:100%; margin:0 auto; background:#ffffff; border-radius:8px; overflow:hidden; box-shadow:0 4px 6px -1px rgba(0,0,0,0.05);">
                            <div style="background-color:${BRAND_COLOR}; padding:30px; text-align:center;">
                                ${headerContent}
                            </div>
                            <div style="padding:30px; color:#374151; line-height:1.6; font-size:15px;">
                                ${content}
                            </div>
                            <div style="padding:15px; text-align:center; background:#f9fafb; color:#9ca3af; font-size: 14px;">
                                &copy; 2026 ${SHOP_NAME}. All rights reserved.
                            </div>
                        </div>
                    </div>`;
                } else {
                    // --- WOOCOMMERCE / SIMPLE PREVIEW ---
                    finalHtml = `
                    <div style="padding:20px; font-family:sans-serif; color:#333; line-height:1.6;">
                        <div style="border-bottom:1px solid #eee; padding-bottom:10px; margin-bottom:15px; font-weight:bold; color:${BRAND_COLOR};">
                            Subject: ${(mode === '1' ? $('input[name="sr_subject_1"]').val() : (mode === '2' ? $('input[name="sr_subject_2"]').val() : $('input[name="sr_subject_3"]').val()))}
                        </div>
                        ${content}
                    </div>`;
                }

                $('#sr-preview-container').html(finalHtml);
            }

            // Listeners
            $('#body1, #body2, #body3, input[name="sr_subject_1"], input[name="sr_subject_2"], input[name="sr_subject_3"]').on('input', updatePreview);
            $('input[name="preview_mode"]').on('change', updatePreview);
            $('#sr_email_template_type').on('change', updatePreview);

            // Logo Listeners
            $('#sr_email_logo_enabled').on('change', function(){
                if($(this).is(':checked')) $('#sr-logo-settings').slideDown(200); else $('#sr-logo-settings').slideUp(200);
                updatePreview();
            });
            $('#sr_email_logo_url, #sr_email_logo_height').on('input', updatePreview);

            // Init
            updatePreview();

            // --- EXISTING SEARCH LOGIC (Keep included) ---
            var searchTimer;
            $('#sr-inc-prod-search').on('keyup', function(){
                clearTimeout(searchTimer);
                var term = $(this).val();
                var resBox = $('#sr-inc-search-results');
                if(term.length < 2) { resBox.hide(); return; }
                searchTimer = setTimeout(function(){
                    $.ajax({
                        url: ajaxurl,
                        data: { action: 'sr_search_products', term: term, nonce: '<?php echo wp_create_nonce( "sr_admin_nonce" ); ?>' },
                        success: function(res) {
                            if(res.success && res.data.length > 0) {
                                var html = '';
                                res.data.forEach(function(item){ html += '<div class="sr-search-item" data-id="'+item.id+'" data-html="'+item.text.replace(/"/g, '&quot;')+'">' + item.text + '</div>'; });
                                resBox.html(html).show();
                            } else { resBox.hide(); }
                        }
                    });
                }, 300);
            });
            $(document).on('click', '#sr-inc-search-results .sr-search-item', function(){
                var id = $(this).data('id');
                var rawText = $(this).html();
                var tempDiv = document.createElement("div"); tempDiv.innerHTML = rawText;
                var cleanText = tempDiv.textContent || tempDiv.innerText || "";
                var nameOnly = cleanText.replace(/\[ID: \d+\]\s*/, '');
                var exists = false;
                $('.sr-prod-tag.inc-tag').each(function(){ if($(this).data('id') == id) exists = true; });
                if(exists) { alert('Product already in list.'); return; }
                var html = `<div class="sr-prod-tag inc-tag" data-id="${id}"><span class="sr-tag-id">ID: ${id}</span><span class="sr-tag-name">${$('<div>').text(nameOnly).html()}</span><button type="button" class="sr-tag-remove" aria-label="Remove product"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button></div>`;
                $('#sr-inc-selected-list').append(html);
                var ids = []; $('.sr-prod-tag.inc-tag').each(function(){ ids.push($(this).data('id')); }); $('#sr-included-ids').val(ids.join(','));
                $('#sr-inc-prod-search').val(''); $('#sr-inc-search-results').hide();
            });
            $(document).on('click', '#sr-inc-selected-list .sr-tag-remove', function(){
                $(this).closest('.sr-prod-tag').remove();
                var ids = []; $('.sr-prod-tag.inc-tag').each(function(){ ids.push($(this).data('id')); }); $('#sr-included-ids').val(ids.join(','));
            });
            $(document).click(function(e) { if (!$(e.target).closest('#sr-inc-prod-search, #sr-inc-search-results').length) { $('#sr-inc-search-results').hide(); } });
        });
        </script>
        <?php
    }
}
?>
