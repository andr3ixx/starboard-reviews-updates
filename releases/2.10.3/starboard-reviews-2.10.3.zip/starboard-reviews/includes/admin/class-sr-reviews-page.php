<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SR_Reviews_Page {

    public static function render() {
        if ( ! current_user_can( 'moderate_comments' ) ) wp_die( 'Permission denied.', '', [ 'response' => 403 ] );
        // Fetch products for the dropdown
        $products = get_posts(['post_type' => 'product', 'numberposts' => -1, 'post_status' => 'publish']);
        ?>
        <div class="sr-wrap">
            <?php SR_Brand::header( 'reviews' ); ?>
            <div class="sr-top-bar">
                <div class="sr-title-group">
                    <p class="sr-eyebrow">STARBOARD REVIEWS</p><h1>Reviews</h1><p class="sr-page-description">A clearer view of what your customers are saying.</p>
                </div>
                <div class="sr-actions">
                    <button class="sr-btn white" id="btn-export">Export CSV</button>
                    <button class="sr-btn white" onclick="srOpenModal('#sr-import-modal')">Import</button>
                    <button class="sr-btn blue" id="sr-add-review" onclick="srOpenEdit(null)"><span class="sr-icon sr-icon-plus" aria-hidden="true"></span> Add review</button>
                </div>
            </div>

            <div id="sr-stats-container" class="sr-stats-box">
                Loading stats...
            </div>

            <div class="sr-toolbar">
                <div class="sr-search-wrap">
                    <i class="sr-icon sr-icon-search" aria-hidden="true"></i>
                    <input type="search" aria-label="Search reviews" id="sr-search" placeholder="Search reviews by content, author, or email...">
                </div>

                <div class="sr-filter-group">
                    <div class="sr-date-range">
                        <input type="text" aria-label="Reviews from date" id="sr-date-from" placeholder="Start Date" readonly autocomplete="off">
                        <span class="sr-sep">-</span>
                        <input type="text" aria-label="Reviews to date" id="sr-date-to" placeholder="End Date" readonly autocomplete="off">
                    </div>

                    <select id="sr-sort" aria-label="Sort reviews">
                        <option value="newest">Newest First</option>
                        <option value="oldest">Oldest First</option>
                        <option value="highest">Highest Rating</option>
                        <option value="lowest">Lowest Rating</option>
                    </select>

                    <button class="sr-btn white" id="sr-clear-filters">Clear</button>
                </div>
            </div>

            <div class="sr-tabs-nav" id="sr-tabs">
                <a href="#" data-status="all" class="active">All <span id="cnt-all" class="sr-badge-pill">0</span></a>
                <a href="#" data-status="approve">Published <span id="cnt-approve" class="sr-badge-pill">0</span></a>
                <a href="#" data-status="hold">Pending <span id="cnt-hold" class="sr-badge-pill">0</span></a>
                <a href="#" data-status="spam">Spam <span id="cnt-spam" class="sr-badge-pill">0</span></a>
                <a href="#" data-status="trash">Trash <span id="cnt-trash" class="sr-badge-pill">0</span></a>
            </div>

            <div class="sr-bulk-bar" id="sr-review-bulk-bar" hidden>
                <div><strong id="sr-selected-count">0 selected</strong><span class="sr-field-help"> across pages</span></div>
                <div class="sr-actions">
                    <button type="button" class="sr-btn white" id="sr-bulk-publish">Publish</button>
                    <button type="button" class="sr-btn blue" id="sr-bulk-edit-open">Edit selected</button>
                    <button type="button" class="sr-btn danger-quiet" id="sr-bulk-trash">Move to trash</button>
                    <button type="button" class="sr-btn ghost" id="sr-clear-selection">Clear</button>
                </div>
            </div>
            <div class="sr-table-card">
                <table class="sr-table">
                    <thead>
                        <tr>
                            <th class="sr-check-cell"><input type="checkbox" id="sr-select-reviews" aria-label="Select all reviews on this page"></th><th width="120">Status</th>
                            <th>Review</th>
                            <th width="200">Reviewer</th>
                            <th width="150">Product</th>
                            <th width="120">Date</th>
                            <th width="50"></th>
                        </tr>
                    </thead>
                    <tbody id="sr-reviews-list" aria-live="polite">
                        </tbody>
                </table>
            </div>

            <div class="sr-table-footer"><span id="sr-results-caption" class="sr-field-help"></span><nav id="sr-pagination" class="sr-pagination" aria-label="Review pages"></nav></div>
        </div>

        <div id="sr-bulk-review-modal" class="sr-modal" role="dialog" aria-modal="true" aria-labelledby="sr-bulk-title" tabindex="-1">
            <div class="sr-modal-panel small">
                <div class="sr-modal-head"><h2 id="sr-bulk-title">Edit selected reviews</h2><button type="button" class="sr-close-modal" aria-label="Close bulk editor"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button></div>
                <div class="sr-modal-body">
                    <p id="sr-bulk-summary" class="sr-field-help"></p>
                    <form id="sr-bulk-review-form">
                        <label for="sr-bulk-status">Status</label>
                        <select id="sr-bulk-status" name="status"><option value="keep">Keep current status</option><option value="approve">Published</option><option value="hold">Pending moderation</option><option value="spam">Spam</option><option value="trash">Trash</option></select>
                        <label for="sr-bulk-rating">Product rating</label>
                        <select id="sr-bulk-rating" name="rating"><option value="">Keep current rating</option><?php for ( $i=5; $i>=1; $i-- ) echo '<option value="'.$i.'">'.$i.' stars</option>'; ?></select>
                        <label for="sr-bulk-cs">Customer service rating</label>
                        <select id="sr-bulk-cs" name="cs_rating"><option value="">Keep current rating</option><option value="clear">Remove service rating</option><?php for ( $i=5; $i>=1; $i-- ) echo '<option value="'.$i.'">'.$i.' stars</option>'; ?></select>
                        <p class="sr-inline-message" id="sr-bulk-message" role="status"></p>
                    </form>
                </div>
                <div class="sr-modal-foot"><button type="button" class="sr-btn white sr-close-modal">Cancel</button><button type="button" class="sr-btn blue" id="sr-bulk-review-save">Apply changes</button></div>
            </div>
        </div>
        <div id="sr-edit-modal" class="sr-modal">
            <div class="sr-modal-panel">
                <div class="sr-modal-head">
                    <h3 id="modal-title">Manage Review</h3>
                    <button type="button" class="sr-close-modal" aria-label="Close dialog"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button>
                </div>
                <div class="sr-modal-body">
                    <form id="sr_edit_form" enctype="multipart/form-data">
                        <input type="hidden" name="id" id="edit_id">

                        <div class="sr-form-group">
                            <label>Review Title</label>
                            <input type="text" name="title" id="edit_title" class="sr-full-width-input" placeholder="e.g. Excellent Quality">
                        </div>

                        <div class="sr-grid-2">
                            <div>
                                <label>Reviewer Name</label>
                                <input type="text" name="author" id="edit_author" required>
                            </div>
                            <div>
                                <label>Reviewer Email</label>
                                <input type="email" name="email" id="edit_email" required>
                            </div>
                        </div>

                        <div class="sr-grid-2">
                            <div>
                                <label>Product</label>
                                <select name="product_id" id="edit_pid">
                                    <option value="">-- Select Product --</option>
                                    <?php foreach ( $products as $p ) echo '<option value="' . (int) $p->ID . '">' . esc_html( $p->post_title ) . '</option>'; ?>
                                </select>
                            </div>
                            <div>
                                <label>Date</label>
                                <input type="text" name="date" id="edit_date_input" placeholder="YYYY-MM-DD">
                            </div>
                        </div>

                        <div style="margin-bottom:15px;">
                            <label>Rating</label>
                            <div class="sr-star-select-row">
                                <?php for ( $i = 5; $i >= 1; $i-- ) : ?>
                                    <label>
                                        <input type="radio" name="rating" value="<?php echo $i; ?>">
                                        <?php echo $i; ?> Stars
                                    </label>
                                <?php endfor; ?>
                            </div>
                        </div>

                        <div style="margin-bottom:15px;">
                            <label>Customer Service Rating <span class="sr-optional-hint">(optional)</span></label>
                            <div class="sr-star-select-row">
                                <label>
                                    <input type="radio" name="cs_rating" id="edit_cs_none" value="">
                                    None
                                </label>
                                <?php for ( $i = 5; $i >= 1; $i-- ) : ?>
                                    <label>
                                        <input type="radio" name="cs_rating" value="<?php echo $i; ?>">
                                        <?php echo $i; ?> Stars
                                    </label>
                                <?php endfor; ?>
                            </div>
                        </div>

                        <div style="margin-bottom:15px;">
                            <label>Review Content</label>
                            <textarea name="content" id="edit_content" rows="4"></textarea>
                        </div>

                        <div class="sr-form-group">
                            <label>Photos (Max 5)</label>
                            <div class="sr-photo-upload-box">
                                <input type="file" name="photos[]" id="edit_photo_input" accept="image/jpeg,image/png,image/webp" multiple>
                                <div class="sr-photo-label">
                                    <i class="sr-icon sr-icon-cloud-upload" aria-hidden="true"></i>
                                    <span>Click to upload or drag photos here</span>
                                </div>
                            </div>
                            <div id="edit-photo-area" style="display:none; margin-top:10px;">
                                <label style="font-size: 14px;">Attached Photos:</label>
                                <div id="edit-photo-preview" class="sr-photo-grid"></div>
                            </div>
                        </div>

                        <div class="sr-admin-reply-area">
                            <label>Admin Reply</label>
                            <textarea name="reply" id="edit_reply" rows="3" placeholder="Write a public response..."></textarea>
                        </div>
                    </form>
                </div>
                <div class="sr-modal-foot">
                    <button class="sr-btn blue" id="sr-save-btn">Save Review</button>
                </div>
            </div>
        </div>

        <div id="sr-import-modal" class="sr-modal">
            <div class="sr-modal-panel small">
                <div class="sr-modal-head">
                    <h3>Import CSV</h3>
                    <button type="button" class="sr-close-modal" aria-label="Close dialog"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button>
                </div>
                <div class="sr-modal-body">
                    <form id="sr-import-form">
                        <p class="sr-field-help">Bring your existing reviews with you. Start with our template, then replace the example product IDs with IDs from your store.</p>
                        <a class="sr-download-link" href="<?php echo esc_url( SR_URL . 'assets/sample-reviews.csv' ); ?>" download="starboard-sample-reviews.csv"><span class="sr-icon sr-icon-download" aria-hidden="true"></span> Download sample CSV</a>
                        <label class="sr-upload-zone" for="sr-import-file"><span class="sr-upload-symbol" aria-hidden="true"><span class="sr-icon sr-icon-upload"></span></span><strong>Choose a CSV file</strong><span id="sr-import-filename">or drop it here · up to 5 MB</span><input type="file" id="sr-import-file" name="csv" accept=".csv,text/csv" required></label>
                        <p class="sr-field-help">Up to 1,000 rows per import. Product ID, review body and rating are required. Existing duplicates are skipped.</p>
                        <div id="sr-import-message" class="sr-inline-message" role="status"></div>
                    </form>
                </div>
                <div class="sr-modal-foot">
                    <button class="sr-btn blue" id="sr-import-btn">Import reviews</button>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Static Helper to Render a Single Row (Used by AJAX)
     */
    public static function get_row_html( $r ) {
        $rating = get_comment_meta( $r->comment_ID, 'rating', true );
        $cs_rating = get_comment_meta( $r->comment_ID, 'cs_rating', true );
        $title  = get_comment_meta( $r->comment_ID, 'review_title', true );
        $status = wp_get_comment_status( $r->comment_ID );
        $replies = get_comments( [ 'parent' => $r->comment_ID ] );
        $product = get_post( $r->comment_post_ID );

        // Fetch Photos (Array support)
        $photo_ids = get_comment_meta( $r->comment_ID, 'review_photos', true );

        ob_start();
        ?>
        <tr class="sr-row <?php echo esc_attr( $status ); ?>" data-review-id="<?php echo (int) $r->comment_ID; ?>">
            <td class="sr-check-cell" data-label="Select"><input type="checkbox" class="sr-review-checkbox" value="<?php echo (int) $r->comment_ID; ?>" aria-label="<?php echo esc_attr( 'Select review by ' . $r->comment_author ); ?>"></td>
            <td data-label="Status">
                <span class="sr-status-badge <?php echo esc_attr( $status ); ?>">
                    <?php echo esc_html( [ 'approve' => 'Published', 'hold' => 'Pending', 'spam' => 'Spam', 'trash' => 'Trash' ][$status] ?? ucfirst( $status ) ); ?>
                </span>
            </td>

            <td data-label="Review">
                <div class="sr-star-row">
                    <div class="sr-stars-static" style="--v:<?php echo esc_attr( $rating ); ?>"></div>
                    <strong style="font-size: 14px; color:#64748b;"><?php echo esc_html( $rating ); ?>/5</strong>
                    <?php if ( $cs_rating ) : ?>
                        <span class="sr-badge-pill" title="Customer Service Rating">Service <?php echo esc_html( $cs_rating ); ?>/5</span>
                    <?php endif; ?>
                </div>

                <?php if ( $title ) : ?>
                    <strong style="display:block; margin-bottom:4px; font-size:14px; color:#1e293b;">
                        <?php echo esc_html( $title ); ?>
                    </strong>
                <?php endif; ?>

                <div class="sr-content-txt">
                    <?php echo wp_trim_words( $r->comment_content, 25 ); ?>
                </div>

                <?php
                if ( ! empty( $photo_ids ) && is_array( $photo_ids ) ) {
                    echo '<div class="sr-photo-grid">';
                    foreach ( $photo_ids as $pid ) {
                        echo wp_get_attachment_image( $pid, 'thumbnail', false, [
                            'class' => 'sr-photo-item',
                            'onclick' => 'window.open(this.src)'
                        ]);
                    }
                    echo '</div>';
                }
                // Backwards compatibility for single photo
                elseif ( $single_pid = get_comment_meta( $r->comment_ID, 'review_photo_id', true ) ) {
                    echo '<div class="sr-photo-grid">' . wp_get_attachment_image( $single_pid, 'thumbnail', false, [ 'class' => 'sr-photo-item' ] ) . '</div>';
                }
                ?>

                <?php if ( $replies ) : ?>
                    <div class="sr-nested-reply">
                        <i class="sr-icon sr-icon-corner-up-left" aria-hidden="true"></i>
                        <span><strong>You:</strong> <?php echo wp_trim_words( $replies[0]->comment_content, 15 ); ?></span>
                    </div>
                <?php endif; ?>
            </td>

            <td data-label="Reviewer">
                <div class="sr-user">
                    <div class="sr-av">
                        <?php echo esc_html( strtoupper( substr( $r->comment_author, 0, 1 ) ) ); ?>
                    </div>
                    <div>
                        <strong><?php echo esc_html( $r->comment_author ); ?></strong>
                        <small><?php echo esc_html( $r->comment_author_email ); ?></small>
                    </div>
                </div>
            </td>

            <td data-label="Product">
                <?php if ( $product ) : ?>
                    <a href="<?php echo esc_url( get_edit_post_link( $product->ID ) ); ?>" class="sr-product-link" target="_blank">
                        <?php echo esc_html( $product->post_title ); ?>
                    </a>
                <?php else : ?>
                    <span style="color:#ccc;">-</span>
                <?php endif; ?>
            </td>

            <td data-label="Date">
                <span style="font-size: 14px; color:#64748b;">
                    <?php echo get_comment_date( 'M j, Y', $r->comment_ID ); ?>
                </span>
            </td>

            <td style="position:relative;">
                <button class="sr-icon-btn sr-context-trigger" aria-label="Review actions" aria-haspopup="true" aria-expanded="false">
                    <i class="sr-icon sr-icon-ellipsis-vertical" aria-hidden="true"></i>
                </button>
                <div class="sr-dropdown">
                    <a href="#" onclick="srOpenEdit(<?php echo $r->comment_ID; ?>)">Edit / Reply</a>

                    <?php if ( $status !== 'approve' ) : ?>
                        <a href="#" onclick="srStatus(<?php echo $r->comment_ID; ?>, 'approve')">Approve</a>
                    <?php endif; ?>

                    <a href="#" onclick="srStatus(<?php echo $r->comment_ID; ?>, 'spam')">Spam</a>
                    <a href="#" onclick="srStatus(<?php echo $r->comment_ID; ?>, 'trash')" class="red">Trash</a>
                </div>
            </td>
        </tr>
        <?php
        return ob_get_clean();
    }
}
