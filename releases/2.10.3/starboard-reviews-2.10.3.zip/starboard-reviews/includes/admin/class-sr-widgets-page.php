<?php
if ( ! defined('ABSPATH') ) exit;
class SR_Widgets_Page {
    public static function render() {
        if ( ! current_user_can('moderate_comments') ) wp_die('Permission denied.','',['response'=>403]);
        ?>
        <div class="sr-wrap">
            <?php SR_Brand::header('widgets'); ?>
            <div class="sr-top-bar"><div class="sr-title-group"><p class="sr-eyebrow">STARBOARD REVIEWS</p><h1>A review for every space</h1><p class="sr-page-description">Customize product reviews and showcases for your home page, landing page, or sidebar.</p></div></div>
            <div class="sr-widget-builder">
                <form id="sr-showcase-builder" class="sr-card">
                    <h3>Make it yours</h3>
                    <label for="sc-placement">Where will this widget go?</label>
                    <select id="sc-placement" name="placement"><option value="home">Home page</option><option value="product">Product page</option><option value="landing">Landing page</option><option value="sidebar">Sidebar</option><option value="other">Other page</option></select>
                    <p id="sc-placement-help" class="sr-field-help">Showcase published reviews across your store.</p>
                    <div class="sc-showcase-only"><label for="sc-layout">Display</label>
                    <select id="sc-layout" name="layout"><option value="grid">Grid · cards in columns</option><option value="carousel">Slider · swipe through reviews</option><option value="featured">Featured · one standout review</option><option value="list">List · room for longer stories</option><option value="wall">Review wall · flowing columns</option><option value="compact">Compact · a simple feed</option><option value="button">Rating button · click to see reviews</option><option value="badge">Rating badge · a compact score</option><option value="floating">Floating · a corner review panel</option><option value="popup">Pop-up · reviews on demand</option><option value="sidebar">Sidebar slider · one at a time</option></select></div>
                    <div class="sr-grid-2"><div><label id="sc-count-label" for="sc-count">Number of reviews</label><input id="sc-count" name="count" type="number" value="6" min="1" max="24"></div><div><label for="sc-min">Minimum rating</label><select id="sc-min" name="min_rating"><option value="1">All ratings</option><option value="2">2 stars and up</option><option value="3">3 stars and up</option><option value="4" selected>4 stars and up</option><option value="5">5 stars only</option></select></div></div>
                    <div class="sr-grid-2"><div><label for="sc-columns">Columns</label><select id="sc-columns" name="columns"><option>1</option><option>2</option><option selected>3</option><option>4</option></select></div><div class="sc-showcase-only"><label for="sc-theme">Appearance</label><select id="sc-theme" name="theme"><option value="light">Light</option><option value="soft">Soft blue</option><option value="dark">Dark</option></select></div></div>
                    <label for="sc-order">Order</label><select id="sc-order" name="order"><option value="newest">Newest first</option><option value="oldest">Oldest first</option><option value="highest">Highest rating</option><option value="lowest">Lowest rating</option><option value="manual" class="sc-showcase-only">Selected review IDs, in order</option></select>
                    <label for="sc-product">Product ID <span class="sr-optional-hint">optional</span></label><input id="sc-product" name="product_id" type="number" value="0" min="0"><p class="sr-field-help">Use 0 to detect the current product on product pages, or show store-wide reviews on other pages.</p>
                    <div class="sc-showcase-only"><label for="sc-ids">Choose specific reviews <span class="sr-optional-hint">optional</span></label><input id="sc-ids" name="review_ids" placeholder="e.g. 128, 142, 156"><p class="sr-field-help">Review IDs are shown in the review editor. For a featured review, enter one ID.</p></div>
                    <label for="sc-title">Heading</label><input id="sc-title" name="title" value="What our customers say" maxlength="200">
                    <label for="sc-subtitle">Supporting text</label><input id="sc-subtitle" name="subtitle" value="Real experiences, in their own words." maxlength="300">
                    <div class="sr-grid-2"><div><label for="sc-excerpt">Excerpt length (words)</label><input id="sc-excerpt" name="excerpt" type="number" value="38" min="10" max="200"></div><div class="sc-showcase-only"><label for="sc-position">Floating position</label><select id="sc-position" name="position"><option value="right">Bottom right</option><option value="left">Bottom left</option></select></div></div>
                    <?php foreach(['show_summary'=>'Overall rating','show_product'=>'Product links','show_date'=>'Review dates','show_photos'=>'Review photos','autoplay'=>'Auto-rotate slider','show_form'=>'Review submission form','show_sort'=>'Sorting control','show_title'=>'Short review titles','show_content'=>'Review content'] as $key=>$label): ?><div class="sr-toggle-row <?php echo in_array($key,['show_product','autoplay'],true)?'sc-showcase-only':(in_array($key,['show_form','show_sort','show_title','show_content'],true)?'sc-product-only':''); ?>"><label for="sc-<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label><input type="checkbox" name="<?php echo esc_attr($key); ?>" id="sc-<?php echo esc_attr($key); ?>" <?php if(in_array($key,['show_summary','show_product','show_date','show_form','show_sort','show_title','show_content'],true))echo 'checked'; ?>></div><?php endforeach; ?>
                    <div class="sc-showcase-only"><label for="sc-interval">Rotation interval (seconds)</label><input id="sc-interval" name="interval" type="number" min="3" max="30" value="6">
                    <label for="sc-link">Button or badge link <span class="sr-optional-hint">optional</span></label><input id="sc-link" name="link" type="url" placeholder="https://your-store.com/reviews"><p class="sr-field-help">Leave empty to open the reviews in a panel. Pop-ups open on click, never automatically.</p></div>
                    <label for="sc-font">Font</label><select id="sc-font" name="font"><option value="default">Plugin setting (site default)</option><option value="site">Site font</option><option value="starboard">Starboard font</option></select>
                    <p class="sr-field-help">Minimum rating filters the review cards. The overall score always includes all published reviews in the selected store or product.</p>
                </form>
                <div class="sr-widget-preview-column">
                    <div class="sr-card sr-embed-card"><div><h3>Ready to place</h3><p class="sr-field-help">Paste this into a WordPress Shortcode block or your page builder's shortcode element.</p></div><label class="sr-screen-reader" for="sc-shortcode">Your widget shortcode</label><textarea id="sc-shortcode" readonly rows="3"></textarea><button type="button" class="sr-btn blue" id="sc-copy"><span class="sr-icon sr-icon-copy" aria-hidden="true"></span> Copy shortcode</button><span id="sc-copy-status" class="sr-field-help" role="status"></span></div>
                    <div class="sr-card sr-showcase-preview-panel"><div class="sr-preview-heading"><h3>Live preview</h3><select id="sc-viewport" aria-label="Preview width"><option value="desktop">Desktop</option><option value="mobile">Mobile</option></select></div><p id="sc-preview-status" class="sr-field-help" role="status"></p><div id="sc-preview" aria-live="polite"></div></div>
                    <p class="sr-field-help" id="sc-embed-help">Showcases display published reviews. Select Product page to include a submission form. Copy your shortcode to keep this configuration.</p>
                </div>
            </div>
        </div>
        <?php
    }
}
