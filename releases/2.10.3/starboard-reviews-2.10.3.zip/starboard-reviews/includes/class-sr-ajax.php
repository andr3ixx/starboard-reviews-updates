<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SR_Ajax {

    public function __construct() {
        // Reviews
        add_action( 'wp_ajax_sr_load_data', [ $this, 'load_reviews_table' ] );
        add_action( 'wp_ajax_sr_save_review', [ $this, 'save_review' ] );
        add_action( 'wp_ajax_sr_get_review', [ $this, 'get_review_details' ] );
        add_action( 'wp_ajax_sr_update_status', [ $this, 'update_status' ] );

        add_action( 'wp_ajax_sr_bulk_reviews', [ $this, 'bulk_reviews' ] );

        // Frontend
        add_action( 'wp_ajax_sr_submit_review', [ $this, 'submit_front_review' ] );
        add_action( 'wp_ajax_nopriv_sr_submit_review', [ $this, 'submit_front_review' ] );
        add_action( 'wp_ajax_sr_filter_reviews', [ $this, 'filter_front_reviews' ] );
        add_action( 'wp_ajax_nopriv_sr_filter_reviews', [ $this, 'filter_front_reviews' ] );

        // Settings / Email / Import
        add_action( 'wp_ajax_sr_save_settings', [ $this, 'save_settings' ] );
        add_action( 'wp_ajax_sr_send_test', [ $this, 'send_test_email' ] );
        add_action( 'wp_ajax_sr_force_run_emails', [ $this, 'force_run_emails' ] );
        add_action( 'wp_ajax_sr_import_csv', [ $this, 'process_import' ] );
        add_action( 'wp_ajax_sr_export_csv', [ $this, 'process_export' ] );

        add_action( 'wp_ajax_sr_search_products', [ $this, 'search_products' ] );

        // NEW: View Email Preview
        add_action( 'wp_ajax_sr_view_email_preview', [ $this, 'view_email_preview' ] );

        // NEW: Bulk Actions
        add_action( 'wp_ajax_sr_bulk_email_action', [ $this, 'process_bulk_email_action' ] );

        // NEW: Email Actions (Cancel/Resend)
        add_action( 'wp_ajax_sr_email_action', [ $this, 'process_email_action' ] );

        // NEW: Manual Send (bulk-send review requests for orders not yet Completed in Woo)
        add_action( 'wp_ajax_sr_manual_send_bulk', [ $this, 'process_manual_send_bulk' ] );
    }

    /**
     * MANUAL SEND (BULK)
     * Sends the review request (level 1) or the Customer Service request (level 3)
     * immediately for the given order IDs, regardless of their WooCommerce order status.
     * Does not touch the order itself. Relies on schedule_request's own duplicate-check
     * so re-running this (or a later automatic trigger) never double-sends.
     */
    public function process_manual_send_bulk() {
        SR_Security::authorize( 'manage_options' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied.' ] );
        }

        $order_ids = $this->selected_ids( 'order_ids' );
        $order_ids = array_filter( $order_ids );
        if ( empty( $order_ids ) ) {
            wp_send_json_error( [ 'message' => 'No orders selected.' ] );
        }

        $level = (int) SR_Security::text( 'level' ) ?: 1;
        if ( ! in_array( $level, [ 1, 3 ], true ) ) $level = 1; // Only levels reachable from Manual Send.
        $label = $level === 3 ? 'customer service request' : 'review request';

        $cron = new SR_Cron();
        $counts = [ 'sent' => 0, 'duplicate' => 0, 'no_items' => 0, 'no_order' => 0, 'failed' => 0, 'busy' => 0, 'unsubscribed' => 0, 'cancelled' => 0 ];

        foreach ( $order_ids as $order_id ) {
            $result = $cron->schedule_request( $order_id, $level, true, 'manual' );
            if ( isset( $counts[ $result ] ) ) {
                $counts[ $result ]++;
            }
        }

        $message = "Sent {$counts['sent']} {$label}(s).";
        $skipped = array_sum( $counts ) - $counts['sent'];
        if ( $skipped > 0 ) {
            $parts = [];
            if ( $counts['duplicate'] ) $parts[] = "{$counts['duplicate']} already requested";
            if ( $counts['no_items'] )  $parts[] = "{$counts['no_items']} had no eligible products";
            if ( $counts['no_order'] )  $parts[] = "{$counts['no_order']} order(s) not found";
            foreach ( [ 'failed', 'busy', 'unsubscribed', 'cancelled' ] as $reason ) if ( $counts[$reason] ) $parts[] = $counts[$reason] . ' ' . $reason;
            $message .= ' Skipped ' . $skipped . ' (' . implode( ', ', $parts ) . ').';
        }

        if ( $counts['failed'] || $counts['busy'] ) wp_send_json_error( [ 'message' => $message, 'counts' => $counts ], 502 );
        wp_send_json_success( [ 'message' => $message, 'counts' => $counts ] );
    }

    /**
     * PROCESS EMAIL ACTION (Cancel/Resend)
     */
    public function process_email_action() {
        SR_Security::authorize();
        $result = $this->email_action( absint( SR_Security::text( 'id' ) ), SR_Security::text( 'type' ) );
        if ( is_wp_error( $result ) ) wp_send_json_error( [ 'message' => $result->get_error_message() ], 400 );
        wp_send_json_success( [ 'message' => 'Request updated.' ] );
    }

    private function email_action( $id, $type ) {
        global $wpdb;
        $table = $wpdb->prefix . 'sr_requests';
        if ( ! $id || ! in_array( $type, [ 'cancel', 'resend', 'delete' ], true ) ) return new WP_Error( 'action', 'Invalid request action.' );
        // Never reset or delete a row currently owned by a sending worker.
        if ( $type === 'resend' ) {
            $changed = $wpdb->query( $wpdb->prepare( "UPDATE $table SET status = 'pending', scheduled_date = %s, sent_date = NULL, processing_date = NULL WHERE id = %d AND status IN ('sent','failed','cancelled','pending')", current_time( 'mysql' ), $id ) );
            if ( $changed !== 1 ) return new WP_Error( 'busy', 'Request not found, unchanged, or already processing.' );
            $cron = new SR_Cron();
            $result = $cron->process_request( $id, true );
            if ( $result !== 'sent' ) return new WP_Error( 'send', 'Request was not sent (' . $result . '). Check the email log.' );
        } else {
            $sql = $type === 'delete' ? "DELETE FROM $table WHERE id = %d AND status <> 'sending'" : "UPDATE $table SET status = 'cancelled' WHERE id = %d AND status = 'pending'";
            if ( $wpdb->query( $wpdb->prepare( $sql, $id ) ) !== 1 ) return new WP_Error( 'busy', 'Request not found or cannot be changed in its current state.' );
        }
        return true;
    }

    /**
     * VIEW EMAIL PREVIEW (For Modal)
     */
    public function view_email_preview() {
        SR_Security::authorize( 'manage_options' );

        global $wpdb;
        $table = $wpdb->prefix . 'sr_requests';
        $id = absint( SR_Security::text( 'id' ) );

        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );

        if ( ! $row ) {
            wp_send_json_error( [ 'message' => 'Log not found.' ] );
        }

        // Re-generate the email content logic
        // Note: This logic duplicates SR_Cron code. Ideally, refactor generation into a helper method.
        // For now, we simulate it.

        $order = wc_get_order( $row->order_id );
        if ( ! $order ) {
            wp_send_json_error( [ 'message' => 'Order no longer exists.' ] );
        }

        $defaults = SR_Cron::defaults( $row->level );
        $subject = get_option( 'sr_subject_' . $row->level, $defaults['subject'] );
        $raw_body = get_option( 'sr_body_' . $row->level, $defaults['body'] );
        $template_type = get_option( 'sr_email_template_type', 'modern' );

        $excluded_ids = get_option( 'sr_excluded_products', '' );
        $included_ids = get_option( 'sr_included_products', '' );
        $ex_array = ! empty( $excluded_ids ) ? array_map( 'trim', explode( ',', $excluded_ids ) ) : [];
        $in_array = ! empty( $included_ids ) ? array_map( 'trim', explode( ',', $included_ids ) ) : [];

        $valid_items = [];
        foreach ( $order->get_items() as $item ) {
            $pid = $item->get_product_id();
            $vid = $item->get_variation_id();

            // Exclude Check
            if ( in_array( $pid, $ex_array ) || in_array( $vid, $ex_array ) ) continue;

            // Include Check
            if ( ! empty( $in_array ) ) {
                if ( ! in_array( $pid, $in_array ) && ! in_array( $vid, $in_array ) ) continue;
            }

            $valid_items[] = $item;
        }

        $brand_color = get_option('sr_color_admin', '#2563eb');
        $btn_color   = get_option('sr_color_widget', '#2563eb');


        if ( $template_type === 'modern' ) {
            $table_html = '<div style="background:#fff; border:1px solid #e5e7eb; border-radius:8px; overflow:hidden; margin-top:20px;">';

            foreach ( $valid_items as $item ) {
                $product = $item->get_product();
                if ( ! $product ) continue;
                $link = get_permalink( $product->get_id() ) . '#sr-widget';
                $img_url = wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' );
                if(!$img_url) $img_url = wc_placeholder_img_src();

                $table_html .= '
                <table width="100%" cellspacing="0" cellpadding="0" border="0" style="border-bottom:1px solid #f3f4f6;">
                    <tr>
                        <td width="80" style="padding:15px 0 15px 15px; vertical-align:middle;">
                            <img src="'.$img_url.'" width="60" height="60" style="border-radius:6px; object-fit:cover; display:block;">
                        </td>
                        <td style="padding:15px 10px; vertical-align:middle;">
                            <div style="font-family:Helvetica, Arial, sans-serif; font-weight:600; color:#111827; font-size:15px; line-height:1.4;">'.$item->get_name().'</div>
                            <div style="font-family:Helvetica, Arial, sans-serif; font-size:13px; color:#6b7280; margin-top:4px;">'.$order->get_formatted_line_subtotal($item).'</div>
                        </td>
                        <td width="100" align="right" style="padding:15px 15px 15px 0; vertical-align:middle;">
                            <a href="'.$link.'" style="background:'.$btn_color.'; color:#ffffff; text-decoration:none; padding:8px 18px; border-radius:6px; font-size:13px; font-weight:bold; white-space:nowrap; display:inline-block; font-family:Helvetica, Arial, sans-serif; border:1px solid '.$btn_color.';">Review</a>
                        </td>
                    </tr>
                </table>';
            }
            $table_html .= '</div>';
        } else {
            // ** WC TABLE **
            $table_html = '<table width="100%" cellspacing="0" cellpadding="10" border="0">';
            foreach ( $valid_items as $item ) {
                $product = $item->get_product();
                if ( ! $product ) continue;
                $link = get_permalink( $product->get_id() ) . '#sr-widget';
                $table_html .= '<tr><td style="padding:10px 0;"><strong>'.$item->get_name().'</strong></td><td style="text-align:right;"><a href="'.$link.'">Review</a></td></tr>';
            }
            $table_html .= '</table>';
        }

        // 2. Replacements
        $replacements = [
            '{first_name}'  => $order->get_billing_first_name(),
            '{last_name}'   => $order->get_billing_last_name(),
            '{order_id}'    => $order->get_order_number(),
            '{shop_name}'   => get_bloginfo( 'name' ),
            '{order_table}' => $table_html,
            '{products}'    => $table_html,
            '{name}'        => $order->get_billing_first_name()
        ];
        $message_body = str_replace( array_keys($replacements), array_values($replacements), $raw_body );

        // 3. Wrap
        $logo_enabled = get_option( 'sr_email_logo_enabled', 0 );
        $logo_url     = get_option( 'sr_email_logo_url', '' );

        $header_content = '<h1 style="color:#fff;">' . get_bloginfo( 'name' ) . '</h1>';
        if ( $logo_enabled && $logo_url ) $header_content = '<img src="' . esc_url( $logo_url ) . '" style="height:40px;">';

        if ( $template_type === 'modern' ) {
            $final_html = '
            <div style="background:#f3f4f6; padding:20px; font-family:sans-serif;">
                <div style="max-width:600px; margin:0 auto; background:#fff; border-radius:8px; overflow:hidden;">
                    <div style="background:'.$brand_color.'; padding:30px; text-align:center;">'.$header_content.'</div>
                    <div style="padding:30px; color:#374151; line-height:1.6;">'.wpautop($message_body).'</div>
                    <div style="padding:20px; text-align:center; background:#f9fafb; font-size:12px; color:#999;">&copy; '.date('Y').' '.get_bloginfo('name').'</div>
                </div>
            </div>';
        } else {
            // Basic wrapper for WC
            $final_html = '<div style="padding:20px;">' . wpautop($message_body) . '</div>';
        }

        wp_send_json_success( [ 'html' => wp_kses_post( $final_html ) ] );
    }

    /**
     * BULK ACTIONS
     */
    public function process_bulk_email_action() {
        SR_Security::authorize();
        $ids = $this->selected_ids( 'ids' );
        $type = SR_Security::text( 'type' );
        $errors = [];
        $updated = 0;
        foreach ( $ids as $id ) {
            $result = $this->email_action( $id, $type );
            if ( is_wp_error( $result ) ) $errors[] = $id . ': ' . $result->get_error_message();
            else $updated++;
        }
        if ( $errors ) wp_send_json_error( [ 'message' => $updated . ' updated. ' . implode( ' ', $errors ) ], 400 );
        wp_send_json_success( [ 'message' => $updated . ' updated.' ] );
    }

    private function selected_ids( $key ) {
        $ids = $_POST[$key] ?? [];
        if ( ! is_array( $ids ) || ! $ids || count( $ids ) > 50 ) wp_send_json_error( [ 'message' => 'Select between 1 and 50 items.' ], 400 );
        foreach ( $ids as $id ) if ( ! is_scalar( $id ) || ! ctype_digit( (string) $id ) || (int) $id < 1 ) wp_send_json_error( [ 'message' => 'Invalid selection.' ], 400 );
        return array_unique( array_map( 'absint', $ids ) );
    }

    /** 1. FRONTEND FILTER */
    public function filter_front_reviews() {
        check_ajax_referer( 'sr_nonce', 'nonce' );
        $pid = absint( SR_Security::text( 'pid' ) );
        $sort = sanitize_key( SR_Security::text( 'sort' ) );
        $page = max( 1, min( 10000, (int) SR_Security::text( 'page' ) ) );
        if ( $pid && ( get_post_type( $pid ) !== 'product' || get_post_status( $pid ) !== 'publish' || post_password_required( $pid ) ) ) wp_send_json_error( [ 'message' => 'Product unavailable.' ], 404 );
        $options = SR_Widget::normalize(['count'=>SR_Security::text('count') ?: 6,'min_rating'=>SR_Security::text('min_rating') ?: 1,'excerpt'=>SR_Security::text('excerpt') ?: 20]);
        $args = [ 'post_id' => $pid, 'post_type' => 'product', 'post_status' => 'publish', 'status' => 'approve', 'type' => 'review', 'number' => $options['count'], 'offset' => ($page - 1) * $options['count'], 'parent' => 0 ];
        $args['meta_query']=[['key'=>'rating','value'=>[$options['min_rating'],5],'compare'=>'BETWEEN','type'=>'NUMERIC']];

        if ( ! $pid ) $args['post__not_in'] = get_posts( [ 'post_type' => 'product', 'post_status' => 'publish', 'has_password' => true, 'numberposts' => -1, 'fields' => 'ids' ] );
        if($sort === 'lowest') { $args['meta_key'] = 'rating'; $args['orderby'] = 'meta_value_num'; $args['order'] = 'ASC'; }
        elseif($sort === 'highest') { $args['meta_key'] = 'rating'; $args['orderby'] = 'meta_value_num'; $args['order'] = 'DESC'; }
        elseif($sort === 'oldest') { $args['orderby'] = 'comment_date'; $args['order'] = 'ASC'; }
        else { $args['orderby'] = 'comment_date'; $args['order'] = 'DESC'; }

        $comments = get_comments( $args );
        $html = '';
        foreach ( $comments as $c ) {
            $html .= SR_Widget::render_single_review( $c, $options );
        }
        $count_args = $args; unset($count_args['number']); unset($count_args['offset']);
        $count_args['count'] = true;
        $total = (int) get_comments( $count_args );
        wp_send_json_success( [ 'html' => $html, 'has_more' => $total > ($page * $options['count']) ] );
    }

    /** 2. FRONTEND SUBMIT (Updated with Custom Notification Emails) */
    public function submit_front_review() {
        check_ajax_referer( 'sr_nonce', 'security' );
        $attempt=SR_Antispam::attempt();
        if(is_wp_error($attempt))wp_send_json_error(['message'=>$attempt->get_error_message()],429);
        if ( ! function_exists( 'wc_get_product' ) ) wp_send_json_error( [ 'message' => 'Reviews are temporarily unavailable.' ], 503 );
        $pid = absint( SR_Security::text( 'pid' ) );
        $rating = filter_var( SR_Security::text( 'rating' ), FILTER_VALIDATE_INT );
        $cs_raw = SR_Security::text( 'cs_rating' );
        $cs_rating = $cs_raw === '' ? 0 : filter_var( $cs_raw, FILTER_VALIDATE_INT );
        $name = sanitize_text_field( SR_Security::text( 'author' ) );
        $email = sanitize_email( SR_Security::text( 'email' ) );
        $content = sanitize_textarea_field( SR_Security::text( 'content' ) );
        $title = sanitize_text_field( SR_Security::text( 'title' ) );
        $product = wc_get_product( $pid );
        if ( ! $product || get_post_type( $pid ) !== 'product' || get_post_status( $pid ) !== 'publish' || post_password_required( $pid ) || ! comments_open( $pid ) || ! $product->get_reviews_allowed() || get_option( 'woocommerce_enable_reviews', 'yes' ) !== 'yes' ) {
            wp_send_json_error( [ 'message' => 'This product is not accepting reviews.' ], 400 );
        }
        if ( $rating < 1 || $rating > 5 || ( $cs_raw !== '' && ( $cs_rating < 1 || $cs_rating > 5 ) ) || ! $name || ! is_email( $email ) || ! $content || ! $title || strlen( $content ) > 10000 || strlen( $name ) > 100 || strlen( $title ) > 200 ) {
            wp_send_json_error( [ 'message' => 'Provide a name, valid email, title, review and ratings from 1 to 5.' ], 400 );
        }
        $user = wp_get_current_user();
        if ( get_option( 'comment_registration' ) && ! $user->ID ) wp_send_json_error( [ 'message' => 'Please sign in to leave a review.' ], 403 );
        if ( get_option( 'sr_verified_only' ) || get_option( 'woocommerce_review_rating_verification_required' ) === 'yes' ) {
            if ( ! $user->ID || ! wc_customer_bought_product( $user->user_email, $user->ID, $pid ) ) {
                wp_send_json_error( [ 'message' => 'Please sign in with the account used to purchase this product.' ], 403 );
            }
            $email = $user->user_email;
        }
        $rate_key = 'sr_submit_' . hash( 'sha256', (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
        $rate = get_transient( $rate_key );
        if ( $rate && ( $rate['last'] > time() - 60 || $rate['count'] >= 10 ) ) wp_send_json_error( [ 'message' => 'Please wait before submitting another review.' ], 429 );
        $verification=SR_Antispam::verify();
        if(is_wp_error($verification))wp_send_json_error(['message'=>$verification->get_error_message()],403);
        $files = SR_Security::photos();
        if ( is_wp_error( $files ) ) wp_send_json_error( [ 'message' => $files->get_error_message() ], 400 );
        // Keep WordPress duplicate, flood, moderation and spam checks. Our rule can
        // require moderation but must never override a spam filter's decision.
        $moderation = function( $approved, $data ) use ( $pid, $rating ) {
            if ( (int) $data['comment_post_ID'] === $pid && in_array( $approved, [ 0, 1, '0', '1' ], true ) && ( ! get_option( 'sr_auto_publish', 1 ) || $rating < (int) get_option( 'sr_auto_publish_min', 4 ) ) ) return 0;
            return $approved;
        };
        add_filter( 'pre_comment_approved', $moderation, PHP_INT_MAX, 2 );
        // Send the configured Starboard notification after photos are saved,
        // rather than also sending WordPress's default notification for this review.
        $notification = function( $notify, $id ) use ( $pid ) {
            $comment = get_comment( $id );
            return $comment && (int) $comment->comment_post_ID === $pid && $comment->comment_type === 'review' ? false : $notify;
        };
        add_filter( 'notify_moderator', $notification, PHP_INT_MAX, 2 );
        add_filter( 'notify_post_author', $notification, PHP_INT_MAX, 2 );
        try {
            $_POST['comment_post_ID'] = $pid;
            $comment_id = wp_new_comment( wp_slash( [
                'comment_post_ID' => $pid, 'comment_author' => $name, 'comment_author_email' => $email,
                'comment_content' => $content, 'comment_type' => 'review',
                'user_id' => $user->ID,
                'comment_meta' => [ 'rating' => $rating, 'review_title' => $title ] + ( $cs_rating ? [ 'cs_rating' => $cs_rating ] : [] ),
            ] ), true );
        } finally {
            remove_filter( 'pre_comment_approved', $moderation, PHP_INT_MAX );
            remove_filter( 'notify_moderator', $notification, PHP_INT_MAX );
            remove_filter( 'notify_post_author', $notification, PHP_INT_MAX );
        }
        if ( is_wp_error( $comment_id ) ) wp_send_json_error( [ 'message' => $comment_id->get_error_message() ], 400 );
        if ( $comment_id ) {
            if ( class_exists( 'WC_Comments' ) ) WC_Comments::clear_transients( $pid );
            set_transient( $rate_key, [ 'last' => time(), 'count' => $rate ? $rate['count'] + 1 : 1 ], DAY_IN_SECONDS );
            $status = get_comment( $comment_id )->comment_approved === '1' ? 1 : 0;
            // Spam/trash must not create public attachments or notification floods.
            if ( in_array( get_comment( $comment_id )->comment_approved, [ '0', '1' ], true ) ) {
                $ids = SR_Security::upload_photos( $files, $pid );
                if ( is_wp_error( $ids ) ) {
                    wp_delete_comment( $comment_id, true );
                    wp_send_json_error( [ 'message' => 'Photo upload failed. Please try submitting again without photos.' ], 400 );
                }
                if ( $ids ) update_comment_meta( $comment_id, 'review_photos', $ids );
            } else {
                wp_send_json_success( [ 'message' => 'Submitted for moderation.', 'approved' => 0 ] );
            }

            // --- ADMIN NOTIFICATION START ---

            // 1. Get Recipients (Custom or Default)
            $recipients_str = get_option( 'sr_notification_email' );
            if ( empty( $recipients_str ) ) {
                $recipients = [ get_option( 'admin_email' ) ];
            } else {
                $recipients = array_map( 'trim', explode( ',', $recipients_str ) );
            }

            $subject = 'New Review (' . $rating . '/5) on ' . get_bloginfo( 'name' );
            $product_title = get_the_title( $pid );
            $status_txt = $status ? 'Published' : 'Pending Moderation';

            $msg  = "A new review has been submitted.\n\n";
            $msg .= "Product: " . $product_title . "\n";
            $msg .= "Reviewer: " . $name . " (" . $email . ")\n";
            $msg .= "Rating: " . $rating . " Stars\n";
            $msg .= "Status: " . $status_txt . "\n\n";
            $msg .= "Title: " . $title . "\n";
            $msg .= "Review:\n" . $content . "\n\n";
            $msg .= "Manage Review: " . admin_url( 'admin.php?page=starboard-reviews' );

            // Send to all
            foreach ( $recipients as $to ) {
                if ( is_email( $to ) ) {
                    wp_mail( $to, $subject, $msg );
                }
            }
            // --- ADMIN NOTIFICATION END ---

            wp_send_json_success( [ 'message' => $status ? 'Published successfully!' : 'Submitted for moderation.', 'approved' => $status, 'summary' => $status ? SR_Widget::summary( $pid ) : null ] );
        }
        wp_send_json_error( ['message'=>'Error saving review.'] );
    }

    /** 3. ADMIN LOAD TABLE */
    public function load_reviews_table() {
        SR_Security::authorize( 'moderate_comments' );
        $status = sanitize_key( SR_Security::text( 'status' ) ) ?: 'all';
        if ( ! in_array( $status, [ 'all', 'approve', 'hold', 'spam', 'trash' ], true ) ) wp_send_json_error( [ 'message' => 'Invalid status filter.' ], 400 );
        $sort = sanitize_key( SR_Security::text( 'sort' ) ) ?: 'newest';
        $page = max( 1, (int) SR_Security::text( 'page' ) );

        $args = [
            'type'   => 'review',
            'post_type' => 'product',
            'status' => ($status === 'all' ? 'approve,hold' : $status),
            'search' => sanitize_text_field( SR_Security::text( 'search' ) ),
            'number' => 20,
            'no_found_rows' => false,
            'offset' => ($page - 1) * 20,
            'parent' => 0
        ];

        $date_query = [];
        if ( ! empty( $_POST['from'] ) ) {
            $date_query['after'] = sanitize_text_field( SR_Security::text( 'from' ) ) . ' 00:00:00';
        }
        if ( ! empty( $_POST['to'] ) ) {
            $date_query['before'] = sanitize_text_field( SR_Security::text( 'to' ) ) . ' 23:59:59';
        }
        if ( ! empty( $date_query ) ) {
            $args['date_query'] = [ $date_query ];
        }

        if($sort=='oldest') { $args['order']='ASC'; }
        elseif($sort=='highest') { $args['meta_key']='rating'; $args['orderby']='meta_value_num'; $args['order']='DESC'; }
        elseif($sort=='lowest') { $args['meta_key']='rating'; $args['orderby']='meta_value_num'; $args['order']='ASC'; }
        else { $args['orderby']='comment_date'; $args['order']='DESC'; }

        $query = new WP_Comment_Query;
        $reviews = $query->query( $args );
        $html = '';
        if($reviews) foreach($reviews as $r) $html .= SR_Reviews_Page::get_row_html($r);
        else $html = '<tr><td colspan="7"><div class="sr-empty-state"><span class="sr-icon sr-icon-message-square" aria-hidden="true"></span><strong>No reviews in this view</strong><p>Try another filter, add a review, or import your existing feedback.</p></div></td></tr>';
        $stats_html = null;
        $status_counts = null;
        if ( SR_Security::text( 'include_stats' ) !== '0' ) {
        $status_counts = $this->get_accurate_counts();
        $stats = $this->get_stats_data();
        ob_start();
        ?>
        <div class="sr-stat-main">
            <div class="sr-stat-label">Product satisfaction</div>
            <div class="sr-big-num"><?php echo $stats['avg']; ?></div>
            <div class="sr-stars-static" style="--v:<?php echo $stats['avg']; ?>"></div>
            <div><?php echo $stats['total']; ?> Reviews</div>
        </div>
        <div class="sr-stat-bars">
            <?php foreach([5,4,3,2,1] as $s): $pct=$stats['total']>0?round(($stats['counts'][$s]/$stats['total'])*100):0; ?>
            <div class="sr-bar-row"><span><?php echo $s; ?><span class="sr-icon sr-icon-star" aria-hidden="true"></span></span><div class="sr-track"><div class="sr-fill" style="width:<?php echo $pct; ?>%"></div></div><span><?php echo $stats['counts'][$s]; ?></span></div>
            <?php endforeach; ?>
        </div>
        <?php if ( $stats['cs_count'] > 0 ) : ?>
        <div class="sr-stat-cs">
            <div class="sr-stat-cs-label"><i class="sr-icon sr-icon-headphones" aria-hidden="true"></i> Customer Service</div>
            <div class="sr-big-num sr-stat-cs-num"><?php echo $stats['cs_avg']; ?></div>
            <div class="sr-stars-static" style="--v:<?php echo $stats['cs_avg']; ?>"></div>
            <div class="sr-stat-cs-count"><?php echo $stats['cs_count']; ?> ratings</div>
        </div>
        <?php endif; ?>
        <?php
        $stats_html = ob_get_clean();

        }

        wp_send_json_success([
            'html'       => $html,
            'stats_html' => $stats_html,
            'pages'      => ceil($query->found_comments/20),
            'total'      => (int) $query->found_comments,
            'counts'     => $status_counts
        ]);
    }

    /** Validate every selected record before applying a bulk moderation change. */
    public function bulk_reviews() {
        SR_Security::authorize( 'moderate_comments' );
        $ids = $this->selected_ids( 'ids' );
        $status = SR_Security::text( 'status' ) ?: 'keep';
        $rating_raw = SR_Security::text( 'rating' );
        $cs_raw = SR_Security::text( 'cs_rating' );
        $rating = filter_var( $rating_raw, FILTER_VALIDATE_INT );
        $cs = filter_var( $cs_raw, FILTER_VALIDATE_INT );
        if ( ! in_array( $status, [ 'keep', 'approve', 'hold', 'spam', 'trash' ], true ) || ( $rating_raw !== '' && ( $rating < 1 || $rating > 5 ) ) || ( $cs_raw !== '' && $cs_raw !== 'clear' && ( $cs < 1 || $cs > 5 ) ) ) {
            wp_send_json_error( [ 'message' => 'Choose a valid status and ratings from 1 to 5.' ], 400 );
        }
        if ( $status === 'keep' && $rating_raw === '' && $cs_raw === '' ) wp_send_json_error( [ 'message' => 'Choose at least one field to change.' ], 400 );
        $reviews = [];
        foreach ( $ids as $id ) $reviews[] = SR_Security::review( $id );
        $updated = 0;
        foreach ( $reviews as $review ) {
            $id = (int) $review->comment_ID;
            if ( $rating_raw !== '' ) update_comment_meta( $id, 'rating', $rating );
            if ( $cs_raw === 'clear' ) delete_comment_meta( $id, 'cs_rating' );
            elseif ( $cs_raw !== '' ) update_comment_meta( $id, 'cs_rating', $cs );
            if ( $status !== 'keep' && ! wp_set_comment_status( $id, $status ) ) {
                wp_send_json_error( [ 'message' => $updated . ' reviews updated. A status change failed; refresh the list before retrying.' ], 500 );
            }
            if ( class_exists( 'WC_Comments' ) ) WC_Comments::clear_transients( $review->comment_post_ID );
            $updated++;
        }
        wp_send_json_success( [ 'message' => $updated . ( $updated === 1 ? ' review updated.' : ' reviews updated.' ), 'updated' => $updated ] );
    }

    /** 4. SAVE REVIEW (Admin Reply) */
    public function save_review() {
        SR_Security::authorize( 'moderate_comments' );
        $id = absint( SR_Security::text( 'id' ) );
        $parent = $id ? SR_Security::review( $id ) : null;
        $pid = absint( SR_Security::text( 'product_id' ) ) ?: ( $parent ? $parent->comment_post_ID : 0 );
        $rating = filter_var( SR_Security::text( 'rating' ), FILTER_VALIDATE_INT );
        $cs_raw = SR_Security::text( 'cs_rating' );
        $cs = $cs_raw === '' ? 0 : filter_var( $cs_raw, FILTER_VALIDATE_INT );
        $name = sanitize_text_field( SR_Security::text( 'author' ) );
        $email = sanitize_email( SR_Security::text( 'email' ) );
        $content = sanitize_textarea_field( SR_Security::text( 'content' ) );
        if ( get_post_type( $pid ) !== 'product' || ! current_user_can( 'edit_post', $pid ) || $rating < 1 || $rating > 5 || ( $cs_raw !== '' && ( $cs < 1 || $cs > 5 ) ) || ! $name || ! $content || ( $email !== '' && ! is_email( $email ) ) ) {
            wp_send_json_error( [ 'message' => 'Select an accessible product and provide valid review fields and ratings.' ], 400 );
        }
        $files = SR_Security::photos();
        if ( is_wp_error( $files ) ) wp_send_json_error( [ 'message' => $files->get_error_message() ], 400 );
        $data = [ 'comment_post_ID' => $pid, 'comment_author' => $name, 'comment_author_email' => $email, 'comment_content' => $content, 'comment_type' => 'review' ];
        $date = SR_Security::text( 'date' );
        if ( $date !== '' ) {
            $parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', $date, wp_timezone() );
            if ( ! $parsed || $parsed->format( 'Y-m-d' ) !== $date ) wp_send_json_error( [ 'message' => 'Invalid review date.' ], 400 );
            $data['comment_date'] = $parsed->format( 'Y-m-d H:i:s' );
            $data['comment_date_gmt'] = get_gmt_from_date( $data['comment_date'] );
        }
        $photo_ids = SR_Security::upload_photos( $files, $pid );
        if ( is_wp_error( $photo_ids ) ) wp_send_json_error( [ 'message' => $photo_ids->get_error_message() ], 400 );
        if ( $id ) {
            $data['comment_ID'] = $id;
            $saved = wp_update_comment( wp_slash( $data ), true );
        } else {
            $data['comment_approved'] = 1;
            $data['user_id'] = get_current_user_id();
            $saved = $id = wp_insert_comment( wp_slash( $data ) );
        }
        if ( ! $saved || is_wp_error( $saved ) ) {
            foreach ( $photo_ids as $attachment ) wp_delete_attachment( $attachment, true );
            wp_send_json_error( [ 'message' => 'Unable to save review.' ], 500 );
        }
        update_comment_meta( $id, 'rating', $rating );
        if ( $cs ) update_comment_meta( $id, 'cs_rating', $cs );
        else delete_comment_meta( $id, 'cs_rating' );
        update_comment_meta( $id, 'review_title', wp_slash( sanitize_text_field( SR_Security::text( 'title' ) ) ) );
        // A new selection replaces this review's gallery; existing media is retained.
        if ( $photo_ids ) update_comment_meta( $id, 'review_photos', $photo_ids );
        if ( class_exists( 'WC_Comments' ) ) WC_Comments::clear_transients( $pid );
        if ( $parent && (int) $parent->comment_post_ID !== (int) $pid && class_exists( 'WC_Comments' ) ) WC_Comments::clear_transients( $parent->comment_post_ID );
        $reply = sanitize_textarea_field( SR_Security::text( 'reply' ) );
        if ( $reply !== '' ) {
            $replies = get_comments( [ 'parent' => $id, 'type' => 'review', 'status' => 'approve', 'number' => 1 ] );
            if ( $replies ) {
                $saved_reply = wp_update_comment( wp_slash( [ 'comment_ID' => $replies[0]->comment_ID, 'comment_post_ID' => $pid, 'comment_content' => $reply ] ), true );
            } else {
                $saved_reply = wp_insert_comment( wp_slash( [ 'comment_post_ID' => $pid, 'comment_content' => $reply, 'comment_parent' => $id, 'comment_type' => 'review', 'comment_approved' => 1, 'user_id' => get_current_user_id(), 'comment_author' => get_bloginfo( 'name' ) ] ));
                if ( $saved_reply && is_email( $email ) ) wp_mail( $email, 'Response to your review on ' . get_bloginfo( 'name' ), "We have replied to your review:\n\n" . $reply . "\n\n" . get_permalink( $pid ) . '#sr-widget' );
            }
            if ( ! $saved_reply || is_wp_error( $saved_reply ) ) wp_send_json_error( [ 'message' => 'Review saved, but the reply could not be saved.' ], 500 );
        }
        wp_send_json_success( [ 'message' => 'Saved.' ] );
    }

    public function search_products() {
        SR_Security::authorize( 'moderate_comments' );

        $term = sanitize_text_field( SR_Security::text( 'term', $_GET ) );
        if ( empty( $term ) ) wp_send_json_success([]);

        $args = [
            'post_type'      => 'product',
            'post_status'    => 'publish',
            's'              => $term,
            'posts_per_page' => 10,
            'fields'         => 'ids'
        ];

        $query = new WP_Query( $args );
        $results = [];

        foreach ( $query->posts as $id ) {
            $product = wc_get_product( $id );
            if ( $product ) {
                $name = $product->get_name();
                $short_name = strlen($name) > 30 ? substr($name, 0, 30) . '...' : $name;

                $results[] = [
                    'id'   => $id,
                    'text' => '<strong>[ID: ' . $id . ']</strong> ' . esc_html( $short_name )
                ];
            }
        }

        wp_send_json_success( $results );
    }

    public function get_review_details() {
        SR_Security::authorize( 'moderate_comments' ); $id=absint( SR_Security::text( 'id' ) ); $c=SR_Security::review($id);
        $replies=get_comments(['parent'=>$id]);
        $photos=get_comment_meta($id,'review_photos',true); $urls=[];
        if(is_array($photos)) foreach($photos as $p) $urls[]=wp_get_attachment_image_url($p,'thumbnail');
        wp_send_json_success([
            'id'=>$c->comment_ID, 'title'=>get_comment_meta($id,'review_title',true),
            'author'=>$c->comment_author, 'email'=>$c->comment_author_email, 'content'=>$c->comment_content,
            'rating'=>get_comment_meta($id,'rating',true), 'cs_rating'=>get_comment_meta($id,'cs_rating',true), 'pid'=>$c->comment_post_ID, 'date'=>$c->comment_date,
            'reply'=>$replies?$replies[0]->comment_content:'', 'photos'=>$urls
        ]);
    }

    public function update_status() {
        SR_Security::authorize( 'moderate_comments' );
        $id = absint( SR_Security::text( 'id' ) );
        SR_Security::review( $id );
        $status = SR_Security::text( 'status' );
        if ( ! in_array( $status, [ 'approve', 'hold', 'spam', 'trash', 'unspam', 'untrash' ], true ) || ! wp_set_comment_status( $id, $status ) ) {
            wp_send_json_error( [ 'message' => 'Unable to update review status.' ], 400 );
        }
        wp_send_json_success();
    }

    public function save_settings() {
        SR_Security::authorize();
        parse_str( SR_Security::text( 'data' ), $fields );
        $group = $fields['sr_settings_group'] ?? '';
        $general = [ 'sr_auto_publish', 'sr_auto_publish_min', 'sr_verified_only', 'sr_excluded_products', 'sr_notification_email', 'sr_color_admin', 'sr_color_widget', 'sr_color_star', 'sr_front_font' ];
        $email = [ 'sr_included_products', 'sr_delay_1', 'sr_delay_2', 'sr_subject_1', 'sr_subject_2', 'sr_subject_3', 'sr_body_1', 'sr_body_2', 'sr_body_3', 'sr_enable_followup', 'sr_email_template_type', 'sr_email_logo_enabled', 'sr_email_logo_url', 'sr_email_logo_height' ];
        if ( ! in_array( $group, [ 'general', 'email' ], true ) ) wp_send_json_error( [ 'message' => 'Unknown settings form.' ], 400 );
        $booleans = $group === 'general' ? [ 'sr_auto_publish', 'sr_verified_only' ] : [ 'sr_enable_followup', 'sr_email_logo_enabled' ];
        $updates = [];
        foreach ( $group === 'general' ? $general : $email as $key ) {
            if ( ! isset( $fields[$key] ) && ! in_array( $key, $booleans, true ) ) continue;
            $value = $fields[$key] ?? '';
            if ( ! is_scalar( $value ) ) wp_send_json_error( [ 'message' => 'Invalid settings value.' ], 400 );
            if ( in_array( $key, $booleans, true ) ) $value = $value === '1' ? 1 : 0;
            elseif ( $key === 'sr_front_font' ) {
                if ( ! in_array( $value, [ 'site', 'starboard' ], true ) ) wp_send_json_error( [ 'message' => 'Choose site or Starboard typography.' ], 400 );
            }
            elseif ( strpos( $key, 'sr_color_' ) === 0 ) {
                $value = sanitize_hex_color( $value );
                if ( ! $value ) wp_send_json_error( [ 'message' => 'Use a valid hex color.' ], 400 );
            } elseif ( in_array( $key, [ 'sr_excluded_products', 'sr_included_products' ], true ) ) {
                $value = implode( ',', array_unique( array_filter( array_map( 'absint', explode( ',', $value ) ) ) ) );
            } elseif ( $key === 'sr_notification_email' ) {
                $addresses = array_filter( array_map( 'trim', explode( ',', $value ) ) );
                foreach ( $addresses as $address ) if ( ! is_email( $address ) ) wp_send_json_error( [ 'message' => 'Invalid notification email.' ], 400 );
                $value = implode( ',', $addresses );
            } elseif ( strpos( $key, 'sr_body_' ) === 0 ) $value = wp_kses_post( $value );
            elseif ( $key === 'sr_email_logo_url' ) $value = esc_url_raw( $value, [ 'https', 'http' ] );
            elseif ( $key === 'sr_email_template_type' ) {
                if ( ! in_array( $value, [ 'modern', 'woocommerce' ], true ) ) wp_send_json_error( [ 'message' => 'Invalid email template.' ], 400 );
            } elseif ( in_array( $key, [ 'sr_delay_1', 'sr_delay_2', 'sr_auto_publish_min', 'sr_email_logo_height' ], true ) ) {
                $min = $key === 'sr_auto_publish_min' || $key === 'sr_email_logo_height' ? 1 : 0;
                $max = $key === 'sr_auto_publish_min' ? 5 : ( $key === 'sr_email_logo_height' ? 500 : 365 );
                $value = filter_var( $value, FILTER_VALIDATE_INT, [ 'options' => [ 'min_range' => $min, 'max_range' => $max ] ] );
                if ( $value === false ) wp_send_json_error( [ 'message' => 'Invalid numeric setting.' ], 400 );
            } else $value = sanitize_text_field( $value );
            // Missing optional fields must not erase values from older clients.
            if ( isset( $fields[$key] ) || in_array( $key, $booleans, true ) ) $updates[$key] = $value;
        }
        foreach ( $updates as $key => $value ) update_option( $key, $value );
        wp_send_json_success();
    }

    public function force_run_emails() {
        SR_Security::authorize();
        $cron = new SR_Cron();
        $cron->process_queue();
        wp_send_json_success( [ 'message' => 'Processed due requests.' ] );
    }

    public function send_test_email() {
        SR_Security::authorize();
        $email = sanitize_email( SR_Security::text( 'email' ) );
        if ( ! is_email( $email ) ) wp_send_json_error( [ 'message' => 'Enter a valid email address.' ], 400 );
        if ( ! wp_mail( $email, 'Starboard Reviews: delivery test', 'Your mail service accepted this test message.' ) ) wp_send_json_error( [ 'message' => 'The mail service rejected the test message.' ], 502 );
        wp_send_json_success( [ 'message' => 'Test message accepted by the mail service.' ] );
    }

    private function csv_cell( $value ) {
        $value = (string) $value;
        return preg_match( "/^(?:'|[\\s\\x00-\\x1f]*[=+@-])/", $value ) ? "'" . $value : $value;
    }

    public function process_export() {
        SR_Security::authorize( 'moderate_comments' );
        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=reviews-export-' . gmdate( 'Y-m-d' ) . '.csv' );
        $output = fopen( 'php://output', 'w' );
        fputcsv( $output, [ 'sr_export_version', 'review_date', 'reviewer_name', 'reviewer_email', 'product_id', 'rating', 'cs_rating', 'title', 'body', 'status', 'picture_urls', 'reply', 'reply_date', 'ip_address', 'location' ] );
        $offset = 0;
        do {
            $comments = get_comments( [ 'post_type' => 'product', 'type' => 'review', 'number' => 200, 'offset' => $offset, 'parent' => 0, 'status' => 'all', 'orderby' => 'comment_ID', 'order' => 'ASC' ] );
            foreach ( $comments as $c ) {
                $photos = get_comment_meta( $c->comment_ID, 'review_photos', true );
                $urls = [];
                foreach ( is_array( $photos ) ? $photos : [] as $photo ) {
                    $url = wp_get_attachment_url( $photo );
                    if ( $url ) $urls[] = $url;
                }
                $replies = get_comments( [ 'parent' => $c->comment_ID, 'status' => 'approve', 'number' => 1 ] );
                $row = [ '1', $c->comment_date, $c->comment_author, $c->comment_author_email, $c->comment_post_ID,
                    get_comment_meta( $c->comment_ID, 'rating', true ), get_comment_meta( $c->comment_ID, 'cs_rating', true ),
                    get_comment_meta( $c->comment_ID, 'review_title', true ), $c->comment_content, wp_get_comment_status( $c->comment_ID ),
                    implode( ',', $urls ), $replies ? $replies[0]->comment_content : '', $replies ? $replies[0]->comment_date : '',
                    $c->comment_author_IP, get_comment_meta( $c->comment_ID, '_sr_location', true ) ];
                fputcsv( $output, array_map( [ $this, 'csv_cell' ], $row ) );
            }
            $offset += 200;
        } while ( count( $comments ) === 200 );
        fclose( $output );
        exit;
    }

    public function process_import() {
        SR_Security::authorize( 'moderate_comments' );
        $upload = $_FILES['csv'] ?? [];
        if ( empty( $upload['tmp_name'] ) || ! is_string( $upload['tmp_name'] ) || (int) ( $upload['error'] ?? -1 ) !== UPLOAD_ERR_OK || ! is_uploaded_file( $upload['tmp_name'] ) || filesize( $upload['tmp_name'] ) > 5 * MB_IN_BYTES ) wp_send_json_error( [ 'message' => 'Upload a CSV file up to 5 MB.' ], 400 );
        $file = fopen( $upload['tmp_name'], 'r' );
        if ( ! $file ) wp_send_json_error( [ 'message' => 'Unable to read CSV.' ], 400 );
        $header = fgetcsv( $file );
        if ( ! is_array( $header ) ) { fclose( $file ); wp_send_json_error( [ 'message' => 'CSV is empty.' ], 400 ); }
        $header = array_map( function( $value ) { return strtolower( trim( (string) $value, "\xEF\xBB\xBF \t\r\n" ) ); }, $header );
        $idx = array_flip( $header );
        // Accept old Starboard exports as well as Judge.me-compatible imports.
        foreach ( [ 'content' => 'body', 'author' => 'reviewer_name', 'email' => 'reviewer_email', 'date' => 'review_date', 'cs rating' => 'cs_rating' ] as $old => $new ) if ( isset( $idx[$old] ) && ! isset( $idx[$new] ) ) $idx[$new] = $idx[$old];
        if ( ! isset( $idx['body'], $idx['rating'] ) ) { fclose( $file ); wp_send_json_error( [ 'message' => 'CSV requires body and rating columns.' ], 400 ); }
        $count = 0; $skipped = 0; $duplicates = 0; $photo_errors = 0; $rows = 0;
        while ( ( $row = fgetcsv( $file ) ) !== false ) {
            if ( ++$rows > 1000 ) { $skipped++; continue; }
            $get = function( $key, $default = '' ) use ( $idx, $row ) {
                $value = isset( $idx[$key], $row[$idx[$key]] ) ? (string) $row[$idx[$key]] : $default;
                if ( isset( $idx['sr_export_version'] ) && ( $row[$idx['sr_export_version']] ?? '' ) === '1' && preg_match( "/^'(?:'|[\\s\\x00-\\x1f]*[=+@-])/", $value ) ) $value = substr( $value, 1 );
                return $value;
            };
            $pid = absint( $get( 'product_id' ) );
            if ( ! $pid && $get( 'product_handle' ) ) {
                $product = get_page_by_path( sanitize_title( $get( 'product_handle' ) ), OBJECT, 'product' );
                if ( $product ) $pid = $product->ID;
            }
            // Old exports only contained the product title; accept an exact unique match.
            if ( ! $pid && $get( 'product' ) ) {
                $products = get_posts( [ 'post_type' => 'product', 'title' => $get( 'product' ), 'post_status' => 'any', 'numberposts' => 2 ] );
                if ( count( $products ) === 1 ) $pid = $products[0]->ID;
            }
            $content = sanitize_textarea_field( $get( 'body' ) );
            $rating = filter_var( $get( 'rating' ), FILTER_VALIDATE_INT );
            $cs_raw = $get( 'cs_rating' );
            $cs = $cs_raw === '' ? 0 : filter_var( $cs_raw, FILTER_VALIDATE_INT );
            $email = sanitize_email( $get( 'reviewer_email' ) );
            $date = $this->csv_date( $get( 'review_date' ) );
            $status = $get( 'status', 'approve' );
            $statuses = [ 'approve' => 1, 'approved' => 1, '1' => 1, 'hold' => 0, 'unapproved' => 0, '0' => 0, 'spam' => 'spam', 'trash' => 'trash' ];
            if ( ! $pid || get_post_type( $pid ) !== 'product' || ! current_user_can( 'edit_post', $pid ) || ! $content || $rating < 1 || $rating > 5 || ( $cs_raw !== '' && ( $cs < 1 || $cs > 5 ) ) || ! $date || ! isset( $statuses[$status] ) || ( $get( 'reviewer_email' ) !== '' && ! is_email( $email ) ) ) { $skipped++; continue; }
            $existing = get_comments( [ 'post_id' => $pid, 'type' => 'review', 'status' => 'all', 'parent' => 0, 'author_email' => $email ] );
            $duplicate = false;
            foreach ( $existing as $review ) if ( $review->comment_content === $content && $review->comment_date === $date ) { $duplicate = true; break; }
            if ( $duplicate ) { $duplicates++; continue; }
            $id = wp_insert_comment( wp_slash( [ 'comment_post_ID' => $pid, 'comment_author' => sanitize_text_field( $get( 'reviewer_name', 'Anonymous' ) ), 'comment_author_email' => $email, 'comment_content' => $content, 'comment_type' => 'review', 'comment_date' => $date, 'comment_date_gmt' => get_gmt_from_date( $date ), 'comment_approved' => $statuses[$status], 'comment_author_IP' => filter_var( $get( 'ip_address' ), FILTER_VALIDATE_IP ) ?: '', 'user_id' => 0,
                'comment_meta' => [ 'rating' => $rating, 'review_title' => sanitize_text_field( $get( 'title' ) ), '_sr_location' => sanitize_text_field( $get( 'location' ) ) ] + ( $cs ? [ 'cs_rating' => $cs ] : [] ) ] ));
            if ( ! $id ) { $skipped++; continue; }
            $photo_ids = [];
            foreach ( array_slice( array_filter( array_map( 'trim', explode( ',', $get( 'picture_urls' ) ) ) ), 0, 5 ) as $url ) {
                $attachment = attachment_url_to_postid( $url );
                if ( ! $attachment || ! in_array( get_post_mime_type( $attachment ), SR_Security::image_mimes(), true ) ) $attachment = SR_Security::remote_photo( $url, $pid );
                if ( is_wp_error( $attachment ) ) $photo_errors++;
                else $photo_ids[] = $attachment;
            }
            if ( $photo_ids ) update_comment_meta( $id, 'review_photos', $photo_ids );
            if ( $get( 'reply' ) !== '' ) {
                $reply_date = $this->csv_date( $get( 'reply_date' ) );
                wp_insert_comment( wp_slash( [ 'comment_post_ID' => $pid, 'comment_parent' => $id, 'comment_author' => get_bloginfo( 'name' ) . ' Support', 'comment_content' => sanitize_textarea_field( $get( 'reply' ) ), 'comment_type' => 'review', 'comment_approved' => 1, 'comment_date' => $reply_date ?: $date, 'comment_date_gmt' => get_gmt_from_date( $reply_date ?: $date ), 'user_id' => get_current_user_id() ] ));
            }
            if ( class_exists( 'WC_Comments' ) ) WC_Comments::clear_transients( $pid );
            $count++;
        }
        fclose( $file );
        wp_send_json_success( [ 'message' => "Imported $count reviews. Skipped $duplicates duplicates and $skipped invalid or excess rows. $photo_errors photos could not be imported." ] );
    }

    private function csv_date( $date ) {
        if ( $date === '' ) return current_time( 'mysql' );
        try { return ( new DateTimeImmutable( $date, wp_timezone() ) )->format( 'Y-m-d H:i:s' ); }
        catch ( Exception $error ) { return false; }
    }

    private function get_stats_data() {
        $reviews = get_comments(['type'=>'review', 'status'=>'approve', 'parent'=>0]);
        $total = count($reviews); $sum=0; $rated_count=0; $counts=[1=>0,2=>0,3=>0,4=>0,5=>0];
        $cs_sum = 0; $cs_count = 0;
        foreach($reviews as $r) {
            $v=(int)get_comment_meta($r->comment_ID,'rating',true); if($v>=1 && $v<=5) { $sum+=$v; $counts[$v]++; $rated_count++; }
            $cs = (int) get_comment_meta( $r->comment_ID, 'cs_rating', true );
            if ( $cs >= 1 && $cs <= 5 ) { $cs_sum += $cs; $cs_count++; }
        }
        return [
            'total'    => $total,
            'avg'      => $rated_count ? round( $sum / $rated_count, 1 ) : 0,
            'counts'   => $counts,
            'cs_avg'   => $cs_count ? round( $cs_sum / $cs_count, 1 ) : 0,
            'cs_count' => $cs_count,
        ];
    }

    private function get_accurate_counts() {
        global $wpdb;
        $results = $wpdb->get_results( "SELECT comment_approved, COUNT(*) as num FROM {$wpdb->comments} WHERE comment_type = 'review' AND comment_parent = 0 GROUP BY comment_approved" );
        $stats = [ 'all' => 0, 'approve' => 0, 'hold' => 0, 'spam' => 0, 'trash' => 0 ];
        foreach ( $results as $row ) {
            if ( $row->comment_approved == '1' ) $stats['approve'] = intval( $row->num );
            elseif ( $row->comment_approved == '0' ) $stats['hold'] = intval( $row->num );
            elseif ( $row->comment_approved == 'spam' ) $stats['spam'] = intval( $row->num );
            elseif ( $row->comment_approved == 'trash' ) $stats['trash'] = intval( $row->num );
        }
        $stats['all'] = $stats['approve'] + $stats['hold'];
        return $stats;
    }
}
