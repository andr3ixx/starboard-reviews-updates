<?php
if ( ! defined('ABSPATH') ) exit;

/** Reuse existing Turnstile settings; verification always runs on the WordPress server. */
class SR_Antispam {
    public function __construct(){add_action('wp_enqueue_scripts',[$this,'assets'],25);}
    public static function keys(){
        $site=defined('SR_TURNSTILE_SITE_KEY')?SR_TURNSTILE_SITE_KEY:get_option('cfturnstile_key','');
        $secret=defined('SR_TURNSTILE_SECRET_KEY')?SR_TURNSTILE_SECRET_KEY:get_option('cfturnstile_secret','');
        return ['site'=>is_string($site)?trim($site):'','secret'=>is_string($secret)?trim($secret):''];
    }
    public static function required(){ $keys=self::keys();return $keys['site']!==''||$keys['secret']!==''; }
    public function assets(){
        if(!self::required())return;
        if(function_exists('cfturnstile_register_api')){cfturnstile_register_api(['in_footer'=>true]);$api='cfturnstile';wp_enqueue_script($api);}
        else{$api='sr-turnstile-api';wp_enqueue_script($api,'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit',[],null,true);}
        wp_enqueue_script('sr-antispam',SR_URL.'assets/antispam.js',['jquery','sr-front',$api],SR_VERSION,true);
    }
    public static function field($preview=false){
        echo '<div class="sr-honeypot" aria-hidden="true"><label>Leave this field empty<input type="text" name="sr_website" tabindex="-1" autocomplete="off"></label></div>';
        if($preview||!self::required())return;
        $keys=self::keys();
        echo '<div class="sr-verification"><div data-sr-turnstile data-sitekey="'.esc_attr($keys['site']).'"></div><p class="sr-verification-status" role="status">Security verification loads when you open this form.</p><button type="button" class="sr-link-btn" data-sr-turnstile-retry hidden>Retry verification</button></div>';
    }
    public static function attempt(){
        if(SR_Security::text('sr_website')!=='')return new WP_Error('sr_spam','Your review could not be submitted. Please try again.');
        $key='sr_attempt_'.hash('sha256',(string)($_SERVER['REMOTE_ADDR']??''));
        $window=get_transient($key);$now=time();
        if(!is_array($window)||($window['start']??0)<$now-600)$window=['start'=>$now,'count'=>0];
        if($window['count']>=20)return new WP_Error('sr_attempt_limit','Too many attempts. Please wait a few minutes and try again.');
        $window['count']++;set_transient($key,$window,max(1,600-($now-$window['start'])));
        return true;
    }
    public static function verify(){
        if(!self::required())return true;
        $keys=self::keys();
        if(!$keys['site']||!$keys['secret'])return new WP_Error('sr_verification_unavailable','Security verification is temporarily unavailable. Please try again later.');
        $token=SR_Security::text('cf-turnstile-response');
        if(!$token||strlen($token)>2048)return new WP_Error('sr_verification_required','Please complete the security verification before submitting.');
        $used='sr_verified_'.hash('sha256',$token);
        if(get_transient($used))return new WP_Error('sr_verification_used','Verification expired. Please complete the new security check.');
        $response=wp_remote_post('https://challenges.cloudflare.com/turnstile/v0/siteverify',['timeout'=>8,'redirection'=>0,'limit_response_size'=>16384,'body'=>['secret'=>$keys['secret'],'response'=>$token]]);
        if(is_wp_error($response)||wp_remote_retrieve_response_code($response)!==200)return new WP_Error('sr_verification_unavailable','Security verification is temporarily unavailable. Please try again.');
        $data=json_decode(wp_remote_retrieve_body($response),true);
        $host=strtolower((string)wp_parse_url(home_url(),PHP_URL_HOST));
        if(!is_array($data)||($data['success']??false)!==true||!is_string($data['hostname']??null)||strtolower($data['hostname'])!==$host||($data['action']??'')!=='starboard-review')return new WP_Error('sr_verification_failed','Security verification failed or expired. Please complete the new check.');
        set_transient($used,true,300);
        return true;
    }
}
