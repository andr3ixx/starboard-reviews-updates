<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SR_Cron {

    public function __construct() {
        add_action( 'admin_post_sr_unsubscribe', [ $this, 'unsubscribe' ] );
        add_action( 'admin_post_nopriv_sr_unsubscribe', [ $this, 'unsubscribe' ] );
        add_filter( 'cron_schedules', [ $this, 'add_custom_interval' ] );
        add_action( 'sr_cron_send_emails', [ $this, 'process_queue' ] );

        $schedule = wp_get_schedule( 'sr_cron_send_emails' );
        if ( $schedule !== 'five_minutes' ) {
            wp_clear_scheduled_hook( 'sr_cron_send_emails' );
            wp_schedule_event( time(), 'five_minutes', 'sr_cron_send_emails' );
        }
        add_action( 'woocommerce_order_status_completed', [ $this, 'trigger_from_order' ], 10, 1 );
    }

    public function add_custom_interval( $schedules ) {
        $schedules['five_minutes'] = [ 'interval' => 300, 'display'  => __( 'Every 5 Minutes' ) ];
        return $schedules;
    }

    public static function defaults( $level ) {
        $templates = [
            1 => [ 'subject' => 'How was your experience?', 'body' => "Hi {name},\n\nThanks for your purchase! We'd love to hear your thoughts.\n\nPlease review your items:\n{products}" ],
            2 => [ 'subject' => 'Just a reminder', 'body' => "Hi {name},\n\nJust a quick reminder to leave a review.\n\n{order_table}" ],
            3 => [ 'subject' => 'How did we do?', 'body' => "Hi {name},\n\nWe'd love to know how our team took care of you during your recent order. Got a minute to share your experience?\n\n{order_table}" ],
        ];
        return $templates[(int) $level] ?? $templates[1];
    }

    public function trigger_from_order( $order_id ) {
        $this->schedule_request( $order_id, 1 );
    }

    /**
     * @param bool   $force_now Skip the configured delay and send immediately, regardless of order status.
     *                          Used for manual sends so they don't depend on WooCommerce order status.
     * @param string $source    'auto' (order-status triggered) or 'manual' (admin-triggered).
     * @return string One of: no_order, no_items, duplicate, sent, scheduled.
     */
    public function schedule_request( $order_id, $level = 1, $force_now = false, $source = 'auto' ) {
        global $wpdb;
        $table = $wpdb->prefix . 'sr_requests';

        if ( ! function_exists( 'wc_get_order' ) ) return 'no_order';
        $order = wc_get_order( $order_id );
        if ( ! $order ) return 'no_order';
        if ( ! is_email( $order->get_billing_email() ) ) return 'failed';
        try {
            if ( $this->is_unsubscribed( $order->get_billing_email() ) ) return 'unsubscribed';
        } catch ( RuntimeException $error ) {
            return 'failed';
        }

        // --- 1. VALIDATION: CHECK IF ORDER HAS ELIGIBLE PRODUCTS ---
        // We mirror the send_request logic here. If no items pass, we don't schedule.
        $excluded_ids = get_option( 'sr_excluded_products', '' );
        $included_ids = get_option( 'sr_included_products', '' );

        $ex_array = ! empty( $excluded_ids ) ? array_map( 'trim', explode( ',', $excluded_ids ) ) : [];
        $in_array = ! empty( $included_ids ) ? array_map( 'trim', explode( ',', $included_ids ) ) : [];

        $has_valid_items = false;

        foreach ( $order->get_items() as $item ) {
            $pid = $item->get_product_id();
            $vid = $item->get_variation_id();

            // Rule A: Is it excluded?
            if ( in_array( $pid, $ex_array ) || in_array( $vid, $ex_array ) ) {
                continue;
            }

            // Rule B: Is there an "Include Only" list? If so, is it in there?
            if ( ! empty( $in_array ) ) {
                if ( ! in_array( $pid, $in_array ) && ! in_array( $vid, $in_array ) ) {
                    continue;
                }
            }

            // If we passed both checks, the order has at least one valid item.
            $has_valid_items = true;
            break; // No need to check further
        }

        // STOP HERE if no valid items found. Do not schedule.
        if ( ! $has_valid_items ) return 'no_items';


        // Serialize scheduling per order/tier. Keep old duplicate log rows intact.
        $lock = 'sr_' . md5( $wpdb->prefix . ':' . $order_id . ':' . $level );
        if ( (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock ) ) !== '1' ) return 'busy';
        $request_id = 0;
        $delay_days = $force_now ? 0 : max( 0, (int) get_option( 'sr_delay_' . $level, 5 ) );
        try {
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE order_id = %d AND level = %d", $order_id, $level ) );
            if ( $exists ) return 'duplicate';
            $date = new DateTimeImmutable( 'now', wp_timezone() );
            $date = $date->modify( '+' . $delay_days . ' days' );
            $inserted = $wpdb->insert( $table, [
                'order_id' => $order_id, 'customer_name' => $order->get_billing_first_name(),
                'customer_email' => strtolower( $order->get_billing_email() ), 'level' => $level,
                'status' => 'pending', 'source' => $source, 'scheduled_date' => $date->format( 'Y-m-d H:i:s' ),
                'unsubscribe_token' => bin2hex( random_bytes( 32 ) ),
            ] );
            if ( ! $inserted ) return 'failed';
            $request_id = $wpdb->insert_id;
        } finally {
            $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
        }
        return $delay_days === 0 ? $this->process_request( $request_id ) : 'scheduled';
    }

    public function process_queue() {
        if ( ! function_exists( 'wc_get_order' ) ) return;
        global $wpdb;
        $table = $wpdb->prefix . 'sr_requests';
        // A timed-out worker may have sent mail. Flag for manual investigation;
        // never automatically resend an ambiguous delivery.
        $wpdb->query( $wpdb->prepare( "UPDATE $table SET status = 'failed' WHERE status = 'sending' AND processing_date < %s", gmdate( 'Y-m-d H:i:s', time() - HOUR_IN_SECONDS ) ) );
        $ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $table WHERE status = 'pending' AND scheduled_date <= %s ORDER BY scheduled_date, id LIMIT 20", current_time( 'mysql' ) ) );
        foreach ( $ids as $id ) $this->process_request( $id );
    }

    public function process_request( $id, $resend = false ) {
        global $wpdb;
        $table = $wpdb->prefix . 'sr_requests';
        if ( ! function_exists( 'wc_get_order' ) ) return 'failed';
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
        if ( ! $row ) return 'failed';
        // Also serialize old duplicate rows by order/tier, without deleting history.
        $lock = 'sr_send_' . md5( $wpdb->prefix . ':' . $row->order_id . ':' . $row->level );
        if ( (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock ) ) !== '1' ) return 'busy';
        try {
            $claimed = $wpdb->query( $wpdb->prepare( "UPDATE $table SET status = 'sending', processing_date = %s WHERE id = %d AND status = 'pending' AND scheduled_date <= %s", gmdate( 'Y-m-d H:i:s' ), $id, current_time( 'mysql' ) ) );
            if ( $claimed !== 1 ) return 'busy';
            if ( ! $resend ) {
                $sent_before = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE order_id = %d AND level = %d AND id <> %d AND status = 'sent' LIMIT 1", $row->order_id, $row->level, $id ) );
                if ( $sent_before ) {
                    $wpdb->update( $table, [ 'status' => 'cancelled' ], [ 'id' => $id ] );
                    return 'duplicate';
                }
            }
            return $this->send_request( $row );
        } catch ( Throwable $error ) {
            $wpdb->update( $table, [ 'status' => 'failed' ], [ 'id' => $id, 'status' => 'sending' ] );
            return 'failed';
        } finally {
            $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
        }
    }

    public function is_unsubscribed( $email ) {
        global $wpdb;
        $id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}sr_unsubscribes WHERE email = %s", strtolower( $email ) ) );
        if ( $wpdb->last_error ) throw new RuntimeException( 'Unable to verify email preferences.' );
        return (bool) $id;
    }

    public function unsubscribe() {
        global $wpdb;
        $id = absint( SR_Security::text( 'id', $_REQUEST ) );
        $token = SR_Security::text( 'token', $_REQUEST );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}sr_requests WHERE id = %d", $id ) );
        nocache_headers();
        if ( ! $row || ! $row->unsubscribe_token || ! hash_equals( $row->unsubscribe_token, $token ) ) wp_die( 'Invalid unsubscribe link.', '', [ 'response' => 400 ] );
        if ( ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) !== 'POST' ) {
            $form = '<p>Stop review request emails from ' . esc_html( get_bloginfo( 'name' ) ) . '?</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="sr_unsubscribe"><input type="hidden" name="id" value="' . (int) $id . '"><input type="hidden" name="token" value="' . esc_attr( $token ) . '"><button type="submit">Unsubscribe</button></form>';
            wp_die( $form, 'Review email preferences', [ 'response' => 200 ] );
        }
        $saved = $wpdb->query( $wpdb->prepare( "INSERT INTO {$wpdb->prefix}sr_unsubscribes (email) VALUES (%s) ON DUPLICATE KEY UPDATE email = VALUES(email)", strtolower( $row->customer_email ) ) );
        if ( $saved === false ) wp_die( 'Unable to save your preference. Please try again.', '', [ 'response' => 500 ] );
        $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->prefix}sr_requests SET status = 'cancelled' WHERE customer_email = %s AND status = 'pending'", $row->customer_email ) );
        wp_die( 'You have been unsubscribed from review request emails.', 'Unsubscribed', [ 'response' => 200 ] );
    }

    private function send_request( $row ) {
        global $wpdb;
        $table = $wpdb->prefix . 'sr_requests';

        if ( $this->is_unsubscribed( $row->customer_email ) ) {
            $wpdb->update( $table, [ 'status' => 'cancelled' ], [ 'id' => $row->id ] );
            return 'unsubscribed';
        }
        $defaults = self::defaults( $row->level );
        $subject = sanitize_text_field( get_option( 'sr_subject_' . $row->level, $defaults['subject'] ) );
        $raw_body = wp_kses_post( get_option( 'sr_body_' . $row->level, $defaults['body'] ) );
        $template_type = get_option( 'sr_email_template_type', 'modern' );

        $order = wc_get_order( $row->order_id );
        if ( ! $order ) {
            $wpdb->update( $table, [ 'status' => 'failed' ], [ 'id' => $row->id ] );
            return 'failed';
        }

        if ( isset( $row->source ) && $row->source === 'auto' && $order->get_status() !== 'completed' ) {
            $wpdb->update( $table, [ 'status' => 'cancelled' ], [ 'id' => $row->id ] );
            return 'cancelled';
        }

        // --- FILTER PRODUCTS ---
        $excluded_ids = get_option( 'sr_excluded_products', '' );
        $included_ids = get_option( 'sr_included_products', '' );
        $ex_array = ! empty( $excluded_ids ) ? array_map( 'trim', explode( ',', $excluded_ids ) ) : [];
        $in_array = ! empty( $included_ids ) ? array_map( 'trim', explode( ',', $included_ids ) ) : [];

        $valid_items = [];
        foreach ( $order->get_items() as $item ) {
            $pid = $item->get_product_id();
            $vid = $item->get_variation_id();

            // Exclude Check
            if ( in_array( $pid, $ex_array ) || in_array( $vid, $ex_array ) ) continue;

            // Include Check
            if ( ! empty( $in_array ) ) {
                if ( ! in_array( $pid, $in_array ) && ! in_array( $vid, $in_array ) ) continue;
            }

            $valid_items[] = $item;
        }

        if ( empty( $valid_items ) ) {
            $wpdb->update( $table, [ 'status' => 'cancelled' ], [ 'id' => $row->id ] );
            return 'no_items';
        }

        // --- BUILD HTML TABLE (INLINE STYLES FOR GMAIL) ---
        $brand_color = sanitize_hex_color( get_option('sr_color_admin', '#2563eb') ) ?: '#2563eb';
        $btn_color   = sanitize_hex_color( get_option('sr_color_widget', '#2563eb') ) ?: '#2563eb';

        // Logo Settings
        $logo_enabled = get_option( 'sr_email_logo_enabled', 0 );
        $logo_url     = get_option( 'sr_email_logo_url', '' );
        $logo_height  = get_option( 'sr_email_logo_height', '40' );

        // ** MODERN TABLE **
        // Using purely inline styles on TDs to survive email forwarding
        if ( $template_type === 'modern' ) {
            $table_html = '<div style="background:#fff; border:1px solid #e5e7eb; border-radius:8px; overflow:hidden; margin-top:20px;">';

            foreach ( $valid_items as $item ) {
                $product = $item->get_product();
                if ( ! $product ) continue;
                $link = get_permalink( $product->get_id() ) . '#sr-widget';
                $img_url = wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' );
                if(!$img_url) $img_url = wc_placeholder_img_src();

                $table_html .= '
                <table width="100%" cellspacing="0" cellpadding="0" border="0" style="border-bottom:1px solid #f3f4f6;">
                    <tr>
                        <td width="80" style="padding:15px 0 15px 15px; vertical-align:middle;">
                            <img src="'.esc_url($img_url).'" width="60" height="60" style="border-radius:6px; object-fit:cover; display:block;">
                        </td>
                        <td style="padding:15px 10px; vertical-align:middle;">
                            <div style="font-family:Helvetica, Arial, sans-serif; font-weight:600; color:#111827; font-size:15px; line-height:1.4;">'.esc_html($item->get_name()).'</div>
                            <div style="font-family:Helvetica, Arial, sans-serif; font-size:13px; color:#6b7280; margin-top:4px;">'.$order->get_formatted_line_subtotal($item).'</div>
                        </td>
                        <td width="100" align="right" style="padding:15px 15px 15px 0; vertical-align:middle;">
                            <a href="'.esc_url($link).'" style="background:'.$btn_color.'; color:#ffffff; text-decoration:none; padding:8px 18px; border-radius:6px; font-size:13px; font-weight:bold; white-space:nowrap; display:inline-block; font-family:Helvetica, Arial, sans-serif; border:1px solid '.$btn_color.';">Review</a>
                        </td>
                    </tr>
                </table>';
            }
            $table_html .= '</div>';
        } else {
            // ** WC TABLE **
            $table_html = '<table width="100%" cellspacing="0" cellpadding="10" border="0">';
            foreach ( $valid_items as $item ) {
                $product = $item->get_product();
                if ( ! $product ) continue;
                $link = get_permalink( $product->get_id() ) . '#sr-widget';
                $table_html .= '<tr><td style="padding:10px 0;"><strong>'.esc_html($item->get_name()).'</strong></td><td style="text-align:right;"><a href="'.esc_url($link).'">Review</a></td></tr>';
            }
            $table_html .= '</table>';
        }

        // --- CONTENT REPLACEMENT ---
        $replacements = [
            '{first_name}'  => esc_html( $order->get_billing_first_name() ),
            '{last_name}'   => esc_html( $order->get_billing_last_name() ),
            '{order_id}'    => esc_html( $order->get_order_number() ),
            '{shop_name}'   => esc_html( get_bloginfo( 'name' ) ),
            '{order_table}' => $table_html,
            '{products}'    => $table_html,
            '{name}'        => esc_html( $order->get_billing_first_name() )
        ];
        $message_body = str_replace( array_keys($replacements), array_values($replacements), $raw_body );

        // --- HEADER CONTENT (Modern Only) ---
        if ( $logo_enabled && ! empty( $logo_url ) ) {
            $header_content = '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" style="height:' . intval( $logo_height ) . 'px; width:auto; display:block; margin:0 auto; border:0;">';
        } else {
            $header_content = '<h1 style="margin:0; color:#ffffff; font-size:24px; font-weight:bold; font-family:Helvetica, Arial, sans-serif;">' . esc_html( get_bloginfo( 'name' ) ) . '</h1>';
        }

        // --- FINAL WRAPPER ---
        if ( $template_type === 'woocommerce' ) {
            // WOOCOMMERCE TEMPLATE WRAPPER
            ob_start();

            // WC Emails expect specific styles. Since we are manually sending, we rely on the theme's header/footer.
            wc_get_template( 'emails/email-header.php', array( 'email_heading' => $subject ) );
            echo wpautop( $message_body );
            wc_get_template( 'emails/email-footer.php' );

            $final_html = ob_get_clean();

            // FIX: Manually replace WC footer placeholders if they failed to parse
            $final_html = str_replace( '{site_title}', get_bloginfo( 'name' ), $final_html );
            $final_html = str_replace( '{site_address}', parse_url( home_url(), PHP_URL_HOST ), $final_html );

        } else {
            // MODERN TEMPLATE (INLINE STYLES FOR FORWARDING)
            // Note: We use a table-based layout wrapper for maximum email client compatibility
            $shop_name = esc_html( get_bloginfo('name') );
            $year = date('Y');

            $final_html = '
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>' . esc_html($subject) . '</title>
            </head>
            <body style="margin:0; padding:0; background-color:#f3f4f6; font-family:Helvetica, Arial, sans-serif;">
                <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background-color:#f3f4f6; width:100%;">
                    <tr>
                        <td align="center" style="padding:40px 10px;">
                            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width:600px; background-color:#ffffff; border-radius:8px; overflow:hidden; box-shadow:0 4px 6px rgba(0,0,0,0.05);">
                                <tr>
                                    <td style="background-color:' . $brand_color . '; padding:30px; text-align:center;">
                                        ' . $header_content . '
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:40px 30px; color:#374151; line-height:1.6; font-size:16px;">
                                        ' . wpautop($message_body) . '
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding:30px; text-align:center; background-color:#f9fafb; color:#9ca3af; font-size:12px;">
                                        &copy; ' . $year . ' ' . $shop_name . '. All rights reserved.
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </body>
            </html>';
        }

        // Legacy queued rows receive a token lazily, before their first send.
        if ( empty( $row->unsubscribe_token ) ) {
            $row->unsubscribe_token = bin2hex( random_bytes( 32 ) );
            if ( $wpdb->update( $table, [ 'unsubscribe_token' => $row->unsubscribe_token ], [ 'id' => $row->id ] ) === false ) return 'failed';
        }
        $unsubscribe_url = add_query_arg( [ 'action' => 'sr_unsubscribe', 'id' => $row->id, 'token' => $row->unsubscribe_token ], admin_url( 'admin-post.php' ) );
        $footer = '<p style="text-align:center;font-size:12px;"><a href="' . esc_url( $unsubscribe_url ) . '">Unsubscribe from review request emails</a></p>';
        $final_html = strpos( $final_html, '</body>' ) !== false ? str_replace( '</body>', $footer . '</body>', $final_html ) : $final_html . $footer;
        if ( $this->is_unsubscribed( $row->customer_email ) ) {
            $wpdb->update( $table, [ 'status' => 'cancelled' ], [ 'id' => $row->id ] );
            return 'unsubscribed';
        }
        $headers = [ 'Content-Type: text/html; charset=UTF-8', 'List-Unsubscribe: <' . esc_url_raw( $unsubscribe_url ) . '>' ];
        $sent = wp_mail( $row->customer_email, $subject, $final_html, $headers );
        if ( ! $sent ) {
            $wpdb->update( $table, [ 'status' => 'failed' ], [ 'id' => $row->id ] );
            return 'failed';
        }
        if ( $wpdb->update( $table, [ 'status' => 'sent', 'sent_date' => current_time( 'mysql' ) ], [ 'id' => $row->id ] ) === false ) return 'failed';
        if ( (int) $row->level === 1 && get_option( 'sr_enable_followup' ) ) {
            $this->schedule_request( $row->order_id, 2, false, $row->source ?? 'auto' );
        }
        return 'sent';
    }
}
