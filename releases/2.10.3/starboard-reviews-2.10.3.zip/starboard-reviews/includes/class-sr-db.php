<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SR_DB {

    // Bump this whenever the schema below changes so existing installs get dbDelta'd again.
    const DB_VERSION = '1.2';

    public static function install() {
        if ( ! self::run_schema() ) wp_die( 'Starboard Reviews could not create its database tables. Check database permissions and try again.' );
        update_option( 'sr_db_version', self::DB_VERSION );
    }

    // Runs on every load; re-applies schema (dbDelta is safe/idempotent) if the version changed,
    // so sites that already have the plugin active pick up new columns without a reactivation.
    public static function maybe_upgrade() {
        if ( get_option( 'sr_db_version' ) !== self::DB_VERSION ) {
            if ( self::run_schema() ) update_option( 'sr_db_version', self::DB_VERSION );
            else add_action( 'admin_notices', function() { echo '<div class="notice notice-error"><p>Starboard Reviews database upgrade failed. Check database permissions before sending requests.</p></div>'; } );
        }
    }

    private static function run_schema() {
        global $wpdb;
        $collate = $wpdb->get_charset_collate();

        // 1. Requests Table
        $sql1 = "CREATE TABLE {$wpdb->prefix}sr_requests (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            order_id bigint(20) NOT NULL,
            customer_email varchar(254) NOT NULL,
            customer_name varchar(200) NOT NULL,
            status varchar(20) DEFAULT 'scheduled',
            level tinyint(1) DEFAULT 1,
            opened tinyint(1) DEFAULT 0,
            source varchar(10) DEFAULT 'auto',
            scheduled_date datetime DEFAULT NULL,
            sent_date datetime DEFAULT NULL,
            processing_date datetime DEFAULT NULL,
            unsubscribe_token varchar(64) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            KEY order_id (order_id),
            KEY order_level (order_id,level),
            KEY due_requests (status,scheduled_date)
        ) $collate;";

        // 2. Unsubscribes Table
        $sql2 = "CREATE TABLE {$wpdb->prefix}sr_unsubscribes (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            email varchar(254) NOT NULL UNIQUE,
            date_unsubscribed datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $collate;";

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql1 );
        dbDelta( $sql2 );
        return (bool) $wpdb->get_var( "SHOW COLUMNS FROM {$wpdb->prefix}sr_requests LIKE 'processing_date'" ) && (bool) $wpdb->get_var( "SHOW TABLES LIKE '" . $wpdb->esc_like( $wpdb->prefix . 'sr_unsubscribes' ) . "'" );
    }
}
