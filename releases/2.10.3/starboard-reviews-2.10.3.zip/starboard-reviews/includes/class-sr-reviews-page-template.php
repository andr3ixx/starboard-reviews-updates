<?php
if ( ! defined('ABSPATH') ) exit;

/** Optional classic-theme page template, independent of theme and page-builder files. */
class SR_Reviews_Page_Template {
    const SLUG = 'starboard-reviews-page.php';
    const META = '_sr_reviews_page';

    public function __construct() {
        add_filter('theme_page_templates',[$this,'templates']);
        add_filter('template_include',[$this,'template'],99);
        add_action('add_meta_boxes_page',[$this,'box']);
        add_action('save_post_page',[$this,'save']);
        add_action('wp_enqueue_scripts',[$this,'assets'],20);
        add_shortcode('starboard_reviews_page',[$this,'render']);
    }
    public static function defaults() {
        return ['product_id'=>'0','heading'=>'In their own words.','intro'=>'Read customer experiences, explore the details, and share your own.','image'=>'','image_alt'=>'Our product out on the water.','cta_url'=>'','cta_label'=>'Explore the product'];
    }
    public static function normalize($input) {
        $input=is_array($input)?$input:[];
        $a=self::defaults();
        foreach($a as $key=>$value)if(isset($input[$key])&&is_scalar($input[$key]))$a[$key]=$input[$key];
        $a['product_id']=absint($a['product_id']);
        foreach(['heading','intro','image_alt','cta_label'] as $key)$a[$key]=sanitize_text_field($a[$key]);
        foreach(['image','cta_url'] as $key)$a[$key]=esc_url_raw($a[$key],['https','http']);
        return $a;
    }
    public function templates($templates) { $templates[self::SLUG]='Starboard · Reviews page';return $templates; }
    public function template($path) {
        return is_page()&&get_page_template_slug(get_queried_object_id())===self::SLUG ? SR_PATH.'includes/templates/reviews-page.php' : $path;
    }
    public function assets() {
        $post=get_post();
        if(is_page()&&(get_page_template_slug(get_queried_object_id())===self::SLUG||($post&&has_shortcode($post->post_content,'starboard_reviews_page'))))wp_enqueue_style('sr-reviews-page',SR_URL.'assets/reviews-page.css',['sr-front'],SR_VERSION);
    }
    public function box() { add_meta_box('sr-reviews-page-options','Starboard reviews page',[$this,'fields'],'page','normal','default'); }
    public function fields($post) {
        $a=self::normalize(get_post_meta($post->ID,self::META,true));
        wp_nonce_field('sr_reviews_page_save','sr_reviews_page_nonce');
        echo '<p>Select <strong>Starboard · Reviews page</strong> in this page’s Template setting to use these options. Existing page-builder content is retained for rollback.</p>';
        foreach(['product_id'=>'Product ID (0 = all public products)','heading'=>'Page heading','intro'=>'Introduction','image'=>'Hero image URL (optional)','image_alt'=>'Hero image description','cta_url'=>'Product link (optional; uses the selected product by default)','cta_label'=>'Product button label'] as $key=>$label) {
            $type=$key==='product_id'?'number':(in_array($key,['image','cta_url'],true)?'url':'text');
            echo '<p><label for="sr-page-'.esc_attr($key).'"><strong>'.esc_html($label).'</strong></label><br><input class="widefat" id="sr-page-'.esc_attr($key).'" name="sr_reviews_page['.esc_attr($key).']" type="'.$type.'" '.($type==='number'?'min="0"':'').' value="'.esc_attr($a[$key]).'"></p>';
        }
    }
    public function save($id) {
        if(wp_is_post_autosave($id)||wp_is_post_revision($id)||!current_user_can('edit_post',$id)||!isset($_POST['sr_reviews_page_nonce'])||!is_string($_POST['sr_reviews_page_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['sr_reviews_page_nonce'])),'sr_reviews_page_save'))return;
        if(!isset($_POST['sr_reviews_page'])||!is_array($_POST['sr_reviews_page']))return;
        update_post_meta($id,self::META,wp_slash(self::normalize(wp_unslash($_POST['sr_reviews_page']))));
    }
    public static function render($input=[]) {
        $a=self::normalize($input);$pid=$a['product_id'];
        if($pid&&(get_post_type($pid)!=='product'||get_post_status($pid)!=='publish'||post_password_required($pid)))return '';
        $summary=SR_Widget::summary($pid);
        $shop=$a['cta_url']?:($pid?get_permalink($pid):'');
        static $instance=0;$uid='sr-reviews-page-'.++$instance;
        ob_start(); ?>
        <div class="sr-reviews-page">
            <section class="sr-rp-hero sr-rp-container <?php if(!$a['image'])echo 'sr-rp-no-image'; ?>" aria-labelledby="<?php echo esc_attr($uid); ?>-heading">
                <div class="sr-rp-intro"><span class="sr-rp-eyebrow">Customer reviews</span><h1 id="<?php echo esc_attr($uid); ?>-heading"><?php echo esc_html($a['heading']); ?></h1><p class="sr-rp-lead"><?php echo esc_html($a['intro']); ?></p>
                    <?php if($summary['count']): ?><a class="sr-rp-rating" href="#<?php echo esc_attr($uid); ?>-reviews"><span class="sr-stars-static" role="img" aria-label="<?php echo esc_attr($summary['avg'].' out of 5 stars'); ?>" style="--v:<?php echo (float)$summary['avg']; ?>"></span><strong><?php echo esc_html($summary['avg']); ?> / 5</strong><span>from <?php echo (int)$summary['count']; ?> customer reviews</span></a><?php endif; ?>
                    <div class="sr-rp-actions"><a class="sr-rp-button" href="#<?php echo esc_attr($uid); ?>-reviews">Read the reviews <span class="sr-icon sr-icon-arrow-down" aria-hidden="true"></span></a><?php if($shop): ?><a class="sr-rp-text-link" href="<?php echo esc_url($shop); ?>"><?php echo esc_html($a['cta_label']); ?><span class="sr-icon sr-icon-arrow-up-right" aria-hidden="true"></span></a><?php endif; ?></div>
                </div>
                <?php if($a['image']): ?><figure class="sr-rp-image"><?php $image_id=attachment_url_to_postid($a['image']);if($image_id):echo wp_get_attachment_image($image_id,'large',false,['alt'=>$a['image_alt'],'loading'=>'eager','fetchpriority'=>'high','sizes'=>'(max-width: 760px) 100vw, 560px']);else: ?><img src="<?php echo esc_url($a['image']); ?>" alt="<?php echo esc_attr($a['image_alt']); ?>" width="1120" height="1040" fetchpriority="high" decoding="async"><?php endif; ?><figcaption>Out on the water. In everyday use.</figcaption></figure><?php endif; ?>
            </section>
            <section class="sr-rp-review-section" id="<?php echo esc_attr($uid); ?>-reviews" aria-label="Customer ratings and reviews"><div class="sr-rp-container"><?php echo (new SR_Widget())->render_shortcode(['product_id'=>$pid,'columns'=>3,'count'=>9,'min_rating'=>1,'title'=>'Every review. A real experience.','subtitle'=>'Customer feedback','excerpt'=>48],false,true); ?></div></section>
            <section class="sr-rp-after sr-rp-container" aria-label="Before you choose"><div><span class="sr-rp-eyebrow">Your next anchorage</span><h2>Get to know the product behind the reviews.</h2><p>Explore the details, or ask us a question before you choose.</p></div><?php if($shop): ?><a class="sr-rp-button" href="<?php echo esc_url($shop); ?>"><?php echo esc_html($a['cta_label']); ?><span class="sr-icon sr-icon-arrow-up-right" aria-hidden="true"></span></a><?php endif; ?></section>
        </div>
        <?php return ob_get_clean();
    }
}
