<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Shared validation for every entry point, including authenticated AJAX calls. */
class SR_Security {
    public static function authorize( $capability = 'manage_options' ) {
        check_ajax_referer( 'sr_admin_nonce', 'nonce' );
        if ( ! current_user_can( $capability ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
        }
    }

    public static function text( $key, $source = null ) {
        $source = $source === null ? $_POST : $source;
        if ( ! isset( $source[$key] ) ) return '';
        if ( ! is_scalar( $source[$key] ) ) {
            wp_send_json_error( [ 'message' => 'Invalid input.' ], 400 );
        }
        return wp_unslash( (string) $source[$key] );
    }

    public static function review( $id ) {
        $review = get_comment( $id );
        if ( ! $review || $review->comment_type !== 'review' || (int) $review->comment_parent !== 0 || get_post_type( $review->comment_post_ID ) !== 'product' ) {
            wp_send_json_error( [ 'message' => 'Review not found.' ], 404 );
        }
        if ( ! current_user_can( 'edit_comment', $id ) ) {
            wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
        }
        return $review;
    }

    /** Validate the entire batch before creating a review or moving any file. */
    public static function photos( $key = 'photos' ) {
        if ( empty( $_FILES[$key] ) ) return [];
        $batch = $_FILES[$key];
        if ( ! isset( $batch['name'] ) || ! is_array( $batch['name'] ) || count( $batch['name'] ) > 5 ) {
            return new WP_Error( 'photos', 'You can upload up to 5 photos.' );
        }
        $files = [];
        foreach ( $batch['name'] as $index => $name ) {
            $file = [];
            foreach ( [ 'name', 'type', 'tmp_name', 'error', 'size' ] as $field ) {
                if ( ! isset( $batch[$field][$index] ) || ! is_scalar( $batch[$field][$index] ) ) {
                    return new WP_Error( 'photos', 'Invalid photo upload.' );
                }
                $file[$field] = $batch[$field][$index];
            }
            if ( (int) $file['error'] === UPLOAD_ERR_NO_FILE ) continue;
            if ( (int) $file['error'] !== UPLOAD_ERR_OK || ! is_uploaded_file( $file['tmp_name'] ) || filesize( $file['tmp_name'] ) > min( wp_max_upload_size(), 5 * MB_IN_BYTES ) ) {
                return new WP_Error( 'photos', 'Each photo must be uploaded successfully and be no larger than 5 MB.' );
            }
            $type = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], self::image_mimes() );
            $dimensions = @getimagesize( $file['tmp_name'] );
            if ( empty( $type['ext'] ) || empty( $type['type'] ) || ! $dimensions || $dimensions[0] * $dimensions[1] > 20000000 ) {
                return new WP_Error( 'photos', 'Use JPEG, PNG or WebP photos no larger than 20 megapixels.' );
            }
            $files[] = $file;
        }
        return $files;
    }

    public static function image_mimes() {
        return [ 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ];
    }

    public static function remote_photo( $url, $pid ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        if ( ! wp_http_validate_url( $url ) ) return new WP_Error( 'photo', 'Invalid photo URL.' );
        $tmp = wp_tempnam();
        if ( ! $tmp ) return new WP_Error( 'photo', 'Unable to create a temporary file.' );
        $response = wp_safe_remote_get( $url, [ 'timeout' => 10, 'stream' => true, 'filename' => $tmp, 'limit_response_size' => 5 * MB_IN_BYTES + 1 ] );
        $name = sanitize_file_name( wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ) );
        $type = wp_check_filetype_and_ext( $tmp, $name, self::image_mimes() );
        $dimensions = @getimagesize( $tmp );
        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 || filesize( $tmp ) > min( wp_max_upload_size(), 5 * MB_IN_BYTES ) || empty( $type['ext'] ) || ! $dimensions || $dimensions[0] * $dimensions[1] > 20000000 ) {
            wp_delete_file( $tmp );
            return new WP_Error( 'photo', 'Unable to import this photo.' );
        }
        $id = media_handle_sideload( [ 'name' => $name, 'tmp_name' => $tmp ], $pid, null, [] );
        // media_handle_sideload moves a successful upload out of the temporary path.
        if ( file_exists( $tmp ) ) wp_delete_file( $tmp );
        return $id;
    }

    public static function upload_photos( $files, $pid ) {
        if ( ! $files ) return [];
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        $saved_files = $_FILES;
        $ids = [];
        foreach ( $files as $file ) {
            $_FILES['sr_photo'] = $file;
            $id = media_handle_upload( 'sr_photo', $pid, [], [ 'test_form' => false, 'mimes' => self::image_mimes() ] );
            if ( is_wp_error( $id ) ) {
                foreach ( $ids as $attachment ) wp_delete_attachment( $attachment, true );
                $_FILES = $saved_files;
                return $id;
            }
            $ids[] = $id;
        }
        $_FILES = $saved_files;
        return $ids;
    }
}
