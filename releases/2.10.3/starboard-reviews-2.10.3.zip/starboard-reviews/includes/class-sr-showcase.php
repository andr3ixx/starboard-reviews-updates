<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Curated review displays for home pages, landing pages and sidebars. */
class SR_Showcase {
    public function __construct() {
        add_shortcode( 'starboard_showcase', [ $this, 'render' ] );
        add_action( 'wp_ajax_sr_preview_showcase', [ $this, 'preview' ] );
    }

    public static function defaults() {
        return [ 'layout'=>'grid', 'count'=>'6', 'min_rating'=>'4', 'columns'=>'3', 'product_id'=>'0', 'review_ids'=>'', 'order'=>'newest', 'theme'=>'light', 'title'=>'What our customers say', 'subtitle'=>'Real experiences, in their own words.', 'show_summary'=>'true', 'show_product'=>'true', 'show_date'=>'true', 'show_photos'=>'false', 'autoplay'=>'false', 'interval'=>'6', 'excerpt'=>'38', 'link'=>'', 'position'=>'right', 'font'=>'default' ];
    }

    public static function normalize( $atts ) {
        $atts = is_array( $atts ) ? $atts : [];
        foreach ( $atts as $key => $value ) if ( ! is_scalar( $value ) ) unset( $atts[$key] );
        if ( isset( $atts['limit'] ) && ! isset( $atts['count'] ) ) $atts['count'] = $atts['limit'];
        $a = shortcode_atts( self::defaults(), $atts, 'starboard_showcase' );
        if ( $a['layout'] === 'slider' ) $a['layout'] = 'carousel';
        if ( $a['layout'] === 'pop-up' ) $a['layout'] = 'popup';
        if ( ! in_array( $a['layout'], [ 'grid','carousel','featured','list','wall','compact','button','badge','floating','popup','sidebar' ], true ) ) $a['layout']='grid';
        foreach ( [ 'count'=>[1,24], 'min_rating'=>[1,5], 'columns'=>[1,4], 'interval'=>[3,30], 'excerpt'=>[10,200] ] as $key => $bounds ) $a[$key] = max( $bounds[0], min( $bounds[1], (int) $a[$key] ) );
        if ( $a['layout'] === 'featured' ) $a['count']=1;
        if ( in_array( $a['layout'], [ 'sidebar','featured','list','compact' ], true ) ) $a['columns']=1;
        $a['product_id'] = absint( $a['product_id'] );
        $a['review_ids'] = array_slice( array_values( array_unique( array_filter( array_map( 'absint', explode( ',', (string) $a['review_ids'] ) ) ) ) ), 0, 24 );
        if ( ! in_array( $a['order'], [ 'newest','oldest','highest','lowest','manual' ], true ) ) $a['order']='newest';
        if ( ! in_array( $a['theme'], [ 'light','soft','dark' ], true ) ) $a['theme']='light';
        foreach ( [ 'show_summary','show_product','show_date','show_photos','autoplay' ] as $key ) $a[$key] = in_array( strtolower( (string) $a[$key] ), [ 'true','1','yes','on' ], true );
        $a['title'] = sanitize_text_field( $a['title'] );
        $a['subtitle'] = sanitize_text_field( $a['subtitle'] );
        $a['link'] = esc_url_raw( $a['link'], [ 'http','https' ] );
        if(!in_array($a['font'],['default','site','starboard'],true))$a['font']='default';
        $a['position'] = $a['position'] === 'left' ? 'left' : 'right';
        return $a;
    }

    public static function reviews( $a ) {
        $pid = $a['product_id'];
        if ( $pid && ( get_post_type( $pid ) !== 'product' || get_post_status( $pid ) !== 'publish' || post_password_required( $pid ) ) ) return [];
        $args = [ 'post_type'=>'product', 'post_status'=>'publish', 'post_id'=>$pid, 'type'=>'review', 'parent'=>0, 'status'=>'approve', 'number'=>$a['count'], 'orderby'=>'comment_date_gmt', 'order'=>$a['order']==='oldest'?'ASC':'DESC', 'meta_query'=>[ [ 'key'=>'rating', 'value'=>[$a['min_rating'],5], 'compare'=>'BETWEEN', 'type'=>'NUMERIC' ] ] ];
        if ( ! $pid ) $args['post__not_in'] = get_posts( [ 'post_type'=>'product','post_status'=>'publish','has_password'=>true,'numberposts'=>-1,'fields'=>'ids' ] );
        if ( $a['review_ids'] ) $args['comment__in']=$a['review_ids'];
        if ( $a['order']==='manual' && $a['review_ids'] ) $args['orderby']='comment__in';
        elseif ( in_array( $a['order'], [ 'highest','lowest' ], true ) ) { $args['meta_key']='rating'; $args['orderby']='meta_value_num'; $args['order']=$a['order']==='lowest'?'ASC':'DESC'; }
        return get_comments( $args );
    }

    private static function stars( $rating ) {
        $rating = max( 0, min( 5, (float) $rating ) );
        return '<span class="sr-stars-static" role="img" aria-label="'.esc_attr($rating.' out of 5 stars').'" style="--v:'.$rating.'"></span>';
    }

    private static function card( $review, $a ) {
        $id = $review->comment_ID;
        $rating = (int) get_comment_meta( $id, 'rating', true );
        $title = get_comment_meta( $id, 'review_title', true );
        $full = wp_strip_all_tags( $review->comment_content );
        $excerpt = wp_trim_words( $full, $a['excerpt'], '…' );
        $initial = function_exists( 'mb_substr' ) ? mb_substr( $review->comment_author, 0, 1 ) : substr( $review->comment_author, 0, 1 );
        ob_start(); ?>
        <article class="sr-showcase-card" role="listitem">
            <div class="sr-showcase-person"><span class="sr-showcase-avatar" aria-hidden="true"><?php echo esc_html( strtoupper($initial) ); ?></span><div><strong><?php echo esc_html($review->comment_author); ?></strong><?php if($a['show_date']): ?><time datetime="<?php echo esc_attr(substr($review->comment_date,0,10)); ?>"><?php echo esc_html(get_comment_date('M j, Y',$id)); ?></time><?php endif; ?></div></div>
            <?php echo self::stars($rating); ?>
            <?php if($title): ?><h3 class="sr-showcase-review-title"><?php echo esc_html($title); ?></h3><?php endif; ?>
            <p class="sr-showcase-excerpt"><?php echo esc_html($excerpt); ?></p>
            <?php if($excerpt!==$full): ?><details class="sr-showcase-details"><summary>Read full review <span class="sr-icon sr-icon-chevron-down" aria-hidden="true"></span></summary><p><?php echo esc_html($full); ?></p></details><?php endif; ?>
            <?php if($a['show_photos']): $photos=get_comment_meta($id,'review_photos',true); if(is_array($photos)): ?><div class="sr-showcase-photos"><?php foreach(array_slice($photos,0,3) as $photo): $url=wp_get_attachment_image_url($photo,'thumbnail'); if($url): ?><a href="<?php echo esc_url(wp_get_attachment_image_url($photo,'large')); ?>" target="_blank" rel="noopener noreferrer" aria-label="Open customer review photo"><img src="<?php echo esc_url($url); ?>" alt="Customer review photo" loading="lazy"></a><?php endif; endforeach; ?></div><?php endif; endif; ?>
            <?php if($a['show_product']): ?><a class="sr-showcase-product" href="<?php echo esc_url(get_permalink($review->comment_post_ID)); ?>"><?php echo esc_html(get_the_title($review->comment_post_ID)); ?><span class="sr-icon sr-icon-arrow-up-right" aria-hidden="true"></span></a><?php endif; ?>
        </article>
        <?php return ob_get_clean();
    }

    public function render( $atts = [] ) {
        $a = self::normalize( $atts );
        $reviews = self::reviews( $a );
        // Overall scores use the complete published product/store population, not
        // just a curated positive subset, or the selected review limit.
        $summary = SR_Widget::summary( $a['product_id'] );
        if ( ! $reviews && ( ! in_array($a['layout'],['button','badge','floating','popup'],true) || ! $summary['count'] ) ) return '';
        static $instance=0; $uid='sr-showcase-'.++$instance;
        $layout=$a['layout'];
        $panel=in_array($layout,['button','floating','popup'],true) || ($layout==='badge' && !$a['link']);
        $slider=in_array($layout,['carousel','sidebar'],true);
        $compact=in_array($layout,['button','badge','floating','popup'],true);
        ob_start(); ?>
        <section class="sr-showcase sr-showcase--<?php echo esc_attr($layout); ?> sr-showcase-theme--<?php echo esc_attr($a['theme']); ?> sr-showcase-position--<?php echo esc_attr($a['position']); ?>" style="--sr-showcase-columns:<?php echo (int)$a['columns']; ?>" data-font="<?php echo esc_attr($a['font']); ?>" data-sr-showcase <?php if($slider) echo 'aria-roledescription="carousel"'; ?> data-columns="<?php echo (int)$a['columns']; ?>" data-layout="<?php echo esc_attr($layout); ?>" data-autoplay="<?php echo $a['autoplay']?'true':'false'; ?>" data-interval="<?php echo (int)$a['interval']*1000; ?>" aria-label="<?php echo esc_attr($a['title']?:'Customer reviews'); ?>">
            <?php if($compact): ?>
                <?php if($a['link'] && in_array($layout,['button','badge'],true)): ?><a class="sr-showcase-trigger" href="<?php echo esc_url($a['link']); ?>"><?php else: ?><button type="button" class="sr-showcase-trigger" data-showcase-open aria-haspopup="dialog" aria-controls="<?php echo esc_attr($uid); ?>-dialog"><?php endif; ?>
                    <span class="sr-showcase-trigger-score"><?php echo esc_html($summary['avg']); ?><small> / 5</small></span><?php echo self::stars($summary['avg']); ?><span class="sr-showcase-trigger-label"><?php echo (int)$summary['count']; ?> customer reviews</span><span class="sr-icon sr-icon-arrow-up-right" aria-hidden="true"></span>
                <?php if($a['link'] && in_array($layout,['button','badge'],true)): ?></a><?php else: ?></button><?php endif; ?>
            <?php endif; ?>
            <?php if($panel): ?><div class="sr-showcase-dialog" id="<?php echo esc_attr($uid); ?>-dialog" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr($uid); ?>-title" tabindex="-1"><div class="sr-showcase-dialog-box"><button type="button" class="sr-showcase-close" data-showcase-close aria-label="Close customer reviews"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button><?php endif; ?>
            <?php if(!$compact || $panel): ?>
                <?php if($a['title'] || $a['subtitle'] || $a['show_summary'] || $panel): ?><header class="sr-showcase-header"><div><?php if($a['title'] || $panel): ?><h2 id="<?php echo esc_attr($uid); ?>-title"><?php echo esc_html($a['title']?:'Customer reviews'); ?></h2><?php endif; ?><?php if($a['subtitle']): ?><p><?php echo esc_html($a['subtitle']); ?></p><?php endif; ?></div>
                    <?php if($a['show_summary']): ?><div class="sr-showcase-summary"><strong><?php echo esc_html($summary['avg']); ?><small> / 5</small></strong><?php echo self::stars($summary['avg']); ?><span>Overall · <?php echo (int)$summary['count']; ?> reviews</span></div><?php endif; ?>
                </header><?php endif; ?>
                <div class="sr-showcase-track" role="list" id="<?php echo esc_attr($uid); ?>-track" <?php if($slider): ?>tabindex="0" aria-label="Customer reviews; use the arrow keys to browse"<?php endif; ?>><?php foreach($reviews as $review) echo self::card($review,$a); ?><?php if(!$reviews): ?><p class="sr-showcase-empty">No reviews match this rating filter yet.</p><?php endif; ?></div>
                <?php if($slider && count($reviews)>1): ?><div class="sr-showcase-controls"><span data-showcase-status aria-live="polite"></span><div><?php if($a['autoplay']): ?><button type="button" data-showcase-pause aria-label="Pause review rotation"><span class="sr-icon sr-icon-pause" aria-hidden="true"></span></button><?php endif; ?><button type="button" data-showcase-prev aria-label="Previous reviews" aria-controls="<?php echo esc_attr($uid); ?>-track"><span class="sr-icon sr-icon-chevron-left" aria-hidden="true"></span></button><button type="button" data-showcase-next aria-label="Next reviews" aria-controls="<?php echo esc_attr($uid); ?>-track"><span class="sr-icon sr-icon-chevron-right" aria-hidden="true"></span></button></div></div><?php endif; ?>
            <?php endif; ?>
            <?php if($panel): ?></div></div><?php endif; ?>
        </section>
        <?php return ob_get_clean();
    }

    public function preview() {
        SR_Security::authorize('moderate_comments');
        $product=SR_Security::text('placement')==='product';
        $atts=[];
        foreach($product?SR_Widget::defaults():self::defaults() as $key=>$value) $atts[$key]=SR_Security::text($key) ?: $value;
        // An empty headline is a valid design choice; keep explicit empty values.
        foreach(['title','subtitle'] as $key) if(isset($_POST[$key]))$atts[$key]=SR_Security::text($key);
        $html=$product?(new SR_Widget())->render_shortcode($atts,true):$this->render($atts);
        wp_send_json_success(['html'=>$html?:'<div class="sr-showcase-empty">No published reviews match these filters. Try another product or a lower minimum rating.</div>']);
    }
}
