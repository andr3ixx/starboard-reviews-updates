<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Public release feed; WordPress retains responsibility for installing updates. */
class SR_Updater {
    const REPOSITORY = 'andr3ixx/starboard-reviews-updates';
    const FEED = 'https://raw.githubusercontent.com/andr3ixx/starboard-reviews-updates/main/update.json';
    const CACHE = 'sr_release_feed_v1';

    public function __construct() {
        add_filter( 'update_plugins_github.com', [ $this, 'offer' ], 10, 4 );
        add_filter( 'plugins_api', [ $this, 'details' ], 10, 3 );
        add_filter( 'upgrader_pre_download', [ $this, 'download' ], 10, 4 );
        add_filter( 'plugin_action_links_' . self::plugin(), [ $this, 'links' ] );
        add_filter( 'network_admin_plugin_action_links_' . self::plugin(), [ $this, 'links' ] );
        add_action( 'admin_post_sr_check_updates', [ $this, 'check' ] );
        add_action( 'admin_notices', [ $this, 'notice' ] );
        add_action( 'network_admin_notices', [ $this, 'notice' ] );
        add_action( 'upgrader_process_complete', [ $this, 'clear_after_upgrade' ], 10, 2 );
    }

    public static function plugin() {
        return plugin_basename( dirname( __DIR__ ) . '/starboard-reviews.php' );
    }

    public static function validate( $data ) {
        if ( ! is_array( $data ) ) return false;
        foreach ( [ 'version', 'requires', 'requires_php' ] as $key ) {
            if ( ! isset( $data[$key] ) || ! is_string( $data[$key] ) || ! preg_match( '/^\d+\.\d+(?:\.\d+)?$/D', $data[$key] ) ) return false;
        }
        $package = 'https://raw.githubusercontent.com/' . self::REPOSITORY . '/main/releases/' . $data['version'] . '/starboard-reviews-' . $data['version'] . '.zip';
        if ( ( $data['download_url'] ?? '' ) !== $package || ! is_string( $data['sha256'] ?? null ) || ! preg_match( '/^[a-f0-9]{64}$/D', $data['sha256'] ) ) return false;
        return [ 'version'=>$data['version'], 'requires'=>$data['requires'], 'requires_php'=>$data['requires_php'], 'download_url'=>$package, 'sha256'=>$data['sha256'] ];
    }

    public static function release() {
        $cached = get_site_transient( self::CACHE );
        if ( is_array( $cached ) && array_key_exists( 'release', $cached ) ) return $cached['release'] ? self::validate( $cached['release'] ) : false;
        $response = wp_safe_remote_get( self::FEED, [ 'timeout'=>8, 'redirection'=>2, 'limit_response_size'=>65536, 'headers'=>[ 'Accept'=>'application/json' ] ] );
        $release = false;
        if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) $release = self::validate( json_decode( wp_remote_retrieve_body( $response ), true ) );
        set_site_transient( self::CACHE, [ 'release'=>$release, 'checked'=>time() ], $release ? HOUR_IN_SECONDS : 10 * MINUTE_IN_SECONDS );
        return $release;
    }

    public function offer( $update, $plugin_data, $plugin_file, $locales ) {
        if ( $plugin_file !== self::plugin() ) return $update;
        $release = self::release();
        if ( ! $release ) return $update;
        return [ 'id'=>'https://github.com/' . self::REPOSITORY, 'slug'=>'starboard-reviews', 'version'=>$release['version'], 'url'=>'https://github.com/' . self::REPOSITORY . '/tree/main/releases/' . $release['version'], 'package'=>$release['download_url'], 'requires'=>$release['requires'], 'requires_php'=>$release['requires_php'] ];
    }

    public function details( $result, $action, $args ) {
        if ( $action !== 'plugin_information' || ! is_object( $args ) || ( $args->slug ?? '' ) !== 'starboard-reviews' ) return $result;
        $release = self::release();
        if ( ! $release ) return $result;
        return (object) [ 'name'=>'Starboard Reviews', 'slug'=>'starboard-reviews', 'version'=>$release['version'], 'author'=>'DigitalDeckhand', 'homepage'=>'https://digitaldeckhand.com/', 'requires'=>$release['requires'], 'requires_php'=>$release['requires_php'], 'download_link'=>$release['download_url'], 'sections'=>[ 'description'=>'Product reviews, moderation and review-request emails for WooCommerce.', 'changelog'=>'<p><a href="' . esc_url( 'https://github.com/' . self::REPOSITORY . '/tree/main/releases/' . $release['version'] ) . '" target="_blank" rel="noopener noreferrer">Read the release notes</a></p>' ] ];
    }

    /** Verify only our release package, leaving every other upgrader untouched. */
    public function download( $reply, $package, $upgrader, $hook_extra ) {
        if ( $reply !== false || ! is_string( $package ) || strpos( $package, 'https://raw.githubusercontent.com/' . self::REPOSITORY . '/main/releases/' ) !== 0 ) return $reply;
        if ( ! empty( $hook_extra['plugin'] ) && $hook_extra['plugin'] !== self::plugin() ) return $reply;
        $release = self::release();
        if ( ! $release || $package !== $release['download_url'] ) return new WP_Error( 'sr_update_manifest', 'The Starboard update could not be verified. Check for updates and try again.' );
        if ( ! function_exists( 'download_url' ) ) require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = download_url( $package );
        if ( is_wp_error( $file ) ) return $file;
        if ( ! hash_equals( $release['sha256'], hash_file( 'sha256', $file ) ?: '' ) ) {
            wp_delete_file( $file );
            return new WP_Error( 'sr_update_checksum', 'The Starboard update download failed its integrity check. No update was installed.' );
        }
        return $file;
    }

    public static function check_url() {
        return wp_nonce_url( admin_url( 'admin-post.php?action=sr_check_updates' ), 'sr_check_updates' );
    }

    public function links( $links ) {
        if ( current_user_can( 'update_plugins' ) ) $links[] = '<a href="' . esc_url( self::check_url() ) . '">Check for updates</a>';
        return $links;
    }

    public function check() {
        if ( ! current_user_can( 'update_plugins' ) ) wp_die( 'Permission denied.', '', [ 'response'=>403 ] );
        check_admin_referer( 'sr_check_updates' );
        // Shared across a multisite network; repeated clicks do not hammer the feed.
        if ( ! get_site_transient( 'sr_update_check_cooldown' ) ) {
            set_site_transient( 'sr_update_check_cooldown', true, MINUTE_IN_SECONDS );
            delete_site_transient( self::CACHE );
            self::release();
            wp_clean_plugins_cache( false );
            delete_site_transient( 'update_plugins' );
            wp_update_plugins();
        }
        wp_safe_redirect( self_admin_url( 'plugins.php?sr_update_checked=1' ) );
        exit;
    }

    public function notice() {
        if ( ! current_user_can( 'update_plugins' ) || empty( $_GET['sr_update_checked'] ) ) return;
        $screen = get_current_screen();
        if ( ! $screen || ! in_array( $screen->id, [ 'plugins', 'plugins-network' ], true ) ) return;
        $cached = get_site_transient( self::CACHE );
        $release = is_array( $cached ) && ! empty( $cached['release'] ) ? self::validate( $cached['release'] ) : false;
        $message = ! $release ? 'Could not check Starboard updates. Please try again later. Your installed plugin is unchanged.' : ( version_compare( $release['version'], SR_VERSION, '>' ) ? 'A Starboard Reviews update is available. Use Update now below to install it.' : 'Starboard Reviews is up to date.' );
        echo '<div class="notice ' . ( $release ? 'notice-success' : 'notice-warning' ) . ' is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
    }

    public static function panel() {
        if ( ! current_user_can( 'update_plugins' ) ) return;
        $updates = get_site_transient( 'update_plugins' );
        $update = is_object( $updates ) ? ( $updates->response[self::plugin()] ?? null ) : null;
        echo '<div class="sr-card sr-updates-card"><h3>Plugin updates</h3><p class="sr-field-help">Installed version: ' . esc_html( SR_VERSION ) . '. WordPress checks for releases periodically. You can also check now.</p>';
        if ( $update && version_compare( $update->new_version, SR_VERSION, '>' ) ) {
            $url = wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . rawurlencode( self::plugin() ) ), 'upgrade-plugin_' . self::plugin() );
            echo '<p>Version ' . esc_html( $update->new_version ) . ' is available.</p><a class="sr-btn blue" href="' . esc_url( $url ) . '">Update now</a> ';
        }
        echo '<a class="sr-btn outline" href="' . esc_url( self::check_url() ) . '">Check for updates</a><p class="sr-field-help">Downloads are served from the public Starboard release repository. Your site does not need a GitHub account or token.</p></div>';
    }

    public function clear_after_upgrade( $upgrader, $options ) {
        if ( ( $options['type'] ?? '' ) === 'plugin' && in_array( self::plugin(), $options['plugins'] ?? [], true ) ) delete_site_transient( self::CACHE );
    }
}
