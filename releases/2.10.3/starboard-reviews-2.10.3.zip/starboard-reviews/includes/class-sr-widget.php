<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SR_Widget {

    public function __construct() {
        add_shortcode( 'starboard_reviews', [ $this, 'render_shortcode' ] );
        add_shortcode( 'starboard_rating', [ $this, 'render_rating_shortcode' ] );
    }

    public function render_rating_shortcode( $atts ) {
        $atts = shortcode_atts( [
            'id'         => '',
            'rating'     => '',
            'count'      => '',
            'show_score' => 'true',
            'show_count' => 'true'
        ], $atts, 'starboard_rating' );

        $pid = absint( $atts['id'] );

        if ( empty( $pid ) && empty( $atts['rating'] ) && is_singular( 'product' ) ) {
            $pid = get_the_ID();
        }

        if ( $atts['rating'] !== '' && $atts['count'] !== '' ) {
            $avg = max( 0, min( 5, floatval( $atts['rating'] ) ) );
            $total = max( 0, intval( $atts['count'] ) );
        } elseif ( $pid ) {
            if ( $pid && ( get_post_type( $pid ) !== 'product' || get_post_status( $pid ) !== 'publish' || post_password_required( $pid ) ) ) return '';
        $args = [ 'post_id' => $pid, 'post_type' => 'product', 'post_status' => 'publish', 'status' => 'approve', 'type' => 'review', 'parent' => 0 ];
            $comments = get_comments( $args );
            $total = count( $comments );
            $sum = 0; $rated_count = 0;
            foreach ( $comments as $c ) {
                $r = (int) get_comment_meta( $c->comment_ID, 'rating', true );
                if ( $r >= 1 && $r <= 5 ) { $sum += $r; $rated_count++; }
            }
            $avg = $rated_count > 0 ? round( $sum / $rated_count, 1 ) : 0;
        } else {
            return '';
        }

        if ( $total === 0 && empty( $atts['rating'] ) ) return '';

        ob_start();
        ?>
        <div class="sr-inline-rating">
            <div class="sr-stars-static sr-small" style="--v:<?php echo $avg; ?>;"></div>
            <?php if ( $atts['show_score'] === 'true' ) : ?>
                <span class="sr-inline-score"><?php echo $avg; ?></span>
            <?php endif; ?>
            <?php if ( $atts['show_count'] === 'true' ) : ?>
                <span class="sr-inline-count">(<?php echo $total; ?> reviews)</span>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    public static function summary( $pid ) {
        $args = [ 'post_id' => $pid, 'post_type' => 'product', 'post_status' => 'publish', 'status' => 'approve', 'type' => 'review', 'parent' => 0 ];
        if ( ! $pid ) $args['post__not_in'] = get_posts( [ 'post_type' => 'product', 'post_status' => 'publish', 'has_password' => true, 'numberposts' => -1, 'fields' => 'ids' ] );
        $comments = get_comments( $args );
        $sum = 0; $rated = 0; $cs_sum = 0; $cs_count = 0;
        $dist = [ 5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0 ];
        foreach ( $comments as $comment ) {
            $rating = (int) get_comment_meta( $comment->comment_ID, 'rating', true );
            if ( $rating >= 1 && $rating <= 5 ) { $sum += $rating; $rated++; $dist[$rating]++; }
            $cs = (int) get_comment_meta( $comment->comment_ID, 'cs_rating', true );
            if ( $cs >= 1 && $cs <= 5 ) { $cs_sum += $cs; $cs_count++; }
        }
        return [ 'count' => count( $comments ), 'avg' => $rated ? round( $sum / $rated, 1 ) : 0, 'dist' => $dist, 'cs_count' => $cs_count, 'cs_avg' => $cs_count ? round( $cs_sum / $cs_count, 1 ) : 0 ];
    }

    public static function defaults() {
        return ['product_id'=>'0','columns'=>'3','count'=>'6','min_rating'=>'1','order'=>'newest','title'=>'Customer reviews','subtitle'=>'Real experiences. Helpful details.','excerpt'=>'20','show_summary'=>'true','show_form'=>'true','show_sort'=>'true','show_title'=>'true','show_content'=>'true','show_date'=>'true','show_photos'=>'true','font'=>'default'];
    }

    public static function normalize($atts) {
        $atts=is_array($atts)?$atts:[];
        foreach($atts as $key=>$value) if(!is_scalar($value))unset($atts[$key]);
        $a=shortcode_atts(self::defaults(),$atts,'starboard_reviews');
        foreach(['columns'=>[1,4],'count'=>[1,24],'min_rating'=>[1,5],'excerpt'=>[10,200]] as $key=>$bounds)$a[$key]=max($bounds[0],min($bounds[1],(int)$a[$key]));
        foreach(['show_summary','show_form','show_sort','show_title','show_content','show_date','show_photos'] as $key)$a[$key]=in_array(strtolower((string)$a[$key]),['true','1','yes','on'],true);
        $a['product_id']=absint($a['product_id']);
        $a['title']=sanitize_text_field($a['title']);$a['subtitle']=sanitize_text_field($a['subtitle']);
        if(!in_array($a['order'],['newest','oldest','highest','lowest'],true))$a['order']='newest';
        if(!in_array($a['font'],['default','site','starboard'],true))$a['font']='default';
        return $a;
    }

    public function render_shortcode( $atts, $preview = false, $initial = false ) {
        $atts = self::normalize($atts);
        $pid = absint( $atts['product_id'] );

        if ( empty( $pid ) && is_singular( 'product' ) ) {
            $pid = get_the_ID();
        }

        if ( $pid && ( get_post_type( $pid ) !== 'product' || get_post_status( $pid ) !== 'publish' || post_password_required( $pid ) ) ) return '';
        $summary = self::summary( $pid );
        $count = $summary['count']; $avg = $summary['avg']; $dist = $summary['dist'];
        $cs_count = $summary['cs_count']; $cs_avg = $summary['cs_avg'];

        $initial_reviews=[];$has_more=false;
        if($initial){
            $selection=SR_Showcase::normalize(['product_id'=>$pid,'count'=>$atts['count'],'min_rating'=>$atts['min_rating'],'order'=>$atts['order']]);
            $selection['count']=$atts['count']+1;
            $initial_reviews=SR_Showcase::reviews($selection);$has_more=count($initial_reviews)>$atts['count'];
            $initial_reviews=array_slice($initial_reviews,0,$atts['count']);
        }
        $badge_text = '';
        if ( $avg >= 4.5 ) { $badge_text = 'Excellent'; }
        elseif ( $avg >= 4.0 ) { $badge_text = 'Very Good'; }

        static $widget_number = 0;
        $uid = 'sr-' . ++$widget_number;
        ob_start();
        ?>
        <div class="sr-widget-container <?php if(!$atts['show_summary'])echo 'sr-no-summary'; ?>" style="--sr-product-columns:<?php echo (int)$atts['columns']; ?>" data-initial="<?php echo $initial?'true':'false'; ?>" data-initial-has-more="<?php echo $has_more?'true':'false'; ?>" data-preview="<?php echo $preview?'true':'false'; ?>" data-font="<?php echo esc_attr($atts['font']); ?>" data-columns="<?php echo (int)$atts['columns']; ?>" <?php foreach(['count','min_rating','order','excerpt','show_title','show_content','show_date','show_photos'] as $key)echo 'data-'.esc_attr(str_replace('_','-',$key)).'="'.esc_attr(is_bool($atts[$key])?($atts[$key]?'true':'false'):$atts[$key]).'" '; ?> id="<?php echo $uid === 'sr-1' ? 'sr-widget' : esc_attr( $uid ); ?>" data-pid="<?php echo esc_attr( $pid ); ?>">

            <div class="sr-widget-intro"><div><?php if($atts['subtitle']): ?><span class="sr-widget-kicker"><?php echo esc_html($atts['subtitle']); ?></span><?php endif; ?><?php if($atts['title']): ?><h2><?php echo esc_html($atts['title']); ?></h2><?php endif; ?></div><span class="sr-review-total"><span data-sr="review-count"><?php echo (int) $count; ?></span> reviews</span></div>
            <div data-sr="notice" class="sr-widget-notice" role="status" hidden></div>
            <div class="sr-header-section" <?php if(!$atts['show_summary']&&!$atts['show_form'])echo 'hidden'; ?>>
                <div class="sr-stats-card">
                    <div class="sr-score-col">
                        <span class="sr-score-label">Overall rating</span><span class="sr-big-score" data-sr="avg"><?php echo $avg; ?></span>
                        <div class="sr-badge" data-sr="rating-badge" <?php if ( ! $badge_text ) echo 'hidden'; ?>><?php echo esc_html( $badge_text ); ?></div>
                        <div class="sr-stars-static" data-sr="overall-stars" role="img" aria-label="<?php echo esc_attr( $avg . ' out of 5 stars' ); ?>" style="--v:<?php echo $avg; ?>;"></div>
                        <span class="sr-sub-text">Based on <span data-sr="review-count"><?php echo (int) $count; ?></span> reviews</span>
                        <div class="sr-cs-score" data-sr="cs-score" <?php if ( ! $cs_count ) echo 'hidden'; ?>>Service <strong data-sr="cs-avg"><?php echo $cs_avg; ?></strong><span aria-hidden="true"> / 5</span></div>
                    </div>

                    <div class="sr-bars-col">
                        <?php foreach ( [ 5, 4, 3, 2, 1 ] as $s ) :
                            $pct = $count > 0 ? ( $dist[$s] / $count ) * 100 : 0;
                        ?>
                            <div class="sr-bar-row">
                                <span class="sr-star-lbl"><?php echo $s; ?> <span class="sr-icon sr-icon-star" aria-hidden="true"></span></span>
                                <div class="sr-track">
                                    <div class="sr-fill" data-star-bar="<?php echo $s; ?>" style="width:<?php echo $pct; ?>%"></div>
                                </div>
                                <span class="sr-count-lbl" data-star-count="<?php echo $s; ?>"><?php echo $dist[$s]; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="sr-btn-col" <?php if(!$atts['show_form'])echo 'hidden'; ?>>
                        <?php if ( $atts['show_form'] && $pid && comments_open( $pid ) ) : ?>
                        <button type="button" class="sr-btn-primary sr-btn-write">Write a review <span class="sr-icon sr-icon-arrow-up-right" aria-hidden="true"></span></button><p class="sr-write-hint">Your experience helps someone choose.</p>
                        <?php if ( ! is_user_logged_in() && ( get_option( 'sr_verified_only' ) || get_option( 'comment_registration' ) || get_option( 'woocommerce_review_rating_verification_required' ) === 'yes' ) ) : ?>
                            <p><a href="<?php echo esc_url( wp_login_url( get_permalink( $pid ) ) ); ?>">Sign in with your purchasing account to review.</a></p>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="sr-widget-toolbar" <?php if(!$atts['show_sort'])echo 'hidden'; ?>>
                <span class="sr-widget-list-label">From our customers</span><label class="sr-sort-label" for="<?php echo esc_attr( $uid ); ?>-sort">Sort by</label>
                <select id="<?php echo esc_attr( $uid ); ?>-sort" data-sr="front-sort">
                    <option value="newest" <?php selected($atts['order'],'newest'); ?>>Newest first</option>
                    <option value="oldest" <?php selected($atts['order'],'oldest'); ?>>Oldest first</option>
                    <option value="highest" <?php selected($atts['order'],'highest'); ?>>Highest rating</option>
                    <option value="lowest" <?php selected($atts['order'],'lowest'); ?>>Lowest rating</option>
                </select>
            </div>
            <div id="<?php echo esc_attr( $uid ); ?>-reviews-list" data-sr="reviews-list" class="sr-reviews-list"><?php if($preview){$selection=SR_Showcase::normalize(['product_id'=>$pid,'count'=>$atts['count'],'min_rating'=>$atts['min_rating'],'order'=>$atts['order']]);foreach(SR_Showcase::reviews($selection) as $review)echo self::render_single_review($review,$atts);}elseif($initial){foreach($initial_reviews as $review)echo self::render_single_review($review,$atts);if(!$initial_reviews)echo '<div class="sr-review-placeholder"><strong>No reviews yet.</strong></div>';} ?></div>

            <div class="sr-load-more-wrap" style="display:none;">
                <button type="button" class="sr-btn-secondary" id="<?php echo esc_attr( $uid ); ?>-load-more-btn" data-sr="load-more-btn">Load More</button>
            </div>

            <div id="<?php echo esc_attr( $uid ); ?>-write-modal" data-sr="write-modal" class="sr-modal-overlay" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr( $uid ); ?>-write-title" tabindex="-1">
                <div class="sr-modal-box">
                    <div class="sr-modal-header">
                        <h3 id="<?php echo esc_attr( $uid ); ?>-write-title">Share your experience</h3>
                        <button type="button" class="sr-close-btn" aria-label="Close review dialog"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button>
                    </div>
                    <div class="sr-modal-content">
                        <form id="<?php echo esc_attr( $uid ); ?>-review-form" data-sr="review-form" enctype="multipart/form-data">
                            <input type="hidden" name="pid" value="<?php echo esc_attr( $pid ); ?>">

                            <fieldset class="sr-field-group">
                                <legend>Your Rating</legend>
                                <div class="sr-write-stars">
                                    <div class="sr-star-input-group">
                                        <?php for ( $i = 5; $i >= 1; $i-- ) : ?>
                                            <input type="radio" name="rating" required aria-label="<?php echo (int) $i; ?> stars" id="<?php echo esc_attr( $uid ); ?>-star-<?php echo $i; ?>" value="<?php echo $i; ?>">
                                            <label for="<?php echo esc_attr( $uid ); ?>-star-<?php echo $i; ?>"></label>
                                        <?php endfor; ?>
                                    </div>
                                    <div class="sr-rating-label">Select</div>
                                </div>
                            </fieldset>

                            <fieldset class="sr-field-group">
                                <legend>Customer Service <span class="sr-optional-tag">(optional)</span></legend>
                                <div class="sr-write-stars">
                                    <div class="sr-star-input-group">
                                        <?php for ( $i = 5; $i >= 1; $i-- ) : ?>
                                            <input type="radio" name="cs_rating" aria-label="<?php echo (int) $i; ?> service stars" id="<?php echo esc_attr( $uid ); ?>-cs-star-<?php echo $i; ?>" value="<?php echo $i; ?>">
                                            <label for="<?php echo esc_attr( $uid ); ?>-cs-star-<?php echo $i; ?>"></label>
                                        <?php endfor; ?>
                                    </div>
                                    <div class="sr-rating-label">Select</div><button type="button" class="sr-clear-service" data-sr="clear-service" hidden>Clear</button>
                                </div>
                            </fieldset>

                            <div class="sr-field-group">
                                <label for="<?php echo esc_attr( $uid ); ?>-title">Short review title</label>
                                <input type="text" id="<?php echo esc_attr( $uid ); ?>-title" name="title" maxlength="200" required placeholder="Give your review a short headline">
                            </div>

                            <div class="sr-field-group">
                                <label for="<?php echo esc_attr( $uid ); ?>-content">Your Review</label>
                                <textarea id="<?php echo esc_attr( $uid ); ?>-content" name="content" rows="4" maxlength="10000" required placeholder="What did you like or dislike?"></textarea>
                            </div>

                            <div class="sr-form-columns">
                                <div class="sr-field-group">
                                    <label for="<?php echo esc_attr( $uid ); ?>-author">Name</label><input type="text" id="<?php echo esc_attr( $uid ); ?>-author" name="author" autocomplete="name" maxlength="100" required>
                                </div>
                                <div class="sr-field-group">
                                    <label for="<?php echo esc_attr( $uid ); ?>-email">Email</label><input type="email" id="<?php echo esc_attr( $uid ); ?>-email" name="email" autocomplete="email" maxlength="254" required>
                                </div>
                            </div>

                            <div class="sr-field-group">
                                <label for="<?php echo esc_attr( $uid ); ?>-photo-input">Photos <span class="sr-optional-tag">optional</span></label>
                                <div class="sr-dropzone">
                                    <input type="file" name="photos[]" id="<?php echo esc_attr( $uid ); ?>-photo-input" data-sr="photo-input" multiple accept="image/jpeg,image/png,image/webp">
                                    <span class="sr-upload-icon" aria-hidden="true"><span class="sr-icon sr-icon-upload"></span></span>
                                    <strong>Choose photos or drop them here</strong><span>JPEG, PNG or WebP · up to 5 files · 5 MB / 20 MP each</span>
                                </div>
                                <div id="<?php echo esc_attr( $uid ); ?>-photo-previews" data-sr="photo-previews"></div>
                            </div>

                            <?php SR_Antispam::field($preview); ?>
                            <p class="sr-privacy-note">Your email is kept private. Only your name and review are shared.</p><div id="<?php echo esc_attr( $uid ); ?>-form-message" data-sr="form-message" role="status"></div>
                            <button type="submit" class="sr-btn-primary sr-full-width">Submit review</button>
                        </form>
                    </div>
                </div>
            </div>

            <div id="<?php echo esc_attr( $uid ); ?>-read-modal" data-sr="read-modal" class="sr-modal-overlay" role="dialog" aria-modal="true" aria-label="Customer review" tabindex="-1">
                <div class="sr-modal-box">
                    <div class="sr-modal-header sr-modal-read-header">
                        <button type="button" class="sr-close-btn" aria-label="Close review dialog"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button>
                    </div>
                    <div class="sr-modal-content" id="<?php echo esc_attr( $uid ); ?>-read-content" data-sr="read-content"></div>
                </div>
            </div>

            <div id="<?php echo esc_attr( $uid ); ?>-lightbox" data-sr="lightbox" class="sr-lightbox-overlay" aria-label="Review photo">
                <button type="button" class="sr-lightbox-close" aria-label="Close photo"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button>
                <img id="<?php echo esc_attr( $uid ); ?>-lightbox-image" data-sr="lightbox-image" alt="Customer review photo">
            </div>

        </div>

        <?php
        return ob_get_clean();
    }

    public static function render_single_review( $c, $options = [] ) {
        $options=self::normalize($options);
        $rating = (int) get_comment_meta( $c->comment_ID, 'rating', true );
        $title  = get_comment_meta( $c->comment_ID, 'review_title', true );
        $date   = get_comment_date( 'M j, Y', $c->comment_ID );

        $photos = get_comment_meta( $c->comment_ID, 'review_photos', true );
        if ( empty( $photos ) ) {
            $single = get_comment_meta( $c->comment_ID, 'review_photo_id', true );
            if ( $single ) $photos = [ $single ];
        }

        $photo_data = [];
        $photo_html = '';
        if ( ! empty( $photos ) && is_array( $photos ) ) {
            $photo_html = '<div class="sr-mini-gallery">';
            foreach ( $photos as $pid ) {
                $src_thumb = wp_get_attachment_image_url( $pid, 'thumbnail' );
                $src_full  = wp_get_attachment_image_url( $pid, 'large' );
                if ( $src_thumb ) {
                    $photo_data[] = $src_full;
                    if ( count($photo_data) <= 3 ) {
                        $photo_html .= '<img src="' . esc_url( $src_thumb ) . '" alt="Customer review photo" loading="lazy">';
                    }
                }
            }
            $photo_html .= '</div>';
        }

        $replies = get_comments( [ 'parent' => $c->comment_ID, 'status' => 'approve', 'number' => 1 ] );
        $reply_content = $replies ? wp_strip_all_tags( $replies[0]->comment_content ) : '';

        $json_photos = esc_attr( json_encode( $photo_data ) );
        $safe_title  = esc_attr( $title );
        $safe_author = esc_attr( $c->comment_author );
        $safe_reply  = esc_attr( $reply_content );
        $full_content= esc_attr( wp_strip_all_tags( $c->comment_content ) );

        return '
        <article class="sr-card">
            <div class="sr-card-top">
                <div class="sr-avatar">' . esc_html( strtoupper( substr( $c->comment_author, 0, 1 ) ) ) . '</div>
                <div class="sr-user-info">
                    <div class="sr-author-name">' . esc_html( $c->comment_author ) . '</div>
                    <div class="sr-stars-static sr-small" role="img" aria-label="' . $rating . ' out of 5 stars" style="--v:' . $rating . '"></div>
                </div>
            </div>
            <div class="sr-card-body">
                ' . ( $title ? '<h4 class="sr-card-title">' . esc_html( $title ) . '</h4>' : '' ) . '
                <div class="sr-card-text">' . esc_html( wp_trim_words( wp_strip_all_tags($c->comment_content), $options['excerpt'], '…' ) ) . '</div>
                ' . $photo_html . '
            </div>
            <div class="sr-card-foot">
                <button type="button" class="sr-link-btn sr-trigger-modal"
                    data-content="' . $full_content . '"
                    data-title="' . $safe_title . '"
                    data-author="' . $safe_author . '"
                    data-date="' . $date . '"
                    data-rating="' . $rating . '"
                    data-reply="' . $safe_reply . '"
                    data-photos="' . $json_photos . '">
                    Read full review <span class="sr-icon sr-icon-arrow-up-right" aria-hidden="true"></span>
                </button>
                <span class="sr-date-lbl">' . $date . '</span>
            </div>
        </article>';
    }
}
