<?php
if ( ! defined('ABSPATH') ) exit;
get_header();
?>
<main id="content" class="sr-reviews-page-template">
<?php while(have_posts()):the_post();echo SR_Reviews_Page_Template::render(get_post_meta(get_the_ID(),SR_Reviews_Page_Template::META,true));endwhile; ?>
</main>
<?php get_footer(); ?>
