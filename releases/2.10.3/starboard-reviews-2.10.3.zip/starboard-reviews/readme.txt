=== Starboard Reviews ===
Contributors: digitaldeckhand
Tags: reviews, woocommerce, ratings, email automation, marine
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Requires Plugins: woocommerce
Stable tag: 2.10.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The complete, ajax-powered review system designed for marine-based companies, with automated and manual review-request emails.

== Description ==

Starboard Reviews adds a product review widget, an admin moderation queue, and an automated review-request email sequence to a WooCommerce store.

**Automated requests** are triggered when a WooCommerce order is marked Completed. The plugin schedules a first request (and an optional follow-up) after a configurable delay, then emails the customer a link back to the product to leave a review.

**Manual requests** cover orders that never get marked Completed in WooCommerce (e.g. stores that fulfil manually and don't keep order status up to date). From Starboard Reviews > Emails > Manual Send, an admin can select any open order and send the review request immediately, without changing the order's status. A manually sent request is tracked the same way as an automatic one, so if the order is later marked Completed the normal way, it will not receive a duplicate email.

**Customer Service score** lets reviewers optionally rate their customer service experience (separate from the product star rating) when they submit a review. The average is shown as its own stat, alongside the overall rating, in both the storefront widget and the admin Reviews dashboard.

**Customer Service request email** is a third, manual-only email tier. From Emails > Manual Send > "Ready for Customer Service Ask", an admin can bulk-send a dedicated "how was our service?" email to customers who already received the review request (and its follow-up, if enabled) but haven't been asked about service specifically. Its subject/body are customized under Emails > Templates & Settings.

**Pagination**: the Logs and Manual Send tables (and the existing Reviews table) page through results 20 at a time instead of showing one long, capped list.

= Requirements =
* WooCommerce must be installed and active. The plugin deactivates itself with an admin notice if WooCommerce is missing.

== Installation ==

1. Upload the plugin zip via Plugins > Add New > Upload Plugin, or extract it into `wp-content/plugins/`.
2. Activate **Starboard Reviews** through the 'Plugins' menu in WordPress.
3. Make sure WooCommerce is installed and active.
4. Configure delays, subject lines, and email templates under Starboard Reviews > Emails > Templates & Settings.

== Operational Notes ==

Verified Buyers Only requires the reviewer to sign in with their purchasing account. Public review submissions also respect WooCommerce review settings and WordPress moderation, duplicate and spam checks.

Photos are limited to five JPEG, PNG or WebP images per submission, each no larger than 5 MB and 20 megapixels. Public submissions are limited to ten per IP address per rolling day, at least one minute apart.

Process Queue Now processes only due requests. Use Resend on a specific log entry to send that request immediately. Concurrent scheduling and sending require MySQL/MariaDB advisory locks. Interrupted deliveries are flagged for manual inspection rather than retried automatically.

Every review-request email includes a confirmation-based unsubscribe link. Opted-out addresses are excluded from automatic, follow-up, manual and resend requests. Existing email-log records receive a token when next sent.

CSV imports accept current Starboard exports, legacy Starboard exports (where product names resolve uniquely), and Judge.me-style columns. The maximum CSV size is 5 MB and 1,000 rows per import; use smaller batches when importing remote photos. Product IDs in an export refer to the originating store. Existing review images are retained when a moderator selects a replacement gallery; no unrelated media is deleted.

== Product Review Customization ==

Open Starboard Reviews > Widgets and choose Product page. Copy the generated starboard_reviews shortcode into the product template's Shortcode block. Product ID 0 detects the current product. This builder configures the copied shortcode; it does not automatically modify templates or existing shortcode blocks.

[starboard_reviews columns="3" count="6" show_form="true"]

Options: product_id, columns (1-4, default 3), count (1-24 per page), min_rating (1-5, default 1), order (newest/oldest/highest/lowest), title, subtitle, excerpt (10-200 words), show_summary, show_form, show_sort, show_title, show_content, show_date, show_photos and font (default/site/starboard). Boolean options accept true/false. The overall score includes all published reviews regardless of the card filter. Submission and moderation rules are unchanged by display choices.

Front-end typography inherits the site font by default. Change the plugin-wide preference in Settings > Colors & Branding or override it in the Widgets builder. Starboard prefers locally installed Avenir and bundles Manrope as a fallback; no third-party font service is used. Admin honors the WordPress body font variable (or --sr-admin-font) and falls back to the Starboard font stack.

== Showcase Widgets ==

Use Starboard Reviews > Widgets to choose a layout, adjust filters, preview the result and copy a shortcode into a page's Shortcode block. These displays show existing reviews and do not include a submission form.

[starboard_showcase layout="carousel" count="6" min_rating="4" columns="3"]
[starboard_showcase layout="featured" product_id="123"]
[starboard_showcase layout="badge"]

Layouts: grid, carousel (or slider), featured, list, wall, compact, button, badge, floating, popup and sidebar. Sidebar is a narrow single-card slider that can be inserted in a sidebar Shortcode block. Floating and popup open on click.

Controls: count (1-24), min_rating (1-5), columns (1-4), product_id (0 for all products), review_ids (comma-separated comment IDs), order (newest, oldest, highest, lowest, manual), theme (light, soft, dark), title, subtitle, show_summary, show_product, show_date, show_photos, autoplay, interval (3-30 seconds), excerpt (10-200 words), link (button/badge destination) position (left/right for floating) and font (default/site/starboard). Boolean values accept true/false. Manual order follows review_ids. Featured always shows one review.

Only approved top-level reviews on published, publicly accessible products are shown. The overall rating includes the full published review population; selecting 4+ reviews never inflates that score. Empty standard displays are hidden. Rating badges and buttons still show the overall score when the selected review filter is empty. Autoplay is off by default and respects reduced motion, focus, hover and tab visibility.

== Changelog ==

= 2.10.3 =
* Fixed: phone review grids use one column and the reviews page introduction clears floating mobile headers.

= 2.10.3 =
* Fixed: hidden controls remain hidden when component display rules are isolated from theme styles.


= 2.10.1 =
* Added: custom review forms reuse existing Cloudflare Turnstile keys, with server-side token, hostname and action verification.
* Added: review honeypots, attempt throttling and verification replay checks; verification failures never create a review or upload a photo.
* Improved: lazy verification in review dialogs, retry states and fresh checks after submissions.
* Improved: scoped control resets protect widget buttons, fields and reviewer spacing from Elementor and theme globals.


= 2.10.0 =
* Added: an optional responsive PHP reviews page template with editable page copy, product scope and hero image, keeping the site header and footer.
* Improved: landing-page reviews render in the initial HTML, with working sorting, pagination and review dialogs.
* Changed: new installations default to auto-publish eligible reviews rated 4 stars and above. Existing moderation settings and WordPress spam checks are preserved.


= 2.9.0 =
* Added: WordPress-native update notifications and installation from a public download-only repository.
* Added: Check for updates links on Plugins and Settings, with permission, nonce and cooldown checks.
* Added: SHA-256 package verification and bounded, cached release metadata requests.
* Added: a main-branch publishing workflow that distributes only packaged plugin files, release notes and update metadata.


= 2.8.1 =
* Added: one Widgets builder with placement choices for product, home, landing, sidebar and other pages.
* Added: product review controls for columns, page size, minimum rating, headings, excerpts, fonts and element visibility.
* Changed: front-end widgets inherit the site font by default, with an optional Starboard font. Admin uses the WordPress body font when configured, with a local Starboard fallback.
* Improved: larger type, compact reviewer details, zero author-name bottom margin and three default product review columns.
* Simplified: review dialogs show the actual review without the generic heading.


= 2.8.0 =
* Added: separate marketing showcase shortcode with 11 layouts, rating filters, curated reviews, themes and display controls.
* Added: Widgets admin builder with live preview, mobile preview and copyable shortcodes.
* Added: accessible slider controls, optional rotation and focus-managed review pop-ups.


= 2.7.1 =
* Revised: a distinct faceted compass identity with an east-facing point and diamond cutout.
* Improved: use bundled Lucide SVG icons for interface actions, uploads, closing controls, navigation, empty states and ratings. Icon license notices are included.


= 2.7.0 =
* Added: Starboard family icon and outlined logotype, inspired by the DigitalDeckhand wave, with local brand assets.
* Redesigned: shared admin navigation, buttons, form fields, status labels, review cards, summary panels, dialogs and responsive layouts.
* Added: select across review pages and bulk-edit status, product rating or service rating, with per-review permission checks and a 50-review limit.
* Added: downloadable sample import CSV with safe placeholder product IDs and inline import guidance.
* Added: quick navigation with Cmd/Ctrl+K and review search with the / shortcut.
* Improved: short-lived review-view caching, obsolete-request cancellation and summary-free paging between recent admin views.
* Improved: keyboard-accessible rating controls, optional-rating clearing, removable photo previews, focus-managed dialogs and reduced-motion support.
* Improved: published reviews refresh the widget and summary without a full page reload.
* Maintenance: bundle interface icons locally instead of loading a third-party icon font stylesheet.


= 2.6.0 =
* Security: enforce administrator/moderator capabilities and record access on all administrative AJAX actions; separate administrative and storefront nonces.
* Security: render review details as text, validate product visibility and ratings, enforce verified purchasers, and constrain public photo uploads.
* Security: preserve WordPress spam, duplicate and moderation decisions and limit repeat public submissions.
* Fixed: save only settings belonging to the submitted form, validate values by type, and allow disabling the email logo.
* Fixed: process only due mail, atomically claim queue rows, serialize order/tier sends, suppress historical duplicates, target resends, and report failures accurately.
* Added: unsubscribe confirmation and suppression for all request types.
* Fixed: admin review pagination, multiple-photo uploads, moderator photo saving, product rating cache refreshes, and multiple storefront widgets.
* Fixed: compatible CSV import/export with moderation states, photo references, replies, safe spreadsheet cells, and correct text escaping.
* Maintenance: version static assets, clean up cron on deactivation, validate database upgrades, and remove the shutdown handler that automatically deactivated the plugin.


= 2.5.2 =
* Fixed: the default Customer Service Request email body had no {order_table} tag, so it had no button/product list — nothing for the customer to click. Default body now includes it, and the settings card shows the "Available Tags" hint (matching First Request/Follow-up) so it's easy to add or remove.

= 2.5.1 =
* Fixed: "Ready for Customer Service Ask" could show no results even with plenty of sent first requests. It was checking the *current* Follow-up setting instead of each order's own history, so a follow-up still queued (or a setting toggled after the fact) wrongly excluded everything. Eligibility is now per-order: level 1 sent, and no level 2 currently pending.
* Added: "Has Reviewed" column on Manual Send (both modes) showing the customer's existing star rating and review count, if any.
* Added: "Hide already reviewed" checkbox on Manual Send, to skip customers who've already left a review.

= 2.5 =
* Added: "Customer Service Request" email tier (level 3) — manual-only, with its own subject/body under Templates & Settings.
* Added: "Ready for Customer Service Ask" mode on the Manual Send tab, listing customers who already received the review request (and follow-up, if enabled) so a dedicated service-feedback email can be sent without duplicating the original ask.
* Added: pagination (20 per page) on the Logs and Manual Send tables.
* Changed: search on Logs and Manual Send now uses the URL query string (GET) instead of a POST-only form, so search and pagination compose in the same link.

= 2.4 =
* Added: optional "Customer Service" star rating on the review submission form, separate from the product rating.
* Added: Customer Service average shown as its own stat in the storefront widget and the admin Reviews dashboard (once at least one rating has been collected).
* Added: Customer Service rating support in the admin Add/Edit Review modal, and in CSV import/export.

= 2.3.1 =
* Added: "Customer Type" column (Retail / Wholesale) on the Manual Send tab, detected from the customer's WooCommerce Wholesale Pro role.

= 2.3 =
* Added: "Manual Send" tab under Emails, to bulk-send review requests for orders that were never marked Completed in WooCommerce, without changing the order's status.
* Added: manually sent requests are tagged and shown with a "Manual" label in the Emails log.
* Added: manual sends are deduplicated against the automatic order-status trigger, so an order can't receive the request twice.
* Added: `Requires at least` / `Requires PHP` headers so incompatible sites get a graceful admin notice instead of a fatal error on activation.

= 2.2 =
* Fixed: star alignment in the sr-user-info block.

== Upgrade Notice ==

= 2.9.0 =
Install this version manually once to enable future WordPress update notices. Subsequent releases can be installed through Plugins or Starboard Settings. Automatic installation is controlled by WordPress, not forced by this plugin.

= 2.8.1 =
Adds unified product/showcase customization and larger typography. Front-end widgets now inherit the site font by default; select Starboard typography in Settings to retain the branded font stack.

= 2.8.0 =
Adds the Widgets builder and starboard_showcase shortcode for home pages, landing pages and sidebars.

= 2.7.1 =
Updated Starboard identity and locally bundled Lucide icons throughout the admin and widget.


= 2.7.0 =
New Starboard branding and a redesigned admin/widget experience. Review bulk editing, a sample CSV and keyboard navigation are included. Existing security checks, settings and email-request history are retained.


= 2.6.0 =
Security and reliability update. Database schema updates automatically to 1.2 and preserves existing logs. Verified-only reviews now require a purchasing account login. Process Queue Now respects configured delivery dates. Review the operational notes and validate the update in staging before deployment.


= 2.5.2 =
Fixes the Customer Service Request email having no button. If you already saved Templates & Settings before this update, add {order_table} to that email's body yourself and save again — see note below.

= 2.5.1 =
Fixes "Ready for Customer Service Ask" showing empty when it shouldn't, and adds a "Has Reviewed" indicator + filter on Manual Send. No action required after updating.

= 2.5 =
Adds a manual "Customer Service Request" email tier and pagination on the Logs/Manual Send tables. No action required after updating.

= 2.4 =
Adds an optional Customer Service star rating to reviews, shown as its own score on the storefront and admin dashboard. No action required after updating; the score fills in as new reviews come in.

= 2.3.1 =
Adds a Customer Type (Retail/Wholesale) column to Manual Send. No action required after updating.

= 2.3 =
Adds manual review-request sending for orders stuck outside the Completed status. No action required after updating.
