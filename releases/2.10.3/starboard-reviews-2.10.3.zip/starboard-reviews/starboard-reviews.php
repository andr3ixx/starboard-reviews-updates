<?php
/**
 * Plugin Name: Starboard Reviews
 * Description: Product reviews, thoughtful moderation, and review-request emails for WooCommerce.
 * Version: 2.10.3
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: DigitalDeckhand
 * Author URI: https://digitaldeckhand.com/
 * Update URI: https://github.com/andr3ixx/starboard-reviews-updates
 * Text Domain: starboard-reviews
 * Requires Plugins: woocommerce
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// Define Constants
define( 'SR_PATH', plugin_dir_path( __FILE__ ) );
define( 'SR_URL', plugin_dir_url( __FILE__ ) );

define( 'SR_VERSION', '2.10.3' );

// Include Core Classes
require_once SR_PATH . 'includes/class-sr-security.php';
require_once SR_PATH . 'includes/class-sr-antispam.php';
require_once SR_PATH . 'includes/class-sr-updater.php';
require_once SR_PATH . 'includes/class-sr-db.php';
require_once SR_PATH . 'includes/class-sr-cron.php';
require_once SR_PATH . 'includes/class-sr-widget.php';
require_once SR_PATH . 'includes/class-sr-showcase.php';
require_once SR_PATH . 'includes/class-sr-reviews-page-template.php';
require_once SR_PATH . 'includes/class-sr-ajax.php';

// Include Admin Classes
require_once SR_PATH . 'includes/admin/class-sr-brand.php';
require_once SR_PATH . 'includes/admin/class-sr-widgets-page.php';
require_once SR_PATH . 'includes/admin/class-sr-admin-menu.php';
require_once SR_PATH . 'includes/admin/class-sr-reviews-page.php';
require_once SR_PATH . 'includes/admin/class-sr-emails-page.php';
require_once SR_PATH . 'includes/admin/class-sr-settings-page.php';

// Add Dashboard link to the plugin action links
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'sr_add_dashboard_link' );

function sr_add_dashboard_link( $links ) {
    $dashboard_url = admin_url( 'admin.php?page=starboard-reviews' );
    $dashboard_link = '<a href="' . esc_url( $dashboard_url ) . '">' . __( 'Dashboard', 'starboard-reviews' ) . '</a>';
    array_unshift( $links, $dashboard_link );
    return $links;
}

// Dependency Check: Deactivate if WooCommerce is missing
add_action( 'admin_init', 'sr_check_dependencies' );

function sr_check_dependencies() {
    if ( is_admin() && current_user_can( 'activate_plugins' ) && ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', 'sr_missing_wc_notice' );
        deactivate_plugins( plugin_basename( __FILE__ ) );
        if ( isset( $_GET['activate'] ) ) {
            unset( $_GET['activate'] );
        }
    }
}

function sr_missing_wc_notice() {
    ?>
    <div class="error notice">
        <p><?php _e( 'Starboard Reviews requires WooCommerce to be installed and active.', 'starboard-reviews' ); ?></p>
    </div>
    <?php
}

class StarboardReviews {

    public function __construct() {
        register_activation_hook( __FILE__, [ 'SR_DB', 'install' ] );
        register_deactivation_hook( __FILE__, function() { wp_clear_scheduled_hook( 'sr_cron_send_emails' ); } );
        add_action( 'plugins_loaded', [ 'SR_DB', 'maybe_upgrade' ] );

        new SR_Updater();
        new SR_Antispam();
        new SR_Ajax();
        new SR_Cron();
        new SR_Widget();
        new SR_Showcase();
        new SR_Reviews_Page_Template();

        add_action( 'admin_footer', function() {
            $screen = get_current_screen();
            if ( $screen && ( strpos( $screen->id, 'starboard' ) !== false || strpos( $screen->id, 'sr-emails' ) !== false || strpos( $screen->id, 'sr-settings' ) !== false || strpos( $screen->id, 'sr-widgets' ) !== false ) ) SR_Brand::footer();
        } );
        add_filter( 'admin_body_class', function( $classes ) {
            $screen = get_current_screen();
            return $classes . ( $screen && ( strpos( $screen->id, 'starboard' ) !== false || strpos( $screen->id, 'sr-emails' ) !== false || strpos( $screen->id, 'sr-settings' ) !== false || strpos( $screen->id, 'sr-widgets' ) !== false ) ? ' sr-admin-page' : '' );
        } );
        add_action( 'admin_enqueue_scripts', [ $this, 'admin_assets' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'front_assets' ] );
        add_action( 'admin_head', [ $this, 'inject_custom_colors' ] );
        add_action( 'wp_head', [ $this, 'inject_custom_colors' ] );

        if ( is_admin() ) {
            new SR_Admin_Menu();
        }
    }

    public function admin_assets( $hook ) {
        if ( strpos( $hook, 'starboard' ) === false && strpos( $hook, 'sr-emails' ) === false && strpos( $hook, 'sr-settings' ) === false && strpos( $hook, 'sr-widgets' ) === false ) return;
        wp_enqueue_style( 'sr-fonts', SR_URL . 'assets/fonts.css', [], SR_VERSION );
        wp_enqueue_style( 'sr-icons', SR_URL . 'assets/icons.css', [], SR_VERSION );
        wp_enqueue_style( 'sr-admin', SR_URL . 'assets/admin.css', ['sr-icons','sr-fonts'], SR_VERSION );
        wp_enqueue_script( 'jquery-ui-datepicker' );
        wp_enqueue_script( 'sr-dialogs', SR_URL . 'assets/dialogs.js', ['jquery'], SR_VERSION, true );
        if ( strpos( $hook, 'sr-widgets' ) !== false ) {
            wp_enqueue_style( 'sr-front', SR_URL . 'assets/front.css', ['sr-icons','sr-fonts'], SR_VERSION );
            wp_enqueue_style( 'sr-showcase', SR_URL . 'assets/showcase.css', ['sr-front'], SR_VERSION );
        wp_enqueue_style( 'sr-isolation', SR_URL . 'assets/isolation.css', ['sr-showcase'], SR_VERSION );
            wp_enqueue_script( 'sr-showcase', SR_URL . 'assets/showcase.js', ['jquery','sr-dialogs'], SR_VERSION, true );
            wp_enqueue_script( 'sr-front', SR_URL . 'assets/front.js', ['jquery','sr-dialogs'], SR_VERSION, true );
            wp_enqueue_script( 'sr-showcase-admin', SR_URL . 'assets/showcase-admin.js', ['jquery','sr-showcase','sr-admin-js','sr-front'], SR_VERSION, true );
        }
        wp_enqueue_script( 'sr-admin-js', SR_URL . 'assets/admin.js', ['jquery', 'jquery-ui-datepicker', 'sr-dialogs'], SR_VERSION, true );
        wp_localize_script( 'sr-admin-js', 'sr_vars', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'sr_admin_nonce' ),
            'can_manage' => current_user_can( 'manage_options' ),
            'urls' => [
                'reviews' => admin_url( 'admin.php?page=starboard-reviews' ),
                'emails' => admin_url( 'admin.php?page=sr-emails' ),
                'manual' => admin_url( 'admin.php?page=sr-emails&sub=manual' ),
                'templates' => admin_url( 'admin.php?page=sr-emails&sub=settings' ),
                'settings' => admin_url( 'admin.php?page=sr-settings' ),
                'widgets' => admin_url( 'admin.php?page=sr-widgets' ),
            ]
        ]);
    }

    public function front_assets() {
        wp_enqueue_style( 'sr-fonts', SR_URL . 'assets/fonts.css', [], SR_VERSION );
        wp_enqueue_style( 'sr-icons', SR_URL . 'assets/icons.css', [], SR_VERSION );
        wp_enqueue_style( 'sr-front', SR_URL . 'assets/front.css', ['sr-icons','sr-fonts'], SR_VERSION );
        wp_enqueue_script( 'sr-dialogs', SR_URL . 'assets/dialogs.js', ['jquery'], SR_VERSION, true );
        wp_enqueue_style( 'sr-showcase', SR_URL . 'assets/showcase.css', ['sr-front'], SR_VERSION );
        wp_enqueue_style( 'sr-isolation', SR_URL . 'assets/isolation.css', ['sr-showcase'], SR_VERSION );
        wp_enqueue_script( 'sr-showcase', SR_URL . 'assets/showcase.js', ['jquery','sr-dialogs'], SR_VERSION, true );
        wp_enqueue_script( 'sr-front', SR_URL . 'assets/front.js', array('jquery', 'sr-dialogs'), SR_VERSION, true );
        wp_localize_script( 'sr-front', 'sr_ajax', array(
            'url'   => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce( 'sr_nonce' )
        ));
    }

    public function inject_custom_colors() {
        $admin_color  = sanitize_hex_color( get_option( 'sr_color_admin', '#2563eb' ) ) ?: '#2563eb';
        $widget_color = sanitize_hex_color( get_option( 'sr_color_widget', '#2563eb' ) ) ?: '#2563eb';
        $star_color   = sanitize_hex_color( get_option( 'sr_color_star', '#fbbf24' ) ) ?: '#fbbf24';
        $font = get_option( 'sr_front_font', 'site' ) === 'starboard' ? '--sr-front-font:var(--sr-brand-font);' : '';
        echo "<style>:root { --sr-admin-accent: {$admin_color}; --sr-widget-accent: {$widget_color}; --sr-star-color: {$star_color}; {$font} }</style>";
    }
}

new StarboardReviews();
