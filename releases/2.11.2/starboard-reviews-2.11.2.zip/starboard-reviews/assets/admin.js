jQuery(document).ready(function($){

    // ==========================================================================
    // 1. STATE & INITIALIZATION
    // ==========================================================================
    var state = {
        status: 'all',
        search: '',
        from: '',
        to: '',
        sort: 'newest',
        page: 1
    };

    var reviewCache = new Map(), reviewRequest = null, reviewGeneration = 0, statsLoadedAt = 0;
    var selectedReviews = new Set();
    var editRequest = null, editGeneration = 0, activeMenuTrigger = null;

    // Initialize if on the Reviews Page
    if($('#sr-reviews-list').length) {
        loadReviews();
        initDatepickers();
    }

    // ==========================================================================
    // 2. TABLE INTERACTION (Filters, Search, Sort)
    // ==========================================================================

    // Tab Switching
    $('#sr-tabs a').on('click', function(e){
        e.preventDefault();
        $('#sr-tabs a').removeClass('active');
        $(this).addClass('active');
        state.status = $(this).data('status');
        state.page = 1; // Reset to page 1
        loadReviews();
    });

    // Search (Debounced 500ms)
    $('#sr-search').on('input', debounce(function(){
        state.search = $(this).val();
        state.page = 1;
        loadReviews();
    }, 500));

    // Sorting
    $('#sr-sort').on('change', function(){
        state.sort = $(this).val();
        state.page = 1;
        loadReviews();
    });

    // Clear All Filters
    $('#sr-clear-filters').on('click', function(e){
        e.preventDefault();

        // 1. Reset Values
        $('#sr-search').val('');
        $('#sr-date-from').val('');
        $('#sr-date-to').val('');
        $('#sr-sort').val('newest');

        // 2. RESET DATEPICKER CONSTRAINTS (Crucial Step)
        // Remove the "minDate" restriction on the End picker
        $('#sr-date-to').datepicker("option", "minDate", null);
        // Reset the "maxDate" restriction on the Start picker back to Today (0)
        $('#sr-date-from').datepicker("option", "maxDate", 0);

        // 3. Reset State
        state = { status:'all', search:'', from:'', to:'', sort:'newest', page:1 };

        // 4. Visual Reset
        $('#sr-tabs a').removeClass('active');
        $('#sr-tabs a[data-status="all"]').addClass('active');

        loadReviews();
    });

    // Pagination Click
    $(document).on('click', '.sr-page-link', function(e){
        e.preventDefault();
        if($(this).hasClass('current') || $(this).hasClass('disabled')) return;
        state.page = $(this).data('page');
        loadReviews();
    });

    // Context Menu Toggle
    $(document).on('click', '.sr-context-trigger', function(e){
        e.stopPropagation();
        activeMenuTrigger=this;
        var menu = $(this).next('.sr-dropdown');
        var rect = this.getBoundingClientRect();
        menu.css({left:Math.max(12, rect.right-174), top:rect.bottom+6});
        if (rect.bottom+menu.outerHeight()+10 > window.innerHeight) menu.css('top',rect.top-menu.outerHeight()-6);
        $('.sr-dropdown').not(menu).hide(); // Close others
        menu.toggle();
        $(this).attr('aria-expanded',menu.is(':visible') ? 'true' : 'false');
    });

    // Close Context Menu on click outside
    $(document).on('click', function(){ $('.sr-dropdown').hide(); $('.sr-context-trigger').attr('aria-expanded','false'); });
    $(document).on('click','.sr-dropdown a',function(e){e.preventDefault(); $('.sr-dropdown').hide();});
    $(window).on('scroll resize',function(){ $('.sr-dropdown').hide(); });

    // ==========================================================================
    // 3. MODAL LOGIC (Add / Edit)
    // ==========================================================================

    // Open Modal
    window.srOpenEdit = function(id) {
        var editVersion=++editGeneration;
        if(editRequest)editRequest.abort();
        var modal = $('#sr-edit-modal');
        var form = $('#sr_edit_form');
        var photoArea = $('#edit-photo-area');
        var photoPreview = $('#edit-photo-preview');

        // 1. Reset Form & UI
        form[0].reset();
        $('#edit_id').val(''); // IMPORTANT: Clear ID to prevent overwrite issues on "Add New"
        photoArea.hide();
        photoPreview.empty();

        // 2. Ensure Loading Overlay Exists
        if(modal.find('.sr-loading-overlay').length === 0) {
            modal.find('.sr-modal-body').css('position', 'relative')
                .append('<div class="sr-loading-overlay" style="position:absolute; inset:0; background:rgba(255,255,255,0.8); display:none; align-items:center; justify-content:center; z-index:10;"><div class="sr-spinner" style="width:30px;height:30px;border:3px solid #e2e8f0;border-top-color:#2563eb;border-radius:50%;animation:spin .8s linear infinite;"></div></div>');
        }
        var overlay = modal.find('.sr-loading-overlay');

        // 3. Open Modal Immediately
        window.srDialog.open(modal);

        if(id) {
            // --- EDIT MODE ---
            $('#modal-title').text('Manage review #'+id);
            overlay.css('display', 'flex'); // Show Spinner

            editRequest=$.post(sr_vars.ajax_url, {
                action: 'sr_get_review',
                nonce: sr_vars.nonce,
                id: id
            }, function(res){
                if(editVersion!==editGeneration)return;
                overlay.hide(); // Hide Spinner

                if(res.success) {
                    var d = res.data;
                    $('#edit_id').val(d.id);
                    $('#edit_title').val(d.title);
                    $('#edit_author').val(d.author);
                    $('#edit_email').val(d.email);
                    $('#edit_pid').val(d.pid);
                    $('#edit_content').val(d.content);
                    if(d.date) $('#edit_date_input').val(d.date.split(' ')[0]);
                    $('#edit_reply').val(d.reply);

                    // Set Star Rating
                    $('input[name="rating"][value="'+d.rating+'"]').prop('checked', true);

                    // Set Customer Service Rating (optional — falls back to "None")
                    if ( d.cs_rating ) {
                        $('input[name="cs_rating"][value="'+d.cs_rating+'"]').prop('checked', true);
                    } else {
                        $('#edit_cs_none').prop('checked', true);
                    }

                    // Display Existing Photos
                    if(d.photos && d.photos.length > 0) {
                        photoArea.show();
                        d.photos.forEach(function(url){
                            photoPreview.append('<img src="'+url+'" class="sr-photo-item" style="width:60px;height:60px;object-fit:cover;border-radius:6px;border:1px solid #e2e8f0; margin-right:8px;" onclick="window.open(this.src)">');
                        });
                    }
                } else {
                    showToast('Error loading review', 'error');
                    window.srDialog.close(modal);
                }
            }).fail(function(xhr,status){if(status==='abort'||editVersion!==editGeneration)return;overlay.hide();showToast(xhr.responseJSON&&xhr.responseJSON.data?xhr.responseJSON.data.message:'Unable to load review. Please try again.','error');window.srDialog.close(modal);});
        } else {
            // --- ADD NEW MODE ---
            $('#modal-title').text('Add New Review');
            $('input[name="rating"][value="5"]').prop('checked', true); // Default 5 stars
            $('#edit_cs_none').prop('checked', true); // Customer Service rating is optional
            overlay.hide();
        }
    };

    // Handle Photo Input Change (Show Preview for New Uploads)
    $('#edit_photo_input').on('change', function(){
        var files = this.files;
        var previewBox = $('#edit-photo-preview');
        var area = $('#edit-photo-area');

        previewBox.empty(); // Clear existing previews

        if(files.length > 0) {
            area.show();
            if(files.length > 5) {
                alert("Max 5 photos allowed");
                this.value = "";
                area.hide();
                return;
            }

            Array.from(files).forEach(function(file){
                var reader = new FileReader();
                reader.onload = function(e){
                    previewBox.append('<img src="'+e.target.result+'" style="width:60px;height:60px;object-fit:cover;border-radius:6px;border:1px solid #e2e8f0; margin-right:8px;">');
                }
                reader.readAsDataURL(file);
            });
        } else {
            area.hide();
        }
    });

    // Close Modal Logic
    $('.sr-close-modal, .sr-modal').on('click', function(e){
        if(e.target === this || $(this).hasClass('sr-close-modal')) {
            window.srDialog.close($(this).closest('.sr-modal'));
        }
    });

    // Generic Modal Opener (For Import Modal)
    window.srOpenModal = function(selector) {
        window.srDialog.open($(selector));
    };

    // ==========================================================================
    // 4. DATA ACTIONS (Save, Delete, Approve)
    // ==========================================================================

    // Save Review (Add/Edit)
    $('#sr-save-btn').on('click', function(e){
        e.preventDefault();
        var btn = $(this);
        var editForm = $('#sr_edit_form')[0];
        if (!editForm.reportValidity()) return;
        btn.text('Saving...').prop('disabled', true);

        // Use FormData to support Files and Inputs
        var fd = new FormData($('#sr_edit_form')[0]);
        fd.append('action', 'sr_save_review');
        fd.append('nonce', sr_vars.nonce);

        $.ajax({
            url: sr_vars.ajax_url,
            type: 'POST',
            data: fd,
            contentType: false, // Required for FormData
            processData: false, // Required for FormData
            success: function(res){
                btn.text('Save Review').prop('disabled', false);
                if(res.success) {
                    $('.sr-modal:visible').each(function(){ window.srDialog.close($(this)); });
                    showToast('Review saved.');
                    loadReviews(true);
                } else {
                    showToast(res.data && res.data.message ? res.data.message : 'Error saving review', 'error');
                }
            },
            error: function(xhr){ btn.text('Save Review').prop('disabled', false); showToast(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to save review', 'error'); }
        });
    });

    // Update Status (Context Menu Actions)
    window.srStatus = function(id, status) {
        $.post(sr_vars.ajax_url, {
            action: 'sr_update_status',
            nonce: sr_vars.nonce,
            id: id,
            status: status
        }, function(res){
            if(res.success) {
                showToast('Status updated.');
                loadReviews(true);
            } else {
                showToast('Action failed', 'error');
            }
        });
    };

    // Import CSV
    $('#sr-import-btn').on('click', function(e){
        e.preventDefault();
        var btn = $(this);
        var file_input = $('#sr-import-form input[name="csv"]');

        if(file_input[0].files.length === 0) {
            $('#sr-import-message').text('Choose a CSV file to continue.').addClass('is-error');
            return;
        }

        if (file_input[0].files[0].size > 5*1024*1024) { $('#sr-import-message').text('Choose a CSV smaller than 5 MB.').addClass('is-error'); return; }
        $('#sr-import-message').text('Importing reviews. Large files may take a moment.').removeClass('is-error');
        var fd = new FormData();
        fd.append('csv', file_input[0].files[0]);
        fd.append('action', 'sr_import_csv');
        fd.append('nonce', sr_vars.nonce);

        btn.text('Importing...').prop('disabled', true);

        $.ajax({
            url: sr_vars.ajax_url, type: 'POST', data: fd, contentType: false, processData: false,
            success: function(res) {
                btn.text('Import reviews').prop('disabled', false);
                if(res.success) {
                    window.srDialog.close($('#sr-import-modal'));
                    showToast(res.data.message);
                    loadReviews(true);
                } else {
                    $('#sr-import-message').text(res.data && res.data.message ? res.data.message : 'Import failed.').addClass('is-error');
                }
            },
            error: function(xhr){ btn.text('Import reviews').prop('disabled', false); $('#sr-import-message').text(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to import CSV.').addClass('is-error'); }
        });
    });

    // Export CSV
    $('#btn-export').on('click', function(e){
        e.preventDefault();
        window.location = sr_vars.ajax_url + '?action=sr_export_csv&nonce=' + encodeURIComponent(sr_vars.nonce);
    });

    // ==========================================================================
    // 5. SETTINGS & HELPERS
    // ==========================================================================

    // Save Settings
    $('#sr-save-gen-btn').on('click', function(e){
        e.preventDefault();
        var btn = $(this);
        btn.text('Saving...');
        $.post(sr_vars.ajax_url, {
            action: 'sr_save_settings', nonce: sr_vars.nonce, data: $('#sr-general-form').serialize()
        }, function(res){
            btn.text('Save Changes');
            showToast(res.success ? 'Settings Saved' : 'Error saving');
        }).fail(function(xhr){ btn.text('Save Changes'); showToast(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to save settings', 'error'); });
    });

    // Copy Shortcode
    $('#sr-copy-sc').on('click', function(e){
        e.preventDefault();
        var copyText = document.getElementById("sr-sc-output");
        copyText.select();
        document.execCommand("copy");
        showToast('Shortcode Copied!');
    });

    // --- SEND TEST EMAIL (UX IMPROVED) ---
    $(document).on('click', '#sr_send_test', function(e){
        e.preventDefault();

        var btn = $(this);
        var email = $('#test_email_addr').val();
        var originalText = btn.html(); // Save icon/text

        // 1. Basic Validation
        if(!email || !email.includes('@')) {
            showToast('Please enter a valid email address', 'error');
            return;
        }

        // 2. Loading State
        btn.prop('disabled', true).html('<i class="sr-icon sr-icon-loader-circle sr-icon-spin" aria-hidden="true"></i> Sending...');

        // 3. AJAX Request
        $.ajax({
            url: sr_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'sr_send_test',
                nonce: sr_vars.nonce,
                email: email
            },
            success: function(res) {
                if(res.success) {
                    showToast('Test message accepted by the mail service.');
                    btn.html('<i class="sr-icon sr-icon-check" aria-hidden="true"></i> Sent!');
                } else {
                    showToast(res.data.message || 'Failed to send', 'error');
                    btn.html('<i class="sr-icon sr-icon-triangle-alert" aria-hidden="true"></i> Failed');
                }
            },
            error: function(xhr, status, error) {
                console.error(error);
                showToast('Server Error: ' + error, 'error');
                btn.html('<i class="sr-icon sr-icon-x" aria-hidden="true"></i> Error');
            },
            complete: function() {
                // Reset button after 3 seconds
                setTimeout(function(){
                    btn.prop('disabled', false).html(originalText);
                }, 3000);
            }
        });
    });


    // Live Email Preview (Advanced Tags)
    if($('#body1').length) {
        $('#body1').on('input', function(){
            var val = $(this).val();

            // 1. Simple Replacements
            val = val.replace(/{first_name}|{name}/g, '<strong>John</strong>')
                     .replace(/{last_name}/g, '<strong>Doe</strong>')
                     .replace(/{order_id}/g, '#12345')
                     .replace(/{shop_name}/g, 'My Awesome Store');

            // 2. Complex Table Replacement
            var fakeTable = `
                <table width="100%" cellspacing="0" cellpadding="10" style="background:#f9fafb; border-radius:8px; border-collapse:collapse; margin-top:10px;">
                    <tr>
                        <td width="50" style="border-bottom:1px solid #e5e7eb; padding:12px;"><div style="width:50px; height:50px; background:#e2e8f0; border-radius:4px;"></div></td>
                        <td style="border-bottom:1px solid #e5e7eb; padding:12px;"><strong style="display:block; color:#333;">Premium T-Shirt</strong><span style="font-size:12px; color:#666;">$25.00</span></td>
                        <td align="right" style="border-bottom:1px solid #e5e7eb; padding:12px;"><a href="#" style="background:#2563eb; color:#fff; text-decoration:none; padding:6px 12px; border-radius:4px; font-size:12px;">Review</a></td>
                    </tr>
                    <tr>
                        <td width="50" style="padding:12px;"><div style="width:50px; height:50px; background:#e2e8f0; border-radius:4px;"></div></td>
                        <td style="padding:12px;"><strong style="display:block; color:#333;">Coffee Mug</strong><span style="font-size:12px; color:#666;">$12.00</span></td>
                        <td align="right" style="padding:12px;"><a href="#" style="background:#2563eb; color:#fff; text-decoration:none; padding:6px 12px; border-radius:4px; font-size:12px;">Review</a></td>
                    </tr>
                </table>`;

            val = val.replace(/{order_table}|{products}/g, fakeTable);

            // 3. Newline to BR
            val = val.replace(/\n/g, '<br>');

            $('#sr-preview').html(val);
        }).trigger('input');
    }

    // Save Email Settings
    $(document).on('click', '#sr-save-email-settings', function(e){
        e.preventDefault();
        var btn = $(this);
        var form = $('#sr-email-settings-form');

        btn.text('Saving...').prop('disabled', true);

        $.post(sr_vars.ajax_url, {
            action: 'sr_save_settings',
            nonce: sr_vars.nonce,
            data: form.serialize()
        }, function(res){
            btn.text('Save Settings').prop('disabled', false);
            if(res.success) {
                showToast('Email Settings Saved');
            } else {
                showToast('Error saving settings', 'error');
            }
        }).fail(function(xhr){
            btn.text('Save Settings').prop('disabled', false);
            showToast(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to save settings', 'error');
        });
    });

    // --- FORCE RUN QUEUE (Add this inside jQuery(document).ready) ---
    $(document).on('click', '#sr-force-run-btn', function(e){
        e.preventDefault();
        var btn = $(this);
        var originalText = btn.html();

        btn.html('<i class="sr-icon sr-icon-loader-circle sr-icon-spin" aria-hidden="true"></i> Processing...').prop('disabled', true);

        $.post(sr_vars.ajax_url, {
            action: 'sr_force_run_emails',
            nonce: sr_vars.nonce
        }, function(res){
            if(res.success) {
                showToast(res.data.message);
                // Reload page after 1.5 seconds to show updated "Sent" status
                setTimeout(function(){ location.reload(); }, 1500);
            } else {
                btn.html(originalText).prop('disabled', false);
                showToast('Error processing queue', 'error');
            }
        }).fail(function(){
             btn.html(originalText).prop('disabled', false);
             showToast('Server error occurred', 'error');
        });
    });

    function applyReviews(data) {
        if (data.pages && state.page > data.pages) {state.page=Math.max(1,data.pages);loadReviews();return;}
        $('#sr-reviews-list').html(data.html);
        renderPagination(data.pages,state.page);
        if (data.stats_html !== null && data.stats_html !== undefined) $('#sr-stats-container').html(data.stats_html);
        if (data.counts) Object.keys(data.counts).forEach(function(key){$('#cnt-'+key).text(data.counts[key]);});
        var total=Number(data.total)||0;
        $('#sr-results-caption').text(total ? ((state.page-1)*20+1)+'–'+Math.min(state.page*20,total)+' of '+total+' reviews' : 'No matching reviews');
        updateSelection();
    }

    // Abort obsolete requests and reuse recent views; aggregation runs at most once
    // per thirty seconds unless a moderation action invalidates the data.
    function loadReviews(force) {
        if (!$('#sr-reviews-list').length) return;
        if (force) { reviewCache.clear(); statsLoadedAt=0; }
        if (reviewRequest) reviewRequest.abort();
        var generation=++reviewGeneration, key=JSON.stringify(state), cached=reviewCache.get(key);
        if (!force && cached && Date.now()-cached.at<20000 && Date.now()-statsLoadedAt<30000) {applyReviews(cached.data);return;}
        var list=$('#sr-reviews-list'), card=list.closest('.sr-table-card');
        card.addClass('is-loading').attr('aria-busy','true');
        if (!list.children().length) list.html('<tr class="sr-skeleton-row"><td colspan="7"><div class="sr-skeleton"></div><div class="sr-skeleton"></div></td></tr>');
        var includeStats=Date.now()-statsLoadedAt>=30000;
        reviewRequest=$.ajax({url:sr_vars.ajax_url,type:'POST',data:{action:'sr_load_data',nonce:sr_vars.nonce,...state,include_stats:includeStats?'1':'0'}})
            .done(function(res){
                if (generation!==reviewGeneration) return;
                if (!res.success) {showToast(res.data && res.data.message ? res.data.message : 'Unable to load reviews.','error');return;}
                if (includeStats) statsLoadedAt=Date.now();
                if (reviewCache.size>=30) reviewCache.delete(reviewCache.keys().next().value);
                reviewCache.set(key,{data:res.data,at:Date.now()});
                applyReviews(res.data);
            }).fail(function(xhr,status){
                if (status==='abort' || generation!==reviewGeneration) return;
                showToast(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to load reviews. Please try again.','error');
                if (list.find('.sr-skeleton-row').length) list.html('<tr><td colspan="7"><div class="sr-empty-state"><strong>Could not load reviews</strong><button type="button" class="sr-btn white sr-retry-reviews">Try again</button></div></td></tr>');
            }).always(function(){if(generation===reviewGeneration)card.removeClass('is-loading').attr('aria-busy','false');});
    }
    $(document).on('click','.sr-retry-reviews',function(){loadReviews(true);});

    function updateSelection() {
        $('.sr-review-checkbox').each(function(){this.checked=selectedReviews.has(String(this.value));$(this).closest('tr').toggleClass('is-selected',this.checked);});
        var boxes=$('.sr-review-checkbox'), checked=boxes.filter(':checked').length;
        $('#sr-select-reviews').prop('checked',boxes.length>0 && checked===boxes.length).prop('indeterminate',checked>0 && checked<boxes.length);
        $('#sr-selected-count').text(selectedReviews.size+' selected');
        $('#sr-review-bulk-bar').prop('hidden',selectedReviews.size===0);
    }
    $(document).on('change','.sr-review-checkbox',function(){
        var id=String(this.value);
        if (this.checked && selectedReviews.size>=50 && !selectedReviews.has(id)) {this.checked=false;showToast('Select up to 50 reviews at a time.','error');return;}
        if (this.checked) selectedReviews.add(id); else selectedReviews.delete(id);
        updateSelection();
    });
    $('#sr-select-reviews').on('change',function(){var checked=this.checked;$('.sr-review-checkbox').prop('checked',checked).trigger('change');});
    $('#sr-clear-selection').on('click',function(){selectedReviews.clear();updateSelection();});
    function openBulk(status) {
        $('#sr-bulk-review-form')[0].reset();
        $('#sr-bulk-status').val(status||'keep');
        $('#sr-bulk-summary').text('Apply changes to '+selectedReviews.size+' selected reviews. Unchanged fields will be kept.');
        $('#sr-bulk-message').empty().removeClass('is-error');
        window.srDialog.open($('#sr-bulk-review-modal'));
    }
    $('#sr-bulk-edit-open').on('click',function(){openBulk();});
    $('#sr-bulk-trash').on('click',function(){openBulk('trash');});
    function saveBulk(status) {
        var button=$('#sr-bulk-review-save'), inline=$('#sr-bulk-message');
        button.prop('disabled',true).text('Applying…');
        return $.ajax({url:sr_vars.ajax_url,type:'POST',data:{action:'sr_bulk_reviews',nonce:sr_vars.nonce,ids:Array.from(selectedReviews),status:status||$('#sr-bulk-status').val(),rating:status?'':$('#sr-bulk-rating').val(),cs_rating:status?'':$('#sr-bulk-cs').val()}})
            .done(function(res){
                if (!res.success) {inline.text(res.data.message).addClass('is-error');return;}
                selectedReviews.clear();updateSelection();window.srDialog.close($('#sr-bulk-review-modal'));showToast(res.data.message);loadReviews(true);
            }).fail(function(xhr){inline.text(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to apply changes.').addClass('is-error');loadReviews(true);})
            .always(function(){button.prop('disabled',false).text('Apply changes');});
    }
    $('#sr-bulk-review-save').on('click',function(){saveBulk();});
    $('#sr-bulk-publish').on('click',function(){
        var button=$(this);button.prop('disabled',true);
        saveBulk('approve').fail(function(xhr){showToast(xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data.message : 'Unable to publish selected reviews.','error');}).always(function(){button.prop('disabled',false);});
    });
    $('#sr-import-file').on('change',function(){
        var file=this.files[0];$('#sr-import-filename').text(file ? file.name+' · '+(file.size/1024).toFixed(0)+' KB' : 'or drop it here · up to 5 MB');$('#sr-import-message').empty();
    });
    $('.sr-upload-zone').on('dragenter dragover',function(){ $(this).addClass('is-dragover'); }).on('dragleave drop',function(){ $(this).removeClass('is-dragover'); });

    function renderPagination(totalPages, currentPage) {
        var html = '';
        if(totalPages > 1) {
            if(currentPage > 1) html += `<a href="#" class="sr-page-link" data-page="${currentPage-1}" aria-label="Previous review page"><span class="sr-icon sr-icon-chevron-left" aria-hidden="true"></span></a>`;
            for(var i = 1; i <= totalPages; i++) {
                if(i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
                    var active = i === currentPage ? 'current' : '';
                    html += `<a href="#" class="sr-page-link ${active}" data-page="${i}">${i}</a>`;
                } else if(i === currentPage - 2 || i === currentPage + 2) {
                    html += `<span style="padding:5px; color:#ccc;">...</span>`;
                }
            }
            if(currentPage < totalPages) html += `<a href="#" class="sr-page-link" data-page="${currentPage+1}" aria-label="Next review page"><span class="sr-icon sr-icon-chevron-right" aria-hidden="true"></span></a>`;
        }
        $('#sr-pagination').html(html);
    }

    function initDatepickers() {
        // Common settings
        var config = {
            dateFormat: 'yy-mm-dd',
            maxDate: 0, // Disable future dates (0 = today)
            changeMonth: true,
            changeYear: true
        };

        // Initialize Start Date
        $('#sr-date-from').datepicker($.extend({}, config, {
            onSelect: function(selectedDate) {
                // When Start is selected, End date cannot be BEFORE this date
                $('#sr-date-to').datepicker("option", "minDate", selectedDate);

                state.from = selectedDate;
                state.page = 1;
                loadReviews();
            }
        }));

        // Initialize End Date
        $('#sr-date-to').datepicker($.extend({}, config, {
            onSelect: function(selectedDate) {
                // When End is selected, Start date cannot be AFTER this date
                $('#sr-date-from').datepicker("option", "maxDate", selectedDate);

                state.to = selectedDate;
                state.page = 1;
                loadReviews();
            }
        }));

        // Simple initialization for the Edit modal
        $('#edit_date_input').datepicker(config);
    }

    function showToast(message, type = 'success') {
        $('#sr-toast').remove();
        var bg = type === 'error' ? '#ef4444' : '#0f172a';
        var toast = $('<div id="sr-toast" role="status" aria-live="polite">').text(message).css('background-color', bg);
        $('body').append(toast);
        setTimeout(function(){ toast.addClass('show'); }, 10);
        setTimeout(function(){ toast.removeClass('show'); setTimeout(function(){ toast.remove(); }, 300); }, 3000);
    }

    // Keep labels and controls programmatically connected, including older settings markup.
    $('.sr-wrap label, .sr-modal label').each(function(index){
        var label=$(this);if(label.attr('for') || label.find('input,select,textarea').length)return;
        var control=label.next('input,select,textarea');
        if(!control.length && label.parent().find('input:not([type="hidden"]),select,textarea').length===1)control=label.parent().find('input:not([type="hidden"]),select,textarea').first();
        if(control.length){if(!control.attr('id'))control.attr('id','sr-field-'+index);label.attr('for',control.attr('id'));}
    });
    $('.sr-modal').each(function(){var title=$(this).find('h2,h3').first();if(title.length){if(!title.attr('id'))title.attr('id',this.id+'-title');$(this).attr('aria-labelledby',title.attr('id'));}});
    var commands=[{name:'Reviews',detail:'Feedback & moderation',url:sr_vars.urls.reviews}];
    if(sr_vars.urls.widgets)commands.push({name:'Widget builder',detail:'Home page & landing page reviews',url:sr_vars.urls.widgets});
    if(sr_vars.can_manage)commands=commands.concat([
        {name:'Email activity',detail:'Request delivery logs',url:sr_vars.urls.emails},
        {name:'Send review requests',detail:'Choose orders',url:sr_vars.urls.manual},
        {name:'Email templates',detail:'Design & automation',url:sr_vars.urls.templates},
        {name:'Settings',detail:'Review rules & appearance',url:sr_vars.urls.settings}
    ]);
    if($('#sr-add-review').length)commands=commands.concat([
        {name:'Add a review',detail:'Create',run:function(){window.srOpenEdit(null);}},
        {name:'Import reviews',detail:'CSV file',run:function(){window.srOpenModal('#sr-import-modal');}},
        {name:'Export reviews',detail:'Download CSV',run:function(){$('#btn-export').trigger('click');}}
    ]);
    (sr_vars.products||[]).forEach(function(product){if(product.id!=='reviews'&&product.home_url)commands.push({name:'Starboard '+product.label,detail:'Starboard family',url:product.home_url});});
    var visibleCommands=[],commandIndex=0;
    function renderCommands(){
        var query=$('#sr-command-search').val().toLowerCase();
        visibleCommands=commands.filter(function(item){return (item.name+' '+item.detail).toLowerCase().includes(query);});commandIndex=0;
        var results=$('#sr-command-results').empty();
        visibleCommands.forEach(function(item,index){$('<button type="button" class="sr-command-item">').toggleClass('is-current',index===0).attr('data-index',index).append($('<span>').text(item.name),$('<small>').text(item.detail)).appendTo(results);});
        if(!visibleCommands.length)$('<p class="sr-field-help">').text('No matching pages or actions.').appendTo(results);
    }
    function runCommand(index){var item=visibleCommands[index];if(!item)return;window.srDialog.close($('#sr-command-modal'));if(item.run)item.run();else window.location.href=item.url;}
    function openCommands(){window.srDialog.open($('#sr-command-modal'));$('#sr-command-search').val('').trigger('input').trigger('focus');}
    $('.sr-command-trigger').on('click',openCommands).find('kbd').text(/Mac|iPhone|iPad/.test(navigator.platform)?'⌘ K':'Ctrl K');
    $('#sr-command-search').on('input',renderCommands).on('keydown',function(event){
        if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();commandIndex=(commandIndex+(event.key==='ArrowDown'?1:-1)+visibleCommands.length)%Math.max(1,visibleCommands.length);$('.sr-command-item').removeClass('is-current').eq(commandIndex).addClass('is-current');}
        if(event.key==='Enter'){event.preventDefault();runCommand(commandIndex);}
    });
    $(document).on('click','.sr-command-item',function(){runCommand(Number($(this).data('index')));});
    $(document).on('keydown',function(event){
        if(event.key==='Escape'&&$('.sr-dropdown:visible').length){$('.sr-dropdown').hide();if(activeMenuTrigger)activeMenuTrigger.focus();}
        if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='k'){event.preventDefault();openCommands();}
        if(event.key==='/'&&!$(event.target).is('input,textarea,select,[contenteditable]')&&!$('.sr-modal:visible').length){event.preventDefault();$('#sr-search').trigger('focus');}
    });

    function debounce(f,t){var i;return function(){clearTimeout(i);i=setTimeout(()=>f.apply(this,arguments),t)}}
});
