/* Shared keyboard and focus behavior for Starboard dialogs. */
(function($){
    'use strict';
    var stack = [], scrollLock = null;
    function lockPage(){
        var body=document.body,html=document.documentElement;
        scrollLock={x:window.scrollX,y:window.scrollY,body:{},htmlOverflow:html.style.overflow};
        ['position','top','left','right','width','overflow'].forEach(function(key){scrollLock.body[key]=body.style[key];});
        body.style.position='fixed';body.style.top=-scrollLock.y+'px';body.style.left=-scrollLock.x+'px';body.style.right='0';body.style.width='100%';body.style.overflow='hidden';html.style.overflow='hidden';
    }
    function unlockPage(){
        if(!scrollLock)return;
        var saved=scrollLock;scrollLock=null;
        Object.keys(saved.body).forEach(function(key){document.body.style[key]=saved.body[key];});
        document.documentElement.style.overflow=saved.htmlOverflow;
        var behavior=document.documentElement.style.scrollBehavior;
        document.documentElement.style.scrollBehavior='auto';window.scrollTo(saved.x,saved.y);document.documentElement.style.scrollBehavior=behavior;
    }
    function focusable(node) {
        return node.find('a[href], button, summary, input:not([type="hidden"]), select, textarea, [tabindex="0"]').filter(function(){return !this.disabled && this.getClientRects().length;});
    }
    window.srDialog = {
        open: function(node) {
            node = $(node);
            if (!node.length || stack.some(function(item){return item.node[0] === node[0];})) return;
            if (!stack.length) lockPage();
            stack.push({node:node, trigger:document.activeElement});
            node.attr({'role':'dialog','aria-modal':'true','aria-hidden':'false',tabindex:'-1'}).addClass('is-open').css('display','flex');
            var first = focusable(node).first();
            (first.length ? first : node).trigger('focus');
        },
        close: function(node) {
            node = $(node);
            var index = stack.findIndex(function(item){return item.node[0] === node[0];});
            var item = index >= 0 ? stack.splice(index,1)[0] : null;
            node.removeClass('is-open').css('display','none').attr('aria-hidden','true');
            if (item && !stack.length) unlockPage();
            if (item && item.trigger && item.trigger.isConnected) item.trigger.focus({preventScroll:true});
        }
    };
    document.addEventListener('click',function(event){
        var close = $(event.target).closest('.sr-close-modal, .sr-close-btn, .sr-lightbox-close');
        var overlay = $(event.target).closest('.sr-modal, .sr-modal-overlay, .sr-lightbox-overlay');
        if (close.length || (overlay.length && event.target === overlay[0])) {
            event.preventDefault(); event.stopImmediatePropagation();
            window.srDialog.close(overlay);
        }
    },true);
    $(document).on('keydown.srDialogs',function(event){
        if (!stack.length) return;
        var top = stack[stack.length-1].node;
        if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); window.srDialog.close(top); }
        if (event.key === 'Tab') {
            var items = focusable(top), first=items[0], last=items[items.length-1];
            if (!items.length) { event.preventDefault(); top.trigger('focus'); }
            else if (event.shiftKey && (document.activeElement===first || !top[0].contains(document.activeElement))) {event.preventDefault(); last.focus();}
            else if (!event.shiftKey && (document.activeElement===last || !top[0].contains(document.activeElement))) {event.preventDefault(); first.focus();}
        }
    });
})(jQuery);
