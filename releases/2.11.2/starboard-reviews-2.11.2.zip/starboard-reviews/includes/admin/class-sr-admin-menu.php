<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SR_Admin_Menu {
    public static $owns_root = false;
    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_menus' ], 10 );
        add_filter( 'parent_file', [ $this, 'parent_file' ] );
        add_filter( 'submenu_file', [ $this, 'submenu_file' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'menu_assets' ] );
    }

    public function register_menus() {
        if ( ! current_user_can( 'moderate_comments' ) ) return;
        global $menu;
        $exists = false;
        foreach ( (array) $menu as $item ) {
            if ( 'starboard' === $item[2] ) { $exists = true; break; }
        }
        if ( ! $exists ) {
            self::$owns_root = true;
            add_menu_page( 'Starboard', 'Starboard', 'read', 'starboard', [ 'SR_Reviews_Page', 'render' ], 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( SR_PATH . 'assets/brand/starboard-menu.svg' ) ), 56 );
        }
        add_submenu_page( 'starboard', 'Starboard Reviews', 'Reviews', 'moderate_comments', 'starboard-reviews', [ 'SR_Reviews_Page', 'render' ] );
        // These screens remain reachable through Reviews' own navigation and existing URLs.
        add_submenu_page( '', 'Review showcases', 'Widgets', 'moderate_comments', 'sr-widgets', [ 'SR_Widgets_Page', 'render' ] );
        add_submenu_page( '', 'Email Automation', 'Emails', 'manage_options', 'sr-emails', [ 'SR_Emails_Page', 'render' ] );
        add_submenu_page( '', 'Settings', 'Settings', 'manage_options', 'sr-settings', [ 'SR_Settings_Page', 'render' ] );
        remove_submenu_page( 'starboard', 'starboard' );
    }

    public function parent_file( $parent ) { return SR_Suite::screen() ? 'starboard' : $parent; }
    public function submenu_file( $submenu ) { return SR_Suite::screen() ? 'starboard-reviews' : $submenu; }
    public function menu_assets() {
        wp_enqueue_style( 'sr-suite-menu', SR_URL . 'assets/suite-menu.css', [], SR_VERSION );
    }
}
