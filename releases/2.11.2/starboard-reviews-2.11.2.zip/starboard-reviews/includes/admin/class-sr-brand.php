<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Shared Starboard suite identity; the product name stays separate from the mark. */
class SR_Brand {
    public static function products() {
        return array_filter( (array) apply_filters('starboard_products_v1', []), function($product) {
            return is_array($product) && 1 === ($product['contract']??0)
                && is_string($product['id']??null) && is_string($product['label']??null)
                && is_string($product['home_url']??null) && is_string($product['capability']??null)
                && current_user_can($product['capability']);
        } );
    }
    public static function header( $active = 'reviews' ) {
        $links = [
            'reviews' => [ 'Reviews', 'admin.php?page=starboard-reviews' ],
            'widgets' => [ 'Widgets', 'admin.php?page=sr-widgets' ],
            'emails' => [ 'Emails', 'admin.php?page=sr-emails' ],
            'settings' => [ 'Settings', 'admin.php?page=sr-settings' ],
        ];
        $suite_brand = apply_filters( 'starboard_brand_v1', [] );
        $light = SR_URL . 'assets/brand/starboard-lockup.svg';
        $dark = SR_URL . 'assets/brand/starboard-lockup-reverse.svg';
        $safe = ( defined('STARBOARD_UI_SAFE_MODE') && STARBOARD_UI_SAFE_MODE ) || ( isset($_GET['starboard-safe']) && '1' === $_GET['starboard-safe'] );
        if ( ! $safe && is_array($suite_brand) && 1 === ($suite_brand['contract']??0) ) {
            if ( is_string($suite_brand['logo_light']??null) && esc_url_raw($suite_brand['logo_light'], ['http','https']) ) $light = $suite_brand['logo_light'];
            if ( is_string($suite_brand['logo_dark']??null) && esc_url_raw($suite_brand['logo_dark'], ['http','https']) ) $dark = $suite_brand['logo_dark'];
            elseif ( $light !== SR_URL . 'assets/brand/starboard-lockup.svg' ) $dark = $light;
        }
        ?>
        <header class="sr-masthead">
            <a class="sr-brand" href="<?php echo esc_url( admin_url( 'admin.php?page=starboard-reviews' ) ); ?>" aria-label="Starboard Reviews home">
                <img src="<?php echo esc_url( $light ); ?>" data-light="<?php echo esc_url($light); ?>" data-dark="<?php echo esc_url($dark); ?>" alt="Starboard" width="196" height="56">
                <span class="sr-product-badge">Reviews</span>
            </a>
            <nav class="sr-main-nav" aria-label="Starboard Reviews">
                <?php foreach ( $links as $key => $link ) :
                    if ( ! in_array( $key, [ 'reviews','widgets' ], true ) && ! current_user_can( 'manage_options' ) ) continue; ?>
                    <a href="<?php echo esc_url( admin_url( $link[1] ) ); ?>" <?php if ( $active === $key ) echo 'aria-current="page"'; ?>><?php echo esc_html( $link[0] ); ?></a>
                <?php endforeach; ?>
            </nav>
            <?php $products = self::products(); if(is_array($products) && count($products)>1): ?><nav class="sr-suite-products" aria-label="Starboard products"><?php foreach($products as $product){if(!is_array($product)||empty($product['capability'])||!current_user_can($product['capability']))continue;?><a href="<?php echo esc_url($product['home_url']??''); ?>" <?php if('reviews'===($product['id']??''))echo 'aria-current="page"'; ?>><?php echo esc_html($product['label']??''); ?></a><?php } ?></nav><?php endif; ?>
            <button type="button" class="sr-command-trigger" aria-label="Open quick navigation" aria-haspopup="dialog"><span>Jump to…</span><kbd>⌘ K</kbd></button>
        </header>
        <?php
    }

    public static function footer() {
        ?>
        <div class="sr-modal sr-command-modal" id="sr-command-modal" role="dialog" aria-modal="true" aria-labelledby="sr-command-title" tabindex="-1">
            <div class="sr-modal-panel">
                <div class="sr-modal-head"><h2 id="sr-command-title">Quick navigation</h2><button type="button" class="sr-close-modal" aria-label="Close navigation"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button></div>
                <div class="sr-modal-body">
                    <label class="sr-screen-reader" for="sr-command-search">Find a page or action</label>
                    <input type="search" id="sr-command-search" placeholder="Find a page or action…" autocomplete="off">
                    <div id="sr-command-results"></div>
                    <p class="sr-field-help"><span class="sr-icon sr-icon-arrow-up" aria-hidden="true"></span> <span class="sr-icon sr-icon-arrow-down" aria-hidden="true"></span> Navigate · Enter to open · Esc to close</p>
                </div>
            </div>
        </div>
        <?php
    }
}
