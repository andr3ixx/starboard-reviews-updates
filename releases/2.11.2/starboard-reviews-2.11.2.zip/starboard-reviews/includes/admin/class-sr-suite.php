<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Optional Starboard contract. No dependency on the UI plugin's classes or files. */
class SR_Suite {
    public static function boot() {
        add_filter( 'starboard_products_v1', [__CLASS__,'product'] );
        add_action( 'admin_head', [__CLASS__,'theme_head'], 1 );
        add_action( 'admin_enqueue_scripts', [__CLASS__,'assets'], 40 );
        add_action( 'show_user_profile', [__CLASS__,'profile'] );
        add_action( 'personal_options_update', [__CLASS__,'save_profile'] );
    }
    public static function screen() {
        $screen = get_current_screen();
        if($screen && 'toplevel_page_starboard' === $screen->id) return class_exists('SR_Admin_Menu') && SR_Admin_Menu::$owns_root;
        return $screen && in_array( $screen->id, ['admin_page_sr-widgets','admin_page_sr-emails','admin_page_sr-settings','starboard_page_starboard-reviews','starboard_page_sr-widgets','starboard_page_sr-emails','starboard_page_sr-settings','toplevel_page_starboard-reviews','starboard-reviews_page_sr-widgets','starboard-reviews_page_sr-emails','starboard-reviews_page_sr-settings'], true );
    }
    public static function product( $products ) {
        $products = is_array( $products ) ? $products : [];
        if ( current_user_can( 'moderate_comments' ) ) $products['reviews'] = ['id'=>'reviews','label'=>'Reviews','version'=>SR_VERSION,'contract'=>1,'home_url'=>admin_url('admin.php?page=starboard-reviews'),'capability'=>'moderate_comments'];
        return $products;
    }
    public static function safe() { return ( defined('STARBOARD_UI_SAFE_MODE') && STARBOARD_UI_SAFE_MODE ) || ( isset($_GET['starboard-safe']) && '1' === $_GET['starboard-safe'] ); }
    public static function preference() {
        if ( self::safe() ) return 'light';
        $own = get_user_meta( get_current_user_id(), 'sr_appearance', true );
        $own = in_array( $own, ['light','dark','system'], true ) ? $own : 'light';
        $signal = apply_filters( 'starboard_appearance_v1', [] );
        return is_array($signal) && 1 === ($signal['contract']??0) && in_array($signal['preference']??'', ['light','dark','system'],true) ? $signal['preference'] : $own;
    }
    public static function theme_head() {
        if(!self::screen()) return;
        $mode=wp_json_encode(self::preference());
        echo '<script>document.documentElement.dataset.srTheme=('.$mode.'==="dark"||('.$mode.'==="system"&&window.matchMedia("(prefers-color-scheme: dark)").matches))?"dark":"light";</script>';
    }
    public static function assets() {
        if ( ! self::screen() ) return;
        wp_enqueue_style('sr-suite',SR_URL.'assets/suite.css',['sr-admin'],SR_VERSION);
        wp_enqueue_script('sr-suite',SR_URL.'assets/suite.js',[],SR_VERSION,true);
        wp_localize_script('sr-suite','srSuite',['preference'=>self::preference()]);
        if ( self::safe() ) return;
        $brand = apply_filters('starboard_brand_v1',[]);
        if ( is_array($brand) && 1 === ($brand['contract']??0) ) {
            $accent = sanitize_hex_color( is_string($brand['accent']??null) ? $brand['accent'] : '' );
            if($accent) wp_add_inline_style('sr-suite','.sr-wrap,.sr-modal,#sr-toast{--sr-admin-accent:'.$accent.';}');
        }
    }
    public static function profile( $user ) {
        if ( $user->ID !== get_current_user_id() ) return;
        $value = get_user_meta($user->ID,'sr_appearance',true) ?: 'light';
        echo '<h2>'.esc_html__('Starboard Reviews appearance','starboard-reviews').'</h2><p>'.esc_html__('Used when Starboard UI does not provide an appearance preference.','starboard-reviews').'</p><label for="sr-appearance">'.esc_html__('Appearance','starboard-reviews').'</label> <select id="sr-appearance" name="sr_appearance">';
        foreach(['light'=>__('Light','starboard-reviews'),'dark'=>__('Dark','starboard-reviews'),'system'=>__('Follow system','starboard-reviews')] as $key=>$label) echo '<option value="'.esc_attr($key).'" '.selected($value,$key,false).'>'.esc_html($label).'</option>';
        echo '</select>';
        wp_nonce_field('sr-appearance','sr_appearance_nonce');
    }
    public static function save_profile( $id ) {
        if ( get_current_user_id() !== (int)$id || !current_user_can('read') || !isset($_POST['sr_appearance_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['sr_appearance_nonce'])),'sr-appearance') ) return;
        $value=isset($_POST['sr_appearance']) && is_string($_POST['sr_appearance']) ? sanitize_key(wp_unslash($_POST['sr_appearance'])) : '';
        if(in_array($value,['light','dark','system'],true)) update_user_meta($id,'sr_appearance',$value);
    }
}
SR_Suite::boot();
