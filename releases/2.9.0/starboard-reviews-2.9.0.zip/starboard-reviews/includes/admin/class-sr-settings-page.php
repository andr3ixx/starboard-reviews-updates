<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SR_Settings_Page {

    public static function render() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.', '', [ 'response' => 403 ] );
        ?>
        <div class="sr-wrap">
            <?php SR_Brand::header( 'settings' ); ?>
            <div class="sr-top-bar">
                <div class="sr-title-group">
                    <p class="sr-eyebrow">STARBOARD REVIEWS</p><h1>Settings</h1><p class="sr-page-description">Make Starboard feel at home in your store.</p>
                </div>
            </div>

            <?php SR_Updater::panel(); ?>
            <form id="sr-general-form">
                <input type="hidden" name="sr_settings_group" value="general">
                <div class="sr-settings-grid">

                    <div class="sr-card">
                        <h3>General Logic</h3>

                        <div class="sr-toggle-row">
                            <label>Auto-Publish Reviews</label>
                            <input type="checkbox" name="sr_auto_publish" value="1" <?php checked( 1, get_option( 'sr_auto_publish' ) ); ?>>
                        </div>

                        <div style="margin-bottom: 20px; padding-left: 10px; border-left: 3px solid #f1f5f9;">
                            <label style="font-size: 14px; margin-bottom: 5px; display: block;">Minimum Rating to Auto-Publish</label>
                            <select name="sr_auto_publish_min" style="width: 100px;">
                                <?php
                                $current_min = get_option( 'sr_auto_publish_min', 4 );
                                for ( $i = 1; $i <= 5; $i++ ) {
                                    echo '<option value="' . $i . '" ' . selected( $current_min, $i, false ) . '>' . $i . ' Stars+</option>';
                                }
                                ?>
                            </select>
                        </div>

                        <div class="sr-toggle-row">
                            <label>Verified Buyers Only</label>
                            <input type="checkbox" name="sr_verified_only" value="1" <?php checked( 1, get_option( 'sr_verified_only' ) ); ?>>
                        </div>

                        <div style="margin-top: 20px; border-top: 1px solid #f1f5f9; padding-top: 15px;">
                            <label style="font-size: 14px; font-weight: 600; display: block; margin-bottom: 8px;">Exclude Products from Emails</label>

                            <input type="hidden" name="sr_excluded_products" id="sr-excluded-ids" value="<?php echo esc_attr( get_option( 'sr_excluded_products' ) ); ?>">

                            <div style="position: relative; margin-bottom: 10px;">
                                <input type="text" id="sr-prod-search" placeholder="Type product name..." autocomplete="off"
                                       style="width: 100%; padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px;">

                                <div id="sr-search-results" style="display: none; position: absolute; top: 100%; left: 0; right: 0;
                                     background: #fff; border: 1px solid #cbd5e1; border-radius: 0 0 6px 6px;
                                     box-shadow: 0 4px 6px rgba(0,0,0,0.1); z-index: 10; max-height: 200px; overflow-y: auto;">
                                </div>
                            </div>

                            <div id="sr-selected-list" style="display: flex; flex-wrap: wrap; gap: 8px;">
                                <?php
                                // Pre-load existing tags
                                $saved_ids = get_option( 'sr_excluded_products' );
                                if ( ! empty( $saved_ids ) ) {
                                    $ids = explode( ',', $saved_ids );
                                    foreach ( $ids as $id ) {
                                        $id = intval( trim( $id ) );
                                        if ( $id ) {
                                            $title = get_the_title( $id );
                                            if ( ! $title ) $title = 'Unknown Product';
                                            $short_title = strlen($title) > 25 ? substr($title, 0, 25) . '...' : $title;

                                            echo '<div class="sr-prod-tag" data-id="'.$id.'">
                                                    <span class="sr-tag-id">ID: '.$id.'</span>
                                                    <span class="sr-tag-name">'.esc_html( $short_title ).'</span>
                                                    <button type="button" class="sr-tag-remove" aria-label="Remove product"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button>
                                                  </div>';
                                        }
                                    }
                                }
                                ?>
                            </div>

                            <style>
                                .sr-prod-tag {
                                    background: #eff6ff; border: 1px solid #bfdbfe; color: #1e40af;
                                    border-radius: 4px; padding: 4px 8px; font-size: 14px;
                                    display: flex; align-items: center; gap: 6px; cursor: default;
                                }
                                .sr-tag-id { font-weight: 700; color: #2563eb; }
                                .sr-tag-remove {
                                    cursor: pointer; font-weight: bold; font-size: 14px; color: #93c5fd;
                                    margin-left: 4px; line-height: 1;
                                }
                                .sr-tag-remove:hover { color: #ef4444; }
                                .sr-search-item { padding: 8px 12px; cursor: pointer; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
                                .sr-search-item:hover { background: #f8fafc; color: #2563eb; }
                            </style>

                            <script>
                                jQuery(document).ready(function($){
                                    // 0. TOAST HELPER
                                    if ($('#sr-toast').length === 0) $('body').append('<div id="sr-toast"></div>');
                                    function showToast(message, isError = false) {
                                        var $t = $('#sr-toast'); $t.text(message);
                                        if (isError) $t.addClass('error'); else $t.removeClass('error');
                                        $t.addClass('show'); setTimeout(function(){ $t.removeClass('show'); }, 3000);
                                    }

                                    // 1. PRODUCT SEARCH
                                    var searchTimer;
                                    $('#sr-prod-search').on('keyup', function(){
                                        clearTimeout(searchTimer);
                                        var term = $(this).val();
                                        var resBox = $('#sr-search-results');
                                        if(term.length < 2) { resBox.hide(); return; }
                                        searchTimer = setTimeout(function(){
                                            $.ajax({
                                                url: ajaxurl,
                                                data: { action: 'sr_search_products', term: term, nonce: '<?php echo wp_create_nonce( "sr_admin_nonce" ); ?>' },
                                                success: function(res) {
                                                    if(res.success && res.data.length > 0) {
                                                        var html = '';
                                                        res.data.forEach(function(item){
                                                            html += '<div class="sr-search-item" data-id="'+item.id+'" data-html="'+item.text.replace(/"/g, '&quot;')+'">' + item.text + '</div>';
                                                        });
                                                        resBox.html(html).show();
                                                    } else { resBox.hide(); }
                                                }
                                            });
                                        }, 300);
                                    });
                                    $(document).on('click', '.sr-search-item', function(){
                                        var id = $(this).data('id');
                                        var rawText = $(this).html();
                                        var tempDiv = document.createElement("div"); tempDiv.innerHTML = rawText;
                                        var cleanText = tempDiv.textContent || tempDiv.innerText || "";
                                        var nameOnly = cleanText.replace(/\[ID: \d+\]\s*/, '');
                                        addTag(id, nameOnly);
                                        $('#sr-prod-search').val(''); $('#sr-search-results').hide();
                                    });
                                    $(document).on('click', '.sr-tag-remove', function(){
                                        $(this).closest('.sr-prod-tag').remove();
                                        updateHiddenInput();
                                    });
                                    function addTag(id, name) {
                                        var exists = false;
                                        $('.sr-prod-tag').each(function(){ if($(this).data('id') == id) exists = true; });
                                        if(exists) return;
                                        var html = `<div class="sr-prod-tag" data-id="${id}"><span class="sr-tag-id">ID: ${id}</span><span class="sr-tag-name">${$('<div>').text(name).html()}</span><button type="button" class="sr-tag-remove" aria-label="Remove product"><span class="sr-icon sr-icon-x" aria-hidden="true"></span></button></div>`;
                                        $('#sr-selected-list').append(html);
                                        updateHiddenInput();
                                    }
                                    function updateHiddenInput() {
                                        var ids = [];
                                        $('.sr-prod-tag').each(function(){ ids.push($(this).data('id')); });
                                        $('#sr-excluded-ids').val(ids.join(','));
                                    }
                                    $(document).click(function(e) {
                                        if (!$(e.target).closest('#sr-prod-search, #sr-search-results').length) { $('#sr-search-results').hide(); }
                                    });

                                    // 2. SHORTCODES
                                    $('#sc-pid').on('input', function(){
                                        var val = $(this).val();
                                        if(val) $('#sr-sc-output').val('[starboard_reviews product_id="' + val + '"]');
                                        else $('#sr-sc-output').val('[starboard_reviews]');
                                    });
                                    $('#sr-copy-sc').click(function(){ navigator.clipboard.writeText($('#sr-sc-output').val()); showToast('Copied!'); });

                                    function updateRatingSC() {
                                        var pid = $('#sc-rate-pid').val();
                                        var rate = $('#sc-rate-val').val();
                                        var count = $('#sc-rate-count').val();
                                        var showScore = $('#sc-show-score').is(':checked');
                                        var showCount = $('#sc-show-count').is(':checked');

                                        var parts = [];
                                        if(pid) parts.push('id="' + pid + '"');
                                        if(rate) parts.push('rating="' + rate + '"');
                                        if(count) parts.push('count="' + count + '"');

                                        // Only add parameters if they are FALSE (since true is default)
                                        if(showScore === false) parts.push('show_score="false"');
                                        if(showCount === false) parts.push('show_count="false"');

                                        var sc = '[starboard_rating ' + parts.join(' ') + ']';
                                        $('#sr-sc-rating-output').val(sc);
                                    }

                                    // Attach listeners
                                    $('#sc-rate-pid, #sc-rate-val, #sc-rate-count, #sc-show-score, #sc-show-count').on('input change', updateRatingSC);

                                    $('#sr-copy-sc-rating').click(function(){
                                        navigator.clipboard.writeText($('#sr-sc-rating-output').val());
                                        showToast('Rating shortcode copied!');
                                    });

                                });
                            </script>
                        </div>
                    </div>

                    <div class="sr-card">
                        <h3>Notifications</h3>
                        <p style="font-size: 14px; color: #64748b; margin-bottom: 15px;">Control who receives alerts for new reviews.</p>

                        <div style="margin-bottom: 15px;">
                            <label style="font-weight:600; display:block; margin-bottom:5px;">Admin Email Recipients</label>
                            <input type="text" name="sr_notification_email" value="<?php echo esc_attr( get_option( 'sr_notification_email' ) ); ?>" placeholder="e.g. admin@site.com, support@site.com" style="width:100%;">
                            <p style="font-size: 14px; color: #94a3b8; margin-top: 5px;">
                                Leave blank to use the site admin email (<code><?php echo esc_html( get_option('admin_email') ); ?></code>).<br>
                                Separate multiple emails with commas.
                            </p>
                        </div>
                    </div>

                    <div class="sr-card">
                        <h3>Colors & Branding</h3>
                        <label for="sr-front-font">Front-end font</label>
                        <select id="sr-front-font" name="sr_front_font">
                            <option value="site" <?php selected(get_option('sr_front_font','site'),'site'); ?>>Use the site font (default)</option>
                            <option value="starboard" <?php selected(get_option('sr_front_font','site'),'starboard'); ?>>Use the Starboard font</option>
                        </select>
                        <p class="sr-field-help">Applies to product reviews, showcases and inline ratings. Each widget can override this. Admin screens use the configured WordPress body font, with the Starboard font as a fallback.</p>

                        <div style="margin-bottom: 20px;">
                            <label>Admin Accent Color</label>
                            <div style="display: flex; gap: 15px; align-items: center;">
                                <input type="color" name="sr_color_admin" value="<?php echo esc_attr( get_option( 'sr_color_admin', '#2563eb' ) ); ?>" style="height: 40px; width: 60px; padding: 0; border: none; cursor: pointer;">
                                <code style="font-size: 14px; color: #64748b;">Buttons & Links in Dashboard</code>
                            </div>
                        </div>

                        <div style="margin-bottom: 20px;">
                            <label>Widget Accent Color</label>
                            <div style="display: flex; gap: 15px; align-items: center;">
                                <input type="color" name="sr_color_widget" value="<?php echo esc_attr( get_option( 'sr_color_widget', '#2563eb' ) ); ?>" style="height: 40px; width: 60px; padding: 0; border: none; cursor: pointer;">
                                <code style="font-size: 14px; color: #64748b;">"Write Review" Button & Links</code>
                            </div>
                        </div>

                        <div style="margin-bottom: 10px;">
                            <label>Star Rating Color</label>
                            <div style="display: flex; gap: 15px; align-items: center;">
                                <input type="color" name="sr_color_star" value="<?php echo esc_attr( get_option( 'sr_color_star', '#fbbf24' ) ); ?>" style="height: 40px; width: 60px; padding: 0; border: none; cursor: pointer;">
                                <code style="font-size: 14px; color: #64748b;">Star Icons (Admin & Front)</code>
                            </div>
                        </div>
                    </div>

                    <div class="sr-card">
                        <h3>Widget Shortcode</h3>
                        <p style="font-size: 14px; color: #64748b; margin-bottom: 15px;">Use this to display reviews on any page.</p>

                        <label>Product ID (Optional)</label>
                        <input type="text" id="sc-pid" class="sr-sc-opt" placeholder="Leave empty to auto-detect" style="margin-bottom: 15px;">

                        <div style="background: #f8fafc; padding: 15px; border: 1px solid #e2e8f0; border-radius: 6px; display: flex; gap: 10px; align-items: center;">
                            <input type="text" id="sr-sc-output" value='[starboard_reviews]' readonly style="border: none; background: transparent; font-family: monospace; font-size: 14px; color: #334155; width: 100%;">
                            <button type="button" id="sr-copy-sc" class="sr-btn blue sm">Copy</button>
                        </div>
                    </div>

                    <div class="sr-card">
                        <h3>Inline Rating Shortcode</h3>
                        <p style="font-size: 14px; color: #64748b; margin-bottom: 15px;">Displays just stars + review count (e.g. for landing pages).</p>

                        <div class="sr-grid-2" style="margin-bottom:10px;">
                            <div>
                                <label>Product ID</label>
                                <input type="text" id="sc-rate-pid" placeholder="e.g. 123" style="width:100%;">
                            </div>
                            <div>
                                <label>Options</label>
                                <div style="display:flex; gap:15px; padding-top:8px;">
                                    <label style="display:flex; align-items:center; gap:5px; font-weight:400;">
                                        <input type="checkbox" id="sc-show-score" checked> Show Score
                                    </label>
                                    <label style="display:flex; align-items:center; gap:5px; font-weight:400;">
                                        <input type="checkbox" id="sc-show-count" checked> Show Count
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div style="margin-bottom:15px; border-top:1px solid #f1f5f9; padding-top:10px;">
                            <label style="color:#94a3b8; font-size: 14px;">Manual Overrides (Optional)</label>
                            <div style="display:flex; gap:10px;">
                                <input type="text" id="sc-rate-val" placeholder="Rating (e.g. 4.8)">
                                <input type="text" id="sc-rate-count" placeholder="Count (e.g. 500)">
                            </div>
                        </div>

                        <div style="background: #f8fafc; padding: 15px; border: 1px solid #e2e8f0; border-radius: 6px; display: flex; gap: 10px; align-items: center;">
                            <input type="text" id="sr-sc-rating-output" value='[starboard_rating]' readonly style="border: none; background: transparent; font-family: monospace; font-size: 14px; color: #334155; width: 100%;">
                            <button type="button" id="sr-copy-sc-rating" class="sr-btn blue sm">Copy</button>
                        </div>
                    </div>

                </div>

                <div class="sr-sticky-foot">
                    <button class="sr-btn blue" id="sr-save-gen-btn">Save Changes</button>
                </div>
            </form>
        </div>
        <?php
    }
}
