/* Preferences are persisted per account; system appearance stays a browser decision. */
(()=>{'use strict';const c=window.sbuiTheme;if(!c)return;
const media=window.matchMedia('(prefers-color-scheme: dark)');let preference=c.mode;
function apply(mode){preference=mode;const dark=mode==='dark'||(mode==='system'&&media.matches);document.body.classList.remove('sbui-mode-light','sbui-mode-dark','sbui-mode-system');document.body.classList.add('sbui-mode-'+mode);document.documentElement.dataset.starboardTheme=dark?'dark':'light';
 document.querySelectorAll('[data-light][data-dark]').forEach(img=>{img.src=dark?img.dataset.dark:img.dataset.light;});
 const logo=document.querySelector('.sbui-sidebar-logo img');if(logo)logo.src=dark?(c.logoDark||c.logo):(c.logo||c.logoDark);
 document.querySelectorAll('[id^="wp-admin-bar-starboard-mode-"] a').forEach(a=>{a.setAttribute('aria-current',a.hash==='#starboard-mode-'+mode?'true':'false');});
 window.dispatchEvent(new CustomEvent('starboard:appearance',{detail:{preference:mode,effective:dark?'dark':'light'}}));}
if(c.logo||c.logoDark){const wrap=document.getElementById('adminmenuwrap');if(wrap){const div=document.createElement('div'),img=document.createElement('img');div.className='sbui-sidebar-logo';img.alt='';div.append(img);wrap.prepend(div);}}
document.querySelectorAll('#adminmenu .sbui-group-row a').forEach(a=>{a.removeAttribute('href');a.tabIndex=-1;});
const status=document.createElement('span');status.className='screen-reader-text';status.setAttribute('role','status');document.body.append(status);
let saving=false;document.addEventListener('click',async e=>{const a=e.target.closest('[id^="wp-admin-bar-starboard-mode-"] a');if(!a)return;e.preventDefault();if(saving)return;const mode=a.hash.replace('#starboard-mode-','');if(!['light','dark','system'].includes(mode))return;const previous=preference;saving=true;apply(mode);try{const r=await fetch(c.endpoint,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-WP-Nonce':c.nonce},body:JSON.stringify({mode})});if(!r.ok)throw Error();status.textContent=c.saved;}catch{apply(previous);status.textContent=c.failed;window.alert(c.failed);}finally{saving=false;}});
if(media.addEventListener)media.addEventListener('change',()=>apply(preference));else media.addListener(()=>apply(preference));apply(preference);
})();
