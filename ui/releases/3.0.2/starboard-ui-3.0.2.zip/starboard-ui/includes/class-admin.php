<?php
namespace Starboard\UI;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Admin {
    private static $owns_root=false;
    public function __construct() {
        add_action('admin_menu',[$this,'menu'],20);
        add_filter('parent_file',[$this,'parent_file']);
        add_filter('submenu_file',[$this,'submenu_file']);
        add_action('admin_init',[$this,'redirect_legacy']);
        add_action('admin_enqueue_scripts',[$this,'assets']);
        add_action('admin_post_sbui_save',[$this,'save']);
        add_action('admin_post_sbui_export',[$this,'export']);
        add_action('wp_ajax_sbui_import_preview',[$this,'import_preview']);
    }
    public function menu(){
        if(!current_user_can('manage_options')){return;}
        global $menu;
        $exists=false;
        foreach((array)$menu as $item){if('starboard'===$item[2]){$exists=true;break;}}
        if(!$exists){self::$owns_root=true;add_menu_page('Starboard','Starboard','read','starboard',[$this,'render'],'data:image/svg+xml;base64,'.base64_encode(file_get_contents(SBUI_PATH.'assets/starboard-menu.svg')),56);}
        add_submenu_page('starboard',__('Starboard UI','starboard-ui'),'UI','manage_options','starboard-ui',[$this,'render']);
        remove_submenu_page('starboard','starboard');
    }
    public static function screen(){
        $screen=get_current_screen();
        if(!$screen){return false;}
        // The shared root belongs to Reviews when Reviews has registered it.
        return in_array($screen->id,['starboard_page_starboard-ui','toplevel_page_starboard-ui'],true)
            || ('toplevel_page_starboard'===$screen->id && self::$owns_root);
    }
    public function parent_file($parent){return self::screen()?'starboard':$parent;}
    public function submenu_file($submenu){return self::screen()?'starboard-ui':$submenu;}
    public function redirect_legacy(){if(isset($_GET['page'])&&'modern-admin'===$_GET['page']&&current_user_can('manage_options')){wp_safe_redirect(admin_url('admin.php?page=starboard-ui'));exit;}}
    public function assets($hook){
        if(!self::screen()){return;}
        wp_enqueue_media();
        wp_enqueue_style('sbui-admin',SBUI_URL.'assets/admin.css',[],SBUI_VERSION);
        wp_enqueue_script('sbui-admin',SBUI_URL.'assets/admin.js',['jquery','jquery-ui-sortable'],SBUI_VERSION,true);
        wp_localize_script('sbui-admin','sbuiAdmin',[
            'defaults'=>Settings::defaults(),'current'=>Settings::get(),'ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('sbui-import'),
            'messages'=>['dirty'=>__('Unsaved changes','starboard-ui'),'saved'=>__('All changes saved','starboard-ui'),'reset'=>__('Section reset. Save changes to apply.','starboard-ui'),'move'=>__('Menu order updated. Save changes to apply.','starboard-ui'),'import'=>__('Import preview ready. Review the changes below before applying.','starboard-ui'),'error'=>__('Could not read this import. Please try again.','starboard-ui'),'leave'=>__('You have unsaved Starboard UI changes.','starboard-ui'),'saving'=>__('Saving…','starboard-ui'),'group'=>__('Group label','starboard-ui'),'up'=>__('Up','starboard-ui'),'down'=>__('Down','starboard-ui'),'remove'=>__('Remove','starboard-ui'),'noChanges'=>__('No changes.','starboard-ui'),'tooLarge'=>__('Import is too large (maximum 256 KB).','starboard-ui'),'choose'=>__('Choose image','starboard-ui'),'use'=>__('Use image','starboard-ui')]
        ]);
    }
    private function guard($action){if(!current_user_can('manage_options')){wp_die(esc_html__('You cannot manage these settings.','starboard-ui'),'', ['response'=>403]);}check_admin_referer($action);}
    public function save(){
        $this->guard('sbui-save');
        $old=Settings::get();
        $import=isset($_POST['sbui_import'])?Settings::scalar(wp_unslash($_POST['sbui_import'])):'';
        $new=$import!==''?Settings::decode($import,$old):Settings::clean(isset($_POST['sbui'])?wp_unslash($_POST['sbui']):[],$old);
        if(is_wp_error($new)){wp_die(esc_html($new->get_error_message()),'', ['back_link'=>true,'response'=>400]);}
        update_option('starboard_ui_previous_settings',$old,false);
        update_option(Settings::OPTION,$new,false);
        wp_safe_redirect(admin_url('admin.php?page=starboard-ui&saved=1'));exit;
    }
    public function export(){
        $this->guard('sbui-export');nocache_headers();
        header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="starboard-ui-settings.json"');
        echo wp_json_encode(Settings::get(),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES);exit;
    }
    public function import_preview(){
        if(!current_user_can('manage_options')){wp_send_json_error(['message'=>__('Permission denied.','starboard-ui')],403);}
        check_ajax_referer('sbui-import','nonce');
        $new=Settings::decode(Settings::scalar(wp_unslash($_POST['json']??'')),Settings::get());
        if(is_wp_error($new)){wp_send_json_error(['message'=>$new->get_error_message()],400);}
        $old=Settings::get();$diff=[];
        foreach($new as $section=>$fields){if(!is_array($fields)){continue;}foreach($fields as $key=>$value){if($value!==$old[$section][$key]){$diff[]=['field'=>$section.'.'.$key,'before'=>$old[$section][$key],'after'=>$value];}}}
        wp_send_json_success(['settings'=>$new,'changes'=>$diff]);
    }
    private function field($section,$key,$label,$type='text',$help=''){
        $s=Settings::get();$value=$s[$section][$key];$id='sbui-'.$section.'-'.$key;$name='sbui['.$section.']['.$key.']';
        echo '<div class="sbui-field"><label for="'.esc_attr($id).'">'.esc_html($label).'</label>';
        $attrs=' id="'.esc_attr($id).'" name="'.esc_attr($name).'"'.($help?' aria-describedby="'.esc_attr($id).'-help"':'');
        if('checkbox'===$type){echo '<input type="hidden" name="'.esc_attr($name).'" value="0"><input type="checkbox"'.$attrs.' value="1" '.checked($value,true,false).'>';}
        elseif('textarea'===$type){echo '<textarea'.$attrs.' rows="5">'.esc_textarea($value).'</textarea>';}
        elseif(is_array($type)){echo '<select'.$attrs.'>';foreach($type as $v=>$text){echo '<option value="'.esc_attr($v).'" '.selected($value,$v,false).'>'.esc_html($text).'</option>';}echo '</select>';}
        else{echo '<div class="sbui-input-row"><input type="'.esc_attr('image'===$type?'url':$type).'"'.$attrs.' value="'.esc_attr($value).'"'.('number'===$type?' min="0" max="'.('overlay'===$key?'90':'40').'"':'').'>';if('image'===$type){echo '<button type="button" class="sbui-button" data-media="'.esc_attr($id).'">'.esc_html__('Choose image','starboard-ui').'</button>';}echo '</div>';}
        if($help){echo '<p id="'.esc_attr($id).'-help" class="sbui-help">'.esc_html($help).'</p>';}
        echo '</div>';
    }
    private function start($id,$title,$description){echo '<section class="sbui-panel" id="sbui-section-'.esc_attr($id).'" data-section="'.esc_attr($id).'"><div class="sbui-panel-heading"><div><h2>'.esc_html($title).'</h2><p>'.esc_html($description).'</p></div><button type="button" class="sbui-text-button" data-reset="'.esc_attr($id).'">'.esc_html__('Reset section','starboard-ui').'</button></div>';}
    private function end(){echo '</section>';}
    private function products(){
        return array_filter((array)apply_filters('starboard_products_v1',[]),function($product){
            return is_array($product) && 1===($product['contract']??0) && is_string($product['id']??null)
                && is_string($product['label']??null) && is_string($product['home_url']??null)
                && is_string($product['capability']??null) && current_user_can($product['capability']);
        });
    }
    public function render(){
        if(!current_user_can('manage_options')){return;}
        $s=Settings::get();$sections=['branding'=>__('Branding','starboard-ui'),'appearance'=>__('Appearance','starboard-ui'),'login'=>__('Login designer','starboard-ui'),'navigation'=>__('Navigation','starboard-ui'),'dashboard'=>__('Client dashboard','starboard-ui'),'toolbar'=>__('Toolbar','starboard-ui'),'advanced'=>__('Advanced','starboard-ui')];
        ?>
        <div class="wrap sbui-wrap">
            <header class="sbui-masthead"><a class="sbui-brand" href="<?php echo esc_url(admin_url('admin.php?page=starboard-ui')); ?>"><img src="<?php echo esc_url(SBUI_URL.'assets/starboard-lockup.svg'); ?>" data-light="<?php echo esc_url(SBUI_URL.'assets/starboard-lockup.svg'); ?>" data-dark="<?php echo esc_url(SBUI_URL.'assets/starboard-lockup-reverse.svg'); ?>" width="174" height="50" alt="Starboard"><span>UI</span></a><nav aria-label="<?php esc_attr_e('Starboard products','starboard-ui'); ?>"><?php foreach($this->products() as $product){if(!is_array($product)||empty($product['capability'])||!current_user_can($product['capability'])){continue;}echo '<a href="'.esc_url($product['home_url']??'').'"'.(('ui'===($product['id']??''))?' aria-current="page"':'').'>'.esc_html($product['label']??'').'</a>';} ?></nav><button type="button" class="sbui-button" id="sbui-command-open" aria-haspopup="dialog"><?php esc_html_e('Jump to…','starboard-ui'); ?></button><span class="sbui-version">3.0</span></header>
            <div class="sbui-page-heading"><div><p class="sbui-eyebrow"><?php esc_html_e('YOUR WORKSPACE, YOUR WAY','starboard-ui'); ?></p><h1><?php esc_html_e('Make yourself at home.','starboard-ui'); ?></h1><p><?php esc_html_e('A familiar WordPress workspace, with your finishing touches.','starboard-ui'); ?></p></div><a class="sbui-button" href="<?php echo esc_url(add_query_arg(['starboard-safe'=>'1'],admin_url('admin.php?page=starboard-ui'))); ?>"><?php esc_html_e('Open safe mode','starboard-ui'); ?></a></div>
            <?php if(Runtime::safe()){echo '<div class="notice notice-warning"><p>'.esc_html__('Safe mode is active. Custom appearance, menus and dashboard changes are bypassed for this request.','starboard-ui').' <a href="'.esc_url(admin_url('admin.php?page=starboard-ui')).'">'.esc_html__('Exit safe mode','starboard-ui').'</a></p></div>';} ?>
            <?php if(isset($_GET['saved'])){echo '<div class="notice notice-success"><p>'.esc_html__('Settings saved.','starboard-ui').'</p></div>';} ?>
            <?php if(is_array(get_option('modern_admin_settings',false))){echo '<p class="sbui-migration-note">'.esc_html__('Your previous configuration has been migrated. The original 2.0 settings are retained for rollback; later changes do not sync back.','starboard-ui').'</p>';} ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="sbui-form">
                <input type="hidden" name="action" value="sbui_save"><?php wp_nonce_field('sbui-save'); ?>
                <div class="sbui-layout"><nav class="sbui-section-nav" aria-label="<?php esc_attr_e('Settings sections','starboard-ui'); ?>"><?php foreach($sections as $id=>$label){echo '<a href="#sbui-section-'.esc_attr($id).'">'.esc_html($label).'</a>';} ?><a href="#sbui-section-transfer"><?php esc_html_e('Import & export','starboard-ui'); ?></a></nav><div class="sbui-panels">
                <?php
                $this->start('branding',__('A recognizable workspace','starboard-ui'),__('Keep your identity consistent across the admin and Starboard products.','starboard-ui'));
                $this->field('branding','accent',__('Accent color','starboard-ui'),'color');
                $this->field('branding','logo',__('Sidebar logo · light','starboard-ui'),'image');
                $this->field('branding','logo_dark',__('Sidebar logo · dark','starboard-ui'),'image',__('Optional. Uses the light logo when empty.','starboard-ui'));
                $this->field('branding','footer',__('Footer credit','starboard-ui'));
                $this->field('branding','menu_style',__('Use Starboard menu styling','starboard-ui'),'checkbox',__('Keeps WordPress menu widths, collapse behavior and mobile navigation.','starboard-ui'));$this->end();
                $this->start('appearance',__('Comfort in every light','starboard-ui'),__('Choose a default, then let each person make it their own.','starboard-ui'));
                $modes=['light'=>__('Light','starboard-ui'),'dark'=>__('Dark','starboard-ui'),'system'=>__('Follow system','starboard-ui')];
                $this->field('appearance','default',__('Site default','starboard-ui'),$modes);
                $this->field('appearance','allow_user',__('Let users choose their appearance','starboard-ui'),'checkbox');
                $this->field('appearance','lock',__('Enforced appearance','starboard-ui'),array_merge([''=>__('No enforced mode','starboard-ui')],$modes),__('An enforced mode takes priority over individual preferences.','starboard-ui'));
                echo '<div class="sbui-callout">'.esc_html__('Dark styling covers supported core screens and Starboard UI. Other plugins keep a light content area unless explicitly opted in. Editor canvases are excluded.','starboard-ui').'</div>';
                echo '<label for="sbui-screens">'.esc_html__('Additional screen IDs (one per line)','starboard-ui').'</label><textarea id="sbui-screens" data-lines="appearance.screens" rows="3">'.esc_textarea(implode("\n",$s['appearance']['screens'])).'</textarea><div data-list-fields="appearance.screens">';foreach($s['appearance']['screens'] as $screen){echo '<input type="hidden" name="sbui[appearance][screens][]" value="'.esc_attr($screen).'">';}echo '</div>';$this->end();
                $this->start('login',__('A warm welcome','starboard-ui'),__('Style the real WordPress login page. Preview changes before you save.','starboard-ui'));
                $this->field('login','enabled',__('Enable login styling','starboard-ui'),'checkbox');
                echo '<div class="sbui-presets"><span>'.esc_html__('Start with a preset','starboard-ui').'</span>';foreach(['harbor'=>__('Harbor','starboard-ui'),'midnight'=>__('Midnight','starboard-ui'),'paper'=>__('Paper','starboard-ui')] as $id=>$label){echo '<button type="button" class="sbui-button" data-preset="'.esc_attr($id).'">'.esc_html($label).'</button>';}echo '</div>';
                $this->field('login','logo',__('Login logo · light','starboard-ui'),'image');$this->field('login','logo_dark',__('Login logo · dark background','starboard-ui'),'image');
                $this->field('login','background',__('Background image','starboard-ui'),'image');
                $this->field('login','background_color',__('Background color','starboard-ui'),'color');$this->field('login','form_color',__('Form color','starboard-ui'),'color');
                $this->field('login','radius',__('Corner radius (0–40 px)','starboard-ui'),'number');$this->field('login','overlay',__('Image overlay (0–90%)','starboard-ui'),'number');
                $this->field('login','layout',__('Form placement','starboard-ui'),['center'=>__('Center','starboard-ui'),'left'=>__('Left','starboard-ui'),'right'=>__('Right','starboard-ui')]);
                $preview=add_query_arg(['sbui-preview'=>'1','_wpnonce'=>wp_create_nonce('sbui-preview')],wp_login_url(''));
                echo '<div class="sbui-preview-toolbar"><strong>'.esc_html__('Live login preview','starboard-ui').'</strong><button type="button" class="sbui-button" id="sbui-preview-size" aria-pressed="false">'.esc_html__('Mobile preview','starboard-ui').'</button></div><iframe id="sbui-login-preview" title="'.esc_attr__('Login appearance preview','starboard-ui').'" src="'.esc_url($preview).'" sandbox="allow-scripts allow-same-origin"></iframe><p class="sbui-help">'.esc_html__('Preview only; sign-in is disabled here. If another plugin moves or blocks the login page, use the standalone login page after saving.','starboard-ui').'</p>';$this->end();
                $this->start('navigation',__('Everything in its place','starboard-ui'),__('Drag menu items or use Move up and Move down. Hiding a menu never blocks access to its page.','starboard-ui'));
                $this->navigation($s);$this->end();
                $this->start('dashboard',__('A useful starting point','starboard-ui'),__('Welcome your team with the links and support they need.','starboard-ui'));
                $this->field('dashboard','enabled',__('Show welcome panel','starboard-ui'),'checkbox');$this->field('dashboard','title',__('Panel title','starboard-ui'));$this->field('dashboard','html',__('Welcome content (basic HTML)','starboard-ui'),'textarea');$this->field('dashboard','support_label',__('Support link label','starboard-ui'));$this->field('dashboard','support_url',__('Support URL','starboard-ui'),'url');
                for($i=0;$i<4;$i++){echo '<div class="sbui-link-row"><label>'.esc_html(sprintf(__('Quick link %d label','starboard-ui'),$i+1)).'<input name="sbui[dashboard][links]['.$i.'][label]" value="'.esc_attr($s['dashboard']['links'][$i]['label']??'').'"></label><label>'.esc_html__('URL','starboard-ui').'<input type="url" name="sbui[dashboard][links]['.$i.'][url]" value="'.esc_attr($s['dashboard']['links'][$i]['url']??'').'"></label></div>';}
                echo '<fieldset><legend>'.esc_html__('Hide selected core widgets','starboard-ui').'</legend>';foreach(['dashboard_activity'=>__('Activity','starboard-ui'),'dashboard_right_now'=>__('At a glance','starboard-ui'),'dashboard_quick_press'=>__('Quick draft','starboard-ui'),'dashboard_primary'=>__('WordPress events and news','starboard-ui'),'dashboard_site_health'=>__('Site health','starboard-ui')] as $id=>$label){echo '<label class="sbui-check"><input type="checkbox" name="sbui[dashboard][hide_widgets][]" value="'.esc_attr($id).'" '.checked(in_array($id,$s['dashboard']['hide_widgets'],true),true,false).'>'.esc_html($label).'</label>';}echo '</fieldset>';$this->end();
                $this->start('toolbar',__('A little less clutter','starboard-ui'),__('Choose which toolbar items to hide. No permissions are changed.','starboard-ui'));
                foreach(['hide_logo'=>__('Hide WordPress logo','starboard-ui'),'hide_updates'=>__('Hide updates shortcut','starboard-ui'),'hide_comments'=>__('Hide comments shortcut','starboard-ui'),'hide_new'=>__('Hide New menu','starboard-ui')] as $key=>$label){$this->field('toolbar',$key,$label,'checkbox');}$this->end();
                $this->start('advanced',__('Advanced controls','starboard-ui'),__('Custom CSS applies throughout the admin. Safe mode always bypasses it.','starboard-ui'));
                if(current_user_can('edit_css')||current_user_can('unfiltered_html')){$this->field('advanced','css',__('Custom admin CSS','starboard-ui'),'textarea');}else{echo '<p>'.esc_html__('Custom CSS requires the edit_css or unfiltered_html capability.','starboard-ui').'</p>';}
                Updater::panel();
                echo '<p>'.esc_html__('For recovery, add STARBOARD_UI_SAFE_MODE to wp-config.php or use wp starboard-ui reset. Deactivation keeps your settings.','starboard-ui').'</p>';$this->end();
                ?>
                <section class="sbui-panel" id="sbui-section-transfer"><h2><?php esc_html_e('Take your setup with you','starboard-ui'); ?></h2><p><?php esc_html_e('Exports contain settings and image URLs. When moving sites, choose local replacement images. User preferences are not exported.','starboard-ui'); ?></p><a class="sbui-button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=sbui_export'),'sbui-export')); ?>"><?php esc_html_e('Export settings','starboard-ui'); ?></a><div class="sbui-field"><label for="sbui-import-file"><?php esc_html_e('Import a settings file','starboard-ui'); ?></label><input type="file" id="sbui-import-file" accept=".json,application/json"></div><div id="sbui-import-review" hidden><h3><?php esc_html_e('Review changes','starboard-ui'); ?></h3><p><?php esc_html_e('Applying replaces all sections. Custom CSS is retained when you lack permission to change it.','starboard-ui'); ?></p><div id="sbui-import-diff"></div><button type="button" class="sbui-button" id="sbui-import-apply"><?php esc_html_e('Apply import and save','starboard-ui'); ?></button><button type="button" class="sbui-text-button" id="sbui-import-cancel"><?php esc_html_e('Cancel import','starboard-ui'); ?></button></div></section>
                </div></div><div class="sbui-savebar"><span id="sbui-status" role="status" aria-live="polite"><?php esc_html_e('All changes saved','starboard-ui'); ?></span><button type="submit" class="sbui-button sbui-primary"><?php esc_html_e('Save changes','starboard-ui'); ?></button></div>
            </form>
            <dialog id="sbui-command" aria-labelledby="sbui-command-title"><div class="sbui-preview-toolbar"><h2 id="sbui-command-title"><?php esc_html_e('Quick navigation','starboard-ui'); ?></h2><button type="button" class="sbui-button" id="sbui-command-close"><?php esc_html_e('Close','starboard-ui'); ?></button></div><label for="sbui-command-search"><?php esc_html_e('Find a page','starboard-ui'); ?></label><input type="search" id="sbui-command-search" autocomplete="off"><nav aria-label="<?php esc_attr_e('Quick navigation results','starboard-ui'); ?>"><?php foreach($sections as $id=>$label){echo '<a data-jump-section="'.esc_attr($id).'" href="#sbui-section-'.esc_attr($id).'">'.esc_html($label).'</a>';}foreach($this->products() as $product){if(is_array($product)&&!empty($product['capability'])&&current_user_can($product['capability']))echo '<a href="'.esc_url($product['home_url']??'').'">Starboard '.esc_html($product['label']??'').'</a>';} ?></nav></dialog>
        </div>
        <?php
    }
    private function navigation($s){
        global $menu,$submenu;
        $items=[];foreach($menu as $item){$items[$item[2]]=$item;}
        $order=array_unique(array_merge($s['navigation']['order'],array_keys($items)));
        echo '<button type="button" class="sbui-button" id="sbui-add-group">'.esc_html__('Add group label','starboard-ui').'</button><ul id="sbui-menu-list">';
        foreach($order as $slug){
            if(!isset($items[$slug])){continue;}$item=$items[$slug];$group=isset($s['navigation']['labels'][$slug])||strpos($slug,'separator')===0;
            $title=trim(wp_strip_all_tags(preg_replace('/<span[^>]*class="[^"]*(?:count|awaiting-mod)[^"]*"[^>]*>.*?<\/span>/is','',$item[0])));
            if(!$title&&!$group){continue;}
            echo '<li class="sbui-menu-item" data-slug="'.esc_attr($slug).'"><div class="sbui-menu-row"><span class="sbui-drag" aria-hidden="true">⠿</span><input type="hidden" name="sbui[navigation][order][]" value="'.esc_attr($slug).'">';
            if($group){if(strpos($slug,'custom-sep-')===0){echo '<button type="button" class="sbui-text-button" data-remove-group>'.esc_html__('Remove group','starboard-ui').'</button>';}echo '<label>'.esc_html__('Group label','starboard-ui').'<input name="sbui[navigation][labels]['.esc_attr($slug).']" value="'.esc_attr($s['navigation']['labels'][$slug]??'').'"></label>';}else{echo '<strong>'.esc_html($title).'</strong>';if($s['navigation']['order']&&!in_array($slug,$s['navigation']['order'],true)){echo '<span class="sbui-new">'.esc_html__('New','starboard-ui').'</span>';}}
            echo '<div class="sbui-move"><button type="button" class="sbui-button" data-move="up" aria-label="'.esc_attr(sprintf(__('Move %s up','starboard-ui'),$title?:$slug)).'">'.esc_html__('Up','starboard-ui').'</button><button type="button" class="sbui-button" data-move="down" aria-label="'.esc_attr(sprintf(__('Move %s down','starboard-ui'),$title?:$slug)).'">'.esc_html__('Down','starboard-ui').'</button></div></div>';
            if(!$group&&!in_array($slug,['starboard','starboard-ui','modern-admin'],true)){
                echo '<details><summary>'.esc_html__('Menu visibility by role','starboard-ui').'</summary><p class="sbui-help">'.esc_html__('Checked roles will not see this menu. Administrators always retain access.','starboard-ui').'</p>';
                $this->role_checks($slug,$s);
                foreach($submenu[$slug]??[] as $child){if(empty($child[0])){continue;}echo '<div class="sbui-submenu"><strong>'.esc_html(wp_strip_all_tags($child[0])).'</strong>';$this->role_checks($slug.'::'.$child[2],$s);echo '</div>';}
                echo '</details>';
            }
            echo '</li>';
        }
        echo '</ul>';
        // Preserve rules for menus temporarily absent from this installation.
        $visible=[]; foreach($items as $parent=>$item){$visible[]=$parent;foreach($submenu[$parent]??[] as $child){$visible[]=$parent.'::'.$child[2];}}
        foreach($s['navigation']['hidden'] as $role=>$slugs){foreach(array_diff($slugs,$visible) as $slug){echo '<input type="hidden" name="sbui[navigation][hidden]['.esc_attr($role).'][]" value="'.esc_attr($slug).'">';}}
        // Preserve original non-admin rules until explicitly cleared; no role guessing.
        foreach($s['navigation']['legacy_hidden'] as $slug){echo '<label class="sbui-check"><input type="checkbox" name="sbui[navigation][legacy_hidden][]" value="'.esc_attr($slug).'" checked> '.esc_html(sprintf(__('Legacy: hide %s from all non-admin users','starboard-ui'),$slug)).'</label>';}
    }
    private function role_checks($slug,$s){foreach(wp_roles()->roles as $role=>$data){if('administrator'===$role){continue;}echo '<label class="sbui-check"><input type="checkbox" name="sbui[navigation][hidden]['.esc_attr($role).'][]" value="'.esc_attr($slug).'" '.checked(in_array($slug,$s['navigation']['hidden'][$role]??[],true),true,false).'>'.esc_html(translate_user_role($data['name'])).'</label>';}}
}
