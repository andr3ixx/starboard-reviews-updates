<?php
namespace Starboard\UI;
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Runtime {
    public function __construct() {
        add_filter( 'starboard_products_v1', [$this,'product'] );
        add_filter( 'starboard_brand_v1', [$this,'brand'] );
        add_filter( 'starboard_appearance_v1', [$this,'appearance'] );
        add_action( 'admin_enqueue_scripts', [$this,'assets'], 30 );
        add_filter( 'admin_body_class', [$this,'body'] );
        add_action( 'admin_bar_menu', [$this,'toolbar'], 999 );
        add_action( 'rest_api_init', [$this,'routes'] );
        add_filter( 'admin_footer_text', [$this,'footer'] );
        add_action( 'admin_menu', [$this,'menus'], 9999 );
        add_filter( 'custom_menu_order', '__return_true' );
        add_filter( 'menu_order', [$this,'order'] );
        add_action( 'wp_dashboard_setup', [$this,'dashboard'], 100 );
        add_action( 'login_enqueue_scripts', [$this,'login'] );
        add_filter( 'login_headerurl', [$this,'login_url'] );
        add_filter( 'login_headertext', [$this,'login_text'] );
        add_action( 'login_init', [$this,'preview_headers'] );
    }
    public static function safe() {
        return ( defined( 'STARBOARD_UI_SAFE_MODE' ) && STARBOARD_UI_SAFE_MODE ) || ( isset( $_GET['starboard-safe'] ) && '1' === $_GET['starboard-safe'] );
    }
    public function product( $products ) {
        $products = is_array( $products ) ? $products : [];
        if ( current_user_can( 'manage_options' ) ) { $products['ui'] = ['id'=>'ui','label'=>'UI','version'=>SBUI_VERSION,'contract'=>1,'home_url'=>admin_url('admin.php?page=starboard-ui'),'capability'=>'manage_options']; }
        return $products;
    }
    public function brand( $fallback ) {
        if ( self::safe() ) { return $fallback; }
        $b = Settings::get()['branding'];
        return ['contract'=>1,'accent'=>$b['accent'],'logo_light'=>$b['logo'],'logo_dark'=>$b['logo_dark']];
    }
    public static function mode() {
        if ( self::safe() ) { return 'light'; }
        $a = Settings::get()['appearance'];
        if ( $a['lock'] ) { return $a['lock']; }
        $user = get_user_meta( get_current_user_id(), 'starboard_ui_mode', true );
        return $a['allow_user'] && in_array( $user, ['light','dark','system'], true ) ? $user : $a['default'];
    }
    public function appearance( $fallback ) { return self::safe() ? $fallback : ['contract'=>1,'preference'=>self::mode()]; }
    public static function content_supported() {
        $screen = get_current_screen();
        if ( ! $screen || ( method_exists( $screen, 'is_block_editor' ) && $screen->is_block_editor() ) || in_array( $screen->base, ['customize','site-editor','post'], true ) ) { return false; }
        $core = ['dashboard','edit','edit-tags','term','upload','media','users','user','profile','plugins','plugin-install','themes','theme-install','options-general','options-writing','options-reading','options-discussion','options-media','options-permalink','options-privacy','site-health','tools','import','export','update-core'];
        return in_array( $screen->base, $core, true ) || Admin::screen() || in_array( $screen->id, Settings::get()['appearance']['screens'], true );
    }
    public function body( $classes ) {
        if ( self::safe() ) { return $classes; }
        $s = Settings::get();
        return $classes . ' sbui-mode-' . self::mode() . ( self::content_supported() ? ' sbui-content' : '' ) . ( $s['branding']['menu_style'] ? ' sbui-menu-style' : '' );
    }
    public function assets() {
        if ( self::safe() ) { return; }
        $s = Settings::get();
        wp_enqueue_style( 'sbui-theme', SBUI_URL.'assets/theme.css', [], SBUI_VERSION );
        wp_add_inline_style( 'sbui-theme', 'body{--sbui-accent:'.$s['branding']['accent'].';}' );
        if ( $s['advanced']['css'] ) { wp_add_inline_style( 'sbui-theme', $s['advanced']['css'] ); }
        wp_enqueue_script( 'sbui-theme', SBUI_URL.'assets/theme.js', [], SBUI_VERSION, true );
        wp_localize_script( 'sbui-theme', 'sbuiTheme', [ 'mode'=>self::mode(), 'endpoint'=>rest_url('starboard-ui/v1/appearance'), 'nonce'=>wp_create_nonce('wp_rest'), 'logo'=>$s['branding']['logo'], 'logoDark'=>$s['branding']['logo_dark'], 'saved'=>__('Appearance saved.','starboard-ui'), 'failed'=>__('Could not save appearance. Please try again.','starboard-ui') ] );
    }
    public function routes() {
        register_rest_route( 'starboard-ui/v1', '/appearance', [
            'methods'=>'POST', 'permission_callback'=>function () { $a=Settings::get()['appearance']; return current_user_can('read') && $a['allow_user'] && ! $a['lock']; },
            'args'=>['mode'=>['required'=>true,'type'=>'string','enum'=>['light','dark','system']]],
            'callback'=>function ( $request ) { $mode=$request->get_param('mode'); update_user_meta(get_current_user_id(),'starboard_ui_mode',$mode); return rest_ensure_response(['mode'=>$mode]); },
        ] );
    }
    public function toolbar( $bar ) {
        if ( self::safe() || ! is_admin() ) { return; }
        $s=Settings::get();
        foreach ( ['hide_logo'=>'wp-logo','hide_updates'=>'updates','hide_comments'=>'comments','hide_new'=>'new-content'] as $key=>$node ) { if($s['toolbar'][$key]){$bar->remove_node($node);} }
        if ( $s['appearance']['allow_user'] && ! $s['appearance']['lock'] && current_user_can('read') ) {
            $bar->add_node(['id'=>'starboard-appearance','title'=>esc_html__('Appearance','starboard-ui'),'href'=>'#','meta'=>['title'=>__('Choose appearance','starboard-ui')]]);
            foreach ( ['light'=>__('Light','starboard-ui'),'dark'=>__('Dark','starboard-ui'),'system'=>__('System','starboard-ui')] as $mode=>$label ) {
                $bar->add_node(['id'=>'starboard-mode-'.$mode,'parent'=>'starboard-appearance','title'=>esc_html($label),'href'=>'#starboard-mode-'.$mode]);
            }
        }
    }
    public function footer( $text ) { $s=Settings::get(); return ! self::safe() && $s['branding']['footer'] ? esc_html($s['branding']['footer']) : $text; }
    public function menus() {
        if ( self::safe() ) { return; }
        global $menu, $submenu;
        $n=Settings::get()['navigation'];
        foreach($n['labels'] as $id=>$label){
            if(strpos($id,'custom-sep-')===0){$menu[]=['','read',$id,'','wp-menu-separator'];}
        }
        foreach($menu as &$item){
            if(isset($n['labels'][$item[2]]) && $n['labels'][$item[2]]!==''){
                $item[0]='<span class="sbui-group">'.esc_html($n['labels'][$item[2]]).'</span>';
                $item[4]=str_replace('wp-menu-separator','',$item[4]??'').' sbui-group-row';
            }
        }
        unset($item);
        if(current_user_can('manage_options')){return;}
        // A multi-role user sees a menu if any assigned role permits it.
        $roles=wp_get_current_user()->roles;
        $hidden=null;
        foreach($roles as $role){$rules=$n['hidden'][$role]??[];$hidden=null===$hidden?$rules:array_intersect($hidden,$rules);}
        $hidden=array_unique(array_merge($hidden??[],$n['legacy_hidden']));
        foreach($hidden as $slug){
            if(in_array($slug,['starboard','starboard-ui','modern-admin','starboard::starboard-ui'],true)){continue;}
            if(strpos($slug,'::')!==false){list($parent,$child)=explode('::',$slug,2);remove_submenu_page($parent,$child);}else{remove_menu_page($slug);}
        }
    }
    public function order( $order ) {
        if(self::safe()){return $order;}
        global $menu;
        $present=array_column($menu,2);
        $saved=Settings::get()['navigation']['order'];
        return $saved ? array_values(array_unique(array_merge(array_intersect($saved,$present),$present))) : $order;
    }
    public function dashboard() {
        if(self::safe()){return;}
        $d=Settings::get()['dashboard'];
        foreach($d['hide_widgets'] as $id){foreach(['normal','side','column3','column4'] as $context){remove_meta_box($id,'dashboard',$context);}}
        if($d['enabled']){wp_add_dashboard_widget('starboard_welcome',esc_html($d['title']),[$this,'welcome']);}
    }
    public function welcome() {
        $d=Settings::get()['dashboard'];
        echo wp_kses_post($d['html']);
        if($d['links']){echo '<ul>';foreach($d['links'] as $link){echo '<li><a href="'.esc_url($link['url']).'">'.esc_html($link['label']).'</a></li>';}echo '</ul>';}
        if($d['support_url']){echo '<p><a href="'.esc_url($d['support_url']).'">'.esc_html($d['support_label']).'</a></p>';}
    }
    public static function preview() {
        return isset($_GET['sbui-preview'],$_GET['_wpnonce']) && '1'===$_GET['sbui-preview'] && current_user_can('manage_options') && wp_verify_nonce(Settings::scalar($_GET['_wpnonce']),'sbui-preview');
    }
    public function preview_headers() { if(self::preview()){nocache_headers();header('X-Robots-Tag: noindex, nofollow',true);} }
    public function login() {
        if(self::safe()){return;}
        $s=Settings::get(); $l=$s['login']; $preview=self::preview();
        if(!$l['enabled']&&!$preview){return;}
        wp_enqueue_style('sbui-login',SBUI_URL.'assets/login.css',[],SBUI_VERSION);
        $vars='body.login{--sbui-accent:'.$s['branding']['accent'].';--sbui-login-bg:'.$l['background_color'].';--sbui-login-form:'.$l['form_color'].';--sbui-login-radius:'.$l['radius'].'px;--sbui-login-overlay:'.($l['overlay']/100).';}';
        // JSON quoting gives a valid CSS string; reject HTML delimiters before embedding.
        foreach(['background'=>'--sbui-login-image','logo'=>'--sbui-login-logo','logo_dark'=>'--sbui-login-logo-dark'] as $key=>$var){if($l[$key]){$vars.='body.login{'.$var.':url('.wp_json_encode($l[$key],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).');}';}}
        if($l['logo']){$vars.='body.login #login h1 a{background-image:var(--sbui-login-logo);background-size:contain;width:100%;height:80px;}';}
        wp_add_inline_style('sbui-login',$vars);
        wp_enqueue_script('sbui-login',SBUI_URL.'assets/login.js',[],SBUI_VERSION,true);
        wp_localize_script('sbui-login','sbuiLogin',['layout'=>$l['layout'],'preview'=>(bool)$preview]);
    }
    public function login_url($url){return !self::safe()&&Settings::get()['login']['enabled']?home_url('/'):$url;}
    public function login_text($text){return !self::safe()&&Settings::get()['login']['enabled']?get_bloginfo('name'):$text;}
}
