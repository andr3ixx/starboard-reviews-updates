<?php
namespace Starboard\UI;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** All storage, imports and migrations pass through this schema. */
class Settings {
    const OPTION = 'starboard_ui_settings';
    public static function defaults() {
        return [
            'schema_version' => 1,
            'branding' => [ 'accent'=>'#2864ed', 'logo'=>'', 'logo_dark'=>'', 'footer'=>'', 'menu_style'=>false ],
            'appearance' => [ 'default'=>'system', 'allow_user'=>true, 'lock'=>'', 'screens'=>[] ],
            'login' => [ 'enabled'=>false, 'logo'=>'', 'logo_dark'=>'', 'background'=>'', 'background_color'=>'#f3f6fb', 'form_color'=>'#ffffff', 'radius'=>16, 'layout'=>'center', 'overlay'=>20 ],
            'navigation' => [ 'order'=>[], 'labels'=>[], 'hidden'=>[], 'legacy_hidden'=>[] ],
            'dashboard' => [ 'enabled'=>false, 'title'=>'Welcome aboard', 'html'=>'<p>Your workspace, ready for the day.</p>', 'support_label'=>'Contact support', 'support_url'=>'', 'links'=>[], 'hide_widgets'=>[] ],
            'toolbar' => [ 'hide_logo'=>false, 'hide_updates'=>false, 'hide_comments'=>false, 'hide_new'=>false ],
            'advanced' => [ 'css'=>'' ],
        ];
    }
    public static function scalar( $value ) { return is_scalar( $value ) ? (string) $value : ''; }
    public static function text( $value ) { return sanitize_text_field( self::scalar( $value ) ); }
    public static function url( $value ) { return esc_url_raw( self::scalar( $value ), [ 'http', 'https' ] ); }
    public static function keys( $value ) {
        if ( ! is_array( $value ) ) { return []; }
        return array_values( array_unique( array_filter( array_map( [__CLASS__, 'text'], array_slice( $value, 0, 300 ) ) ) ) );
    }
    public static function choice( $value, $choices, $default ) { return in_array( $value, $choices, true ) ? $value : $default; }
    public static function clean( $input, $old = [] ) {
        $d = self::defaults();
        $input = is_array( $input ) ? $input : [];
        $out = $d;
        foreach ( $d as $section => $fields ) {
            if ( ! is_array( $fields ) ) { continue; }
            $v = isset( $input[$section] ) && is_array( $input[$section] ) ? $input[$section] : [];
            foreach ( $fields as $key => $default ) {
                $value = $v[$key] ?? $default;
                if ( is_bool( $default ) ) { $out[$section][$key] = in_array( $value, [true, 1, '1'], true ); }
                elseif ( is_string( $default ) ) { $out[$section][$key] = self::text( $value ); }
            }
        }
        $b = is_array( $input['branding'] ?? null ) ? $input['branding'] : [];
        $out['branding']['accent'] = sanitize_hex_color( self::scalar( $b['accent'] ?? '' ) ) ?: $d['branding']['accent'];
        foreach ( ['branding','login'] as $section ) {
            foreach ( ['logo','logo_dark'] as $key ) { $out[$section][$key] = self::url( $input[$section][$key] ?? '' ); }
        }
        $a = is_array( $input['appearance'] ?? null ) ? $input['appearance'] : [];
        $out['appearance']['default'] = self::choice( $a['default'] ?? '', ['light','dark','system'], 'system' );
        $out['appearance']['lock'] = self::choice( $a['lock'] ?? '', ['','light','dark','system'], '' );
        $out['appearance']['screens'] = self::keys( $a['screens'] ?? [] );
        $l = is_array( $input['login'] ?? null ) ? $input['login'] : [];
        $out['login']['background'] = self::url( $l['background'] ?? '' );
        foreach ( ['background_color','form_color'] as $key ) { $out['login'][$key] = sanitize_hex_color( self::scalar( $l[$key] ?? '' ) ) ?: $d['login'][$key]; }
        $out['login']['radius'] = max( 0, min( 40, (int) self::scalar( $l['radius'] ?? 16 ) ) );
        $out['login']['overlay'] = max( 0, min( 90, (int) self::scalar( $l['overlay'] ?? 20 ) ) );
        $out['login']['layout'] = self::choice( $l['layout'] ?? '', ['center','left','right'], 'center' );
        $n = is_array( $input['navigation'] ?? null ) ? $input['navigation'] : [];
        $out['navigation']['order'] = array_values(array_unique(array_map(function($slug){
            return in_array($slug,['starboard-reviews','starboard-ui','modern-admin'],true)?'starboard':$slug;
        },self::keys( $n['order'] ?? [] ))));
        $out['navigation']['legacy_hidden'] = array_values( array_diff( self::keys( $n['legacy_hidden'] ?? [] ), ['starboard','starboard-ui','modern-admin','starboard::starboard-ui'] ) );
        foreach ( array_slice( is_array( $n['labels'] ?? null ) ? $n['labels'] : [], 0, 100, true ) as $id => $label ) {
            $id = self::text( $id );
            if ( preg_match( '/^(custom-sep-|separator)[a-zA-Z0-9_-]*$/', $id ) ) { $out['navigation']['labels'][$id] = self::text( $label ); }
        }
        foreach ( is_array( $n['hidden'] ?? null ) ? $n['hidden'] : [] as $role => $slugs ) {
            if ( isset( wp_roles()->roles[$role] ) && 'administrator' !== $role ) {
                $out['navigation']['hidden'][$role] = array_values( array_diff( self::keys( $slugs ), ['starboard','starboard-ui','modern-admin','starboard::starboard-ui'] ) );
            }
        }
        $dash = is_array( $input['dashboard'] ?? null ) ? $input['dashboard'] : [];
        $out['dashboard']['html'] = wp_kses_post( self::scalar( $dash['html'] ?? $d['dashboard']['html'] ) );
        $out['dashboard']['support_url'] = self::url( $dash['support_url'] ?? '' );
        $out['dashboard']['hide_widgets'] = array_values( array_intersect( self::keys( $dash['hide_widgets'] ?? [] ), ['dashboard_activity','dashboard_right_now','dashboard_quick_press','dashboard_primary','dashboard_site_health','dashboard_recent_comments','dashboard_recent_drafts','dashboard_incoming_links','dashboard_plugins'] ) );
        foreach ( array_slice( is_array( $dash['links'] ?? null ) ? $dash['links'] : [], 0, 12 ) as $link ) {
            if ( ! is_array( $link ) ) { continue; }
            $url = self::url( $link['url'] ?? '' ); $label = self::text( $link['label'] ?? '' );
            if ( $url && $label ) { $out['dashboard']['links'][] = compact( 'label', 'url' ); }
        }
        // CSS is deliberately privileged; imports must not bypass this check.
        $out['advanced']['css'] = current_user_can( 'edit_css' ) || current_user_can( 'unfiltered_html' )
            ? wp_strip_all_tags( self::scalar( $input['advanced']['css'] ?? '' ) )
            : self::scalar( $old['advanced']['css'] ?? '' );
        return $out;
    }
    public static function get() {
        return self::clean( get_option( self::OPTION, self::defaults() ), get_option( self::OPTION, [] ) );
    }
    public static function from_legacy( $v ) {
        $d = self::defaults();
        $d['branding'] = [ 'accent'=>$v['primary_color'] ?? '#722ed1', 'logo'=>$v['logo_url'] ?? '', 'logo_dark'=>'', 'footer'=>$v['footer_text'] ?? 'Built by The DigitalDeckhand', 'menu_style'=>true ];
        $d['appearance']['default'] = empty( $v['dark_mode'] ) ? 'light' : 'dark';
        $d['appearance']['allow_user'] = false;
        $d['login'] = array_merge( $d['login'], [ 'enabled'=>true, 'logo'=>$v['login_logo'] ?? '', 'background'=>$v['login_bg_image'] ?? '', 'background_color'=>$v['login_bg_color'] ?? '#f0f0f1', 'form_color'=>$v['login_form_bg'] ?? '#ffffff', 'radius'=>$v['login_radius'] ?? 8 ] );
        $d['navigation']['order'] = is_string( $v['menu_order'] ?? null ) ? explode( ',', $v['menu_order'] ) : [];
        $d['navigation']['labels'] = $v['sep_labels'] ?? [];
        $d['navigation']['legacy_hidden'] = $v['restricted_menus'] ?? [];
        $d['dashboard']['enabled'] = ! empty( $v['enable_welcome'] );
        $d['dashboard']['html'] = $v['welcome_html'] ?? $d['dashboard']['html'];
        foreach ( ['hide_updates','hide_comments','hide_new'] as $key ) { $d['toolbar'][$key] = ! empty( $v[$key] ); }
        $d['toolbar']['hide_logo'] = true;
        $d['advanced']['css'] = ''; // Never activate unvalidated legacy CSS during an automatic upgrade.
        return self::clean( $d );
    }
    public static function migrate() {
        if ( false !== get_option( self::OPTION, false ) ) { return; }
        $old = get_option( 'modern_admin_settings', false );
        $new = is_array( $old ) ? self::from_legacy( $old ) : self::defaults();
        add_option( self::OPTION, $new, '', false );
        // The original option is never modified. Unsafe legacy CSS is not activated.
    }
    public static function decode( $json, $old ) {
        if ( strlen( $json ) > 262144 ) { return new \WP_Error( 'size', __( 'Import is too large (maximum 256 KB).', 'starboard-ui' ) ); }
        $data = json_decode( $json, true, 32 );
        if ( ! is_array( $data ) || JSON_ERROR_NONE !== json_last_error() || ( $data['schema_version'] ?? null ) !== 1 ) {
            return new \WP_Error( 'schema', __( 'Choose a Starboard UI export with schema_version 1.', 'starboard-ui' ) );
        }
        $defaults = self::defaults();
        if ( array_diff( array_keys( $data ), array_keys( $defaults ) ) ) { return new \WP_Error( 'fields', __( 'Import contains unknown sections.', 'starboard-ui' ) ); }
        foreach ( $defaults as $section => $fields ) {
            if ( ! is_array( $fields ) ) { continue; }
            if ( ! isset( $data[$section] ) || ! is_array( $data[$section] ) || array_diff( array_keys( $data[$section] ), array_keys( $fields ) ) ) {
                return new \WP_Error( 'fields', __( 'Import has missing sections or unknown fields.', 'starboard-ui' ) );
            }
            foreach ( $fields as $key => $default ) {
                if ( ! array_key_exists( $key, $data[$section] ) || ( is_array( $default ) ? ! is_array( $data[$section][$key] ) : ! is_scalar( $data[$section][$key] ) ) ) {
                    return new \WP_Error( 'type', __( 'Import contains missing fields or invalid field types.', 'starboard-ui' ) );
                }
            }
        }
        return self::clean( $data, $old );
    }
}
