<?php
namespace Starboard\UI;
if ( ! defined( 'ABSPATH' ) ) exit;

/** Public release feed; WordPress retains responsibility for installing updates. */
class Updater {
    const REPOSITORY = 'andr3ixx/starboard-reviews-updates';
    const FEED = 'https://raw.githubusercontent.com/andr3ixx/starboard-reviews-updates/main/ui/update.json';
    const CACHE = 'sbui_release_feed_v1';

    public function __construct() {
        add_filter( 'update_plugins_github.com', [ $this, 'offer' ], 10, 4 );
        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'legacy_offer' ] );
        add_filter( 'plugins_api', [ $this, 'details' ], 10, 3 );
        add_filter( 'upgrader_pre_download', [ $this, 'download' ], 10, 4 );
        add_filter( 'plugin_action_links_' . self::plugin(), [ $this, 'links' ] );
        add_filter( 'network_admin_plugin_action_links_' . self::plugin(), [ $this, 'links' ] );
        add_action( 'admin_post_sbui_check_updates', [ $this, 'check' ] );
        add_action( 'admin_notices', [ $this, 'notice' ] );
        add_action( 'network_admin_notices', [ $this, 'notice' ] );
        add_action( 'upgrader_process_complete', [ $this, 'clear_after_upgrade' ], 10, 2 );
    }

    public static function plugin() {
        return defined('SBUI_PLUGIN') ? SBUI_PLUGIN : 'starboard-ui/starboard-ui.php';
    }

    public static function installed_version() {
        if(defined('SBUI_VERSION')) return SBUI_VERSION;
        $updates=get_site_transient('update_plugins');
        return is_object($updates) ? ($updates->checked[self::plugin()]??'0') : '0';
    }

    /** Bootstrap updates for older UI versions which have no Update URI or updater. */
    public function legacy_offer($updates) {
        $plugin=self::plugin();
        if(!is_object($updates) || !isset($updates->checked) || !is_array($updates->checked) || empty($updates->checked[$plugin])) return $updates;
        $release=self::release();
        if(!$release || !version_compare($release['version'],$updates->checked[$plugin],'>')) return $updates;
        $existing=$updates->response[$plugin]??null;
        if(is_object($existing) && version_compare($existing->new_version??'0',$release['version'],'>')) return $updates;
        $updates->response[$plugin]=(object)[
            'id'=>'https://github.com/'.self::REPOSITORY.'/tree/main/ui','slug'=>'starboard-ui','plugin'=>$plugin,
            'new_version'=>$release['version'],'url'=>'https://github.com/'.self::REPOSITORY.'/tree/main/ui',
            'package'=>$release['download_url'],'requires'=>$release['requires'],'requires_php'=>$release['requires_php'],
        ];
        unset($updates->no_update[$plugin]);
        return $updates;
    }

    public static function validate( $data ) {
        if ( ! is_array( $data ) ) return false;
        foreach ( [ 'version', 'requires', 'requires_php' ] as $key ) {
            if ( ! isset( $data[$key] ) || ! is_string( $data[$key] ) || ! preg_match( '/^\d+\.\d+(?:\.\d+)?$/D', $data[$key] ) ) return false;
        }
        $package = 'https://raw.githubusercontent.com/' . self::REPOSITORY . '/main/ui/releases/' . $data['version'] . '/starboard-ui-' . $data['version'] . '.zip';
        if ( ( $data['download_url'] ?? '' ) !== $package || ! is_string( $data['sha256'] ?? null ) || ! preg_match( '/^[a-f0-9]{64}$/D', $data['sha256'] ) ) return false;
        return [ 'version'=>$data['version'], 'requires'=>$data['requires'], 'requires_php'=>$data['requires_php'], 'download_url'=>$package, 'sha256'=>$data['sha256'] ];
    }

    public static function release() {
        $cached = get_site_transient( self::CACHE );
        if ( is_array( $cached ) && array_key_exists( 'release', $cached ) ) return $cached['release'] ? self::validate( $cached['release'] ) : false;
        $response = wp_safe_remote_get( self::FEED, [ 'timeout'=>8, 'redirection'=>2, 'limit_response_size'=>65536, 'headers'=>[ 'Accept'=>'application/json' ] ] );
        $release = false;
        if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) $release = self::validate( json_decode( wp_remote_retrieve_body( $response ), true ) );
        set_site_transient( self::CACHE, [ 'release'=>$release, 'checked'=>time() ], $release ? HOUR_IN_SECONDS : 10 * MINUTE_IN_SECONDS );
        return $release;
    }

    public function offer( $update, $plugin_data, $plugin_file, $locales ) {
        if ( $plugin_file !== self::plugin() ) return $update;
        $release = self::release();
        if ( ! $release ) return $update;
        return [ 'id'=>'https://github.com/' . self::REPOSITORY . '/tree/main/ui', 'slug'=>'starboard-ui', 'version'=>$release['version'], 'url'=>'https://github.com/' . self::REPOSITORY . '/tree/main/ui/releases/' . $release['version'], 'package'=>$release['download_url'], 'requires'=>$release['requires'], 'requires_php'=>$release['requires_php'] ];
    }

    public function details( $result, $action, $args ) {
        if ( $action !== 'plugin_information' || ! is_object( $args ) || ( $args->slug ?? '' ) !== 'starboard-ui' ) return $result;
        $release = self::release();
        if ( ! $release ) return $result;
        return (object) [ 'name'=>'Starboard UI', 'slug'=>'starboard-ui', 'version'=>$release['version'], 'author'=>'DigitalDeckhand', 'homepage'=>'https://digitaldeckhand.com/', 'requires'=>$release['requires'], 'requires_php'=>$release['requires_php'], 'download_link'=>$release['download_url'], 'sections'=>[ 'description'=>'Admin branding, login design, navigation and appearance for WordPress.', 'changelog'=>'<p><a href="' . esc_url( 'https://github.com/' . self::REPOSITORY . '/tree/main/ui/releases/' . $release['version'] ) . '" target="_blank" rel="noopener noreferrer">Read the release notes</a></p>' ] ];
    }

    /** Verify only our release package, leaving every other upgrader untouched. */
    public function download( $reply, $package, $upgrader, $hook_extra ) {
        if ( $reply !== false || ! is_string( $package ) || strpos( $package, 'https://raw.githubusercontent.com/' . self::REPOSITORY . '/main/ui/releases/' ) !== 0 ) return $reply;
        if ( ! empty( $hook_extra['plugin'] ) && $hook_extra['plugin'] !== self::plugin() ) return $reply;
        $release = self::release();
        if ( ! $release || $package !== $release['download_url'] ) return new \WP_Error( 'sbui_update_manifest', 'The Starboard update could not be verified. Check for updates and try again.' );
        if ( ! function_exists( 'download_url' ) ) require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = download_url( $package );
        if ( is_wp_error( $file ) ) return $file;
        if ( ! hash_equals( $release['sha256'], hash_file( 'sha256', $file ) ?: '' ) ) {
            wp_delete_file( $file );
            return new \WP_Error( 'sbui_update_checksum', 'The Starboard update download failed its integrity check. No update was installed.' );
        }
        return $file;
    }

    public static function check_url() {
        return wp_nonce_url( admin_url( 'admin-post.php?action=sbui_check_updates' ), 'sbui_check_updates' );
    }

    public function links( $links ) {
        if ( current_user_can( 'update_plugins' ) ) $links[] = '<a href="' . esc_url( self::check_url() ) . '">Check for updates</a>';
        return $links;
    }

    public function check() {
        if ( ! current_user_can( 'update_plugins' ) ) wp_die( 'Permission denied.', '', [ 'response'=>403 ] );
        check_admin_referer( 'sbui_check_updates' );
        // Shared across a multisite network; repeated clicks do not hammer the feed.
        if ( ! get_site_transient( 'sbui_update_check_cooldown' ) ) {
            set_site_transient( 'sbui_update_check_cooldown', true, MINUTE_IN_SECONDS );
            delete_site_transient( self::CACHE );
            self::release();
            wp_clean_plugins_cache( false );
            delete_site_transient( 'update_plugins' );
            wp_update_plugins();
        }
        wp_safe_redirect( self_admin_url( 'plugins.php?sbui_update_checked=1' ) );
        exit;
    }

    public function notice() {
        if ( ! current_user_can( 'update_plugins' ) || empty( $_GET['sbui_update_checked'] ) ) return;
        $screen = get_current_screen();
        if ( ! $screen || ! in_array( $screen->id, [ 'plugins', 'plugins-network' ], true ) ) return;
        $cached = get_site_transient( self::CACHE );
        $release = is_array( $cached ) && ! empty( $cached['release'] ) ? self::validate( $cached['release'] ) : false;
        $message = ! $release ? 'Could not check Starboard updates. Please try again later. Your installed plugin is unchanged.' : ( version_compare( $release['version'], self::installed_version(), '>' ) ? 'A Starboard UI update is available. Use Update now below to install it.' : 'Starboard UI is up to date.' );
        echo '<div class="notice ' . ( $release ? 'notice-success' : 'notice-warning' ) . ' is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
    }

    public static function panel() {
        if ( ! current_user_can( 'update_plugins' ) ) return;
        $updates = get_site_transient( 'update_plugins' );
        $update = is_object( $updates ) ? ( $updates->response[self::plugin()] ?? null ) : null;
        echo '<div class="sbui-callout sbui-updates-card"><h3>Plugin updates</h3><p class="sbui-help">Installed version: ' . esc_html( self::installed_version() ) . '. WordPress checks for releases periodically. You can also check now.</p>';
        if ( $update && version_compare( $update->new_version, self::installed_version(), '>' ) ) {
            $url = wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . rawurlencode( self::plugin() ) ), 'upgrade-plugin_' . self::plugin() );
            echo '<p>Version ' . esc_html( $update->new_version ) . ' is available.</p><a class="sbui-button sbui-primary" href="' . esc_url( $url ) . '">Update now</a> ';
        }
        echo '<a class="sbui-button" href="' . esc_url( self::check_url() ) . '">Check for updates</a><p class="sbui-help">Downloads are served from the public Starboard release repository. Your site does not need a GitHub account or token.</p></div>';
    }

    public function clear_after_upgrade( $upgrader, $options ) {
        if ( ( $options['type'] ?? '' ) === 'plugin' && in_array( self::plugin(), $options['plugins'] ?? [], true ) ) delete_site_transient( self::CACHE );
    }
}
