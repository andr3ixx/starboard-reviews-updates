=== Starboard UI ===
Contributors: digitaldeckhand
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 3.0.2
License: GPLv2 or later

A comfortable WordPress workspace with optional branding, appearance modes, login styling and client navigation.

== Installation ==
Upload the starboard-ui folder to wp-content/plugins, activate it and open Starboard > UI.
Replace the old Starboard UI installation; do not run the old and new plugins together.
Reviews and WooCommerce are not required. Starboard Reviews integrates automatically when present.
WordPress update notices use the public Starboard UI feed. Use Plugins > Starboard UI > Check for updates, or Starboard > UI > Advanced. Older UI-only installations need one manual installation of 3.0.2 or later; sites paired with updated Reviews can receive that initial UI update through its compatibility bridge.

== Upgrade and recovery ==
Version 3.0 migrates modern_admin_settings into a separate versioned option. The original option is retained unchanged. Downgrading restores the configuration at the time of migration; later changes are not written back to 2.0.
Legacy custom CSS is retained only in the original option until an authorized user re-enters it. It is not automatically executed.
Legacy menu styling and footer credits are preserved. New installs start with minimal changes.
Append &starboard-safe=1 to the settings URL to bypass custom styling, menu changes and dashboard changes for that request.
For persistent recovery, add define('STARBOARD_UI_SAFE_MODE', true); to wp-config.php before WordPress loads.
WP-CLI: wp starboard-ui reset resets site settings after confirmation. Per-user appearance preferences are retained.
Deactivation preserves settings. Remove options starboard_ui_settings and starboard_ui_previous_settings manually only if you want to delete configuration.

== Appearance ==
Light, Dark and System modes follow site enforcement, then permitted user preferences, then the site default. User preferences are stored in user meta and work across devices.
Supported core screens and Starboard UI receive dark content styling. Third-party content stays light unless its screen ID is explicitly opted in. Editor canvases are excluded. WooCommerce screens require explicit opt-in and site-specific testing.
Reviews supports appearance on its own via Users > Profile; Starboard UI takes precedence when installed.

== Settings and permissions ==
Settings require manage_options. Custom CSS also requires edit_css or unfiltered_html. Menu hiding changes navigation only, never permissions or URL access. Users with manage_options are never hidden from menus. Users with multiple roles keep a menu if any assigned role allows it.
Import requires a versioned schema-1 export, shows a sanitized diff, and replaces all sections only when applied. The previous configuration is retained as starboard_ui_previous_settings.
Exports include image URLs, not image binaries. Replace URLs with local images after moving between sites. This avoids nonportable attachment IDs. No media is fetched by the import handler.
Login preview uses the same-origin login page, a permission-checked nonce and origin/source checked messages. It never saves preview values or permits form submission. Login-hiding plugins may prevent this preview; use a separate login window after saving in that case.

== Changelog ==
= 3.0.2 =
* Use a compact monochrome sidebar mark that follows WordPress menu colors.
* Add native WordPress update notices, manual checks and SHA-256 verified downloads.
= 3.0.1 =
* Group UI and Reviews beneath one Starboard sidebar entry, with independent activation and deactivation.
* Remove right-edge arrows throughout the admin sidebar.
= 3.0.0 =
* Rebuilt accessible settings, versioned schema, validated imports and migration.
* Light, Dark and System modes with toolbar preferences and safe mode.
* Login presets, live preview and responsive layouts.
* Keyboard menu ordering, group labels, role-aware menu visibility and selected dashboard widgets.
* Optional Starboard Reviews product navigation, branding and appearance integration.
