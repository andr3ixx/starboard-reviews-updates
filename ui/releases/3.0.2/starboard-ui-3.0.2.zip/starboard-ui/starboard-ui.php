<?php
/**
 * Plugin Name: Starboard UI
 * Description: Thoughtful branding, appearance, login design and client navigation for WordPress.
 * Version: 3.0.2
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: DigitalDeckhand
 * Author URI: https://digitaldeckhand.com/
 * Update URI: https://github.com/andr3ixx/starboard-reviews-updates/tree/main/ui
 * Text Domain: starboard-ui
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
define( 'SBUI_VERSION', '3.0.2' );
define( 'SBUI_PATH', plugin_dir_path( __FILE__ ) );
define( 'SBUI_PLUGIN', plugin_basename( __FILE__ ) );
define( 'SBUI_URL', plugin_dir_url( __FILE__ ) );
if(!class_exists('Starboard\\UI\\Updater',false)){require_once SBUI_PATH . 'includes/class-updater.php';}
require_once SBUI_PATH . 'includes/class-settings.php';
require_once SBUI_PATH . 'includes/class-runtime.php';
require_once SBUI_PATH . 'includes/class-admin.php';
add_action( 'plugins_loaded', function () {
    \Starboard\UI\Settings::migrate();
    new \Starboard\UI\Updater();
    new \Starboard\UI\Runtime();
    new \Starboard\UI\Admin();
} );
if ( defined( 'WP_CLI' ) && WP_CLI ) {
    WP_CLI::add_command( 'starboard-ui reset', function () {
        WP_CLI::confirm( 'Reset Starboard UI settings? The original 2.0 option is retained.' );
        update_option( \Starboard\UI\Settings::OPTION, \Starboard\UI\Settings::defaults(), false );
        WP_CLI::success( 'Starboard UI reset. User appearance preferences remain in place.' );
    } );
}
